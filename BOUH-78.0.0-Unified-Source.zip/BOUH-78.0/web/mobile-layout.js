/* Viewport and display preferences only. Scientific scores never depend on these. */
(function(root){
 'use strict';
 const KEY='bouh_v77_display',defaults={mapSize:'balanced',textSize:'normal',autoCompact:true,topInset:0,bottomInset:0};
 const heights={compact:'clamp(190px,24dvh,230px)',balanced:'clamp(210px,30dvh,290px)',large:'clamp(240px,40dvh,380px)'};
 const $=id=>document.getElementById(id);let prefs={...defaults},focused=false,largestHeight=0;
 try{const x=JSON.parse(localStorage.getItem(KEY));if(x&&typeof x==='object')prefs={...defaults,...x};}catch(e){}
 function sanitize(p){return {mapSize:heights[p.mapSize]?p.mapSize:'balanced',textSize:p.textSize==='large'?'large':'normal',autoCompact:p.autoCompact!==false,topInset:Math.max(0,Math.min(64,Number(p.topInset)||0)),bottomInset:Math.max(0,Math.min(80,Number(p.bottomInset)||0))};}
 prefs=sanitize(prefs);
 function persist(){try{localStorage.setItem(KEY,JSON.stringify(prefs));}catch(e){}}
 function apply(){
  const s=document.documentElement.style;s.setProperty('--extra-top',prefs.topInset+'px');s.setProperty('--extra-bottom',prefs.bottomInset+'px');s.setProperty('--map-height',heights[prefs.mapSize]);document.body.classList.toggle('large-text',prefs.textSize==='large');
  $('mapSize').value=prefs.mapSize;$('textSize').value=prefs.textSize;$('autoCompact').checked=prefs.autoCompact;$('topInset').value=prefs.topInset;$('bottomInset').value=prefs.bottomInset;$('topInsetValue').textContent=prefs.topInset+' بكسل';$('bottomInsetValue').textContent=prefs.bottomInset+' بكسل';sync();
 }
 function sync(){
  const vv=root.visualViewport,scale=vv?vv.scale:1;
  // Do not interpret pinch zoom as keyboard resizing.
  const h=Math.round(vv&&Math.abs(scale-1)<.05?vv.height:root.innerHeight);
  if(!Number.isFinite(h)||h<=0)return;
  largestHeight=Math.max(largestHeight,h);document.documentElement.style.setProperty('--app-height',h+'px');
  document.body.classList.toggle('keyboard-open',!!(focused&&prefs.autoCompact));
  const status=$('displayStatus');if(status)status.textContent='الإصدار 78.0 · ارتفاع العرض المتاح: '+h+' بكسل · '+(focused?'وضع الكتابة':'وضع التصفح')+' · تُحفظ إعدادات العرض تلقائيًا.';
 }
 function isEditable(t){return t&&((t.tagName==='INPUT'&&!['checkbox','range','button','submit'].includes(t.type))||t.tagName==='TEXTAREA');}
 document.addEventListener('focusin',e=>{if(isEditable(e.target)){focused=true;sync();setTimeout(()=>{if(e.target&&e.target.scrollIntoView)e.target.scrollIntoView({block:'nearest',inline:'nearest',behavior:'auto'});},180);}});
 document.addEventListener('focusout',()=>setTimeout(()=>{focused=isEditable(document.activeElement);sync();},70));
 for(const id of ['mapSize','textSize','autoCompact','topInset','bottomInset']){
  const el=$(id);el.addEventListener(id.endsWith('Inset')?'input':'change',()=>{prefs=sanitize({mapSize:$('mapSize').value,textSize:$('textSize').value,autoCompact:$('autoCompact').checked,topInset:$('topInset').value,bottomInset:$('bottomInset').value});persist();apply();root.dispatchEvent(new Event('resize'));});
 }
 $('resetDisplay').onclick=()=>{prefs={...defaults};persist();apply();root.dispatchEvent(new Event('resize'));};
 $('mapToggle').onclick=()=>{const collapsed=!document.body.classList.contains('map-collapsed');document.body.classList.toggle('map-collapsed',collapsed);$('mapToggle').textContent=collapsed?'توسيع الخريطة ↓':'طي الخريطة ↑';$('mapToggle').setAttribute('aria-expanded',String(!collapsed));root.dispatchEvent(new Event('resize'));};
 root.addEventListener('resize',sync);root.addEventListener('orientationchange',()=>{largestHeight=0;setTimeout(sync,150);});
 if(root.visualViewport){root.visualViewport.addEventListener('resize',sync);root.visualViewport.addEventListener('scroll',sync);}
 apply();root.BOUHDisplay={getPreferences:()=>({...prefs}),sync};
})(window);
