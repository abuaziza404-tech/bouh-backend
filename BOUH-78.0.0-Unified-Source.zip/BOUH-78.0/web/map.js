/* Small offline-capable canvas viewer. Legacy image bounds are approximate. */
(function(root){
 'use strict';
 const MAXLAT=85.05112878;
 function project(lat,lon,z){const size=256*2**z,s=Math.sin(Math.max(-MAXLAT,Math.min(MAXLAT,lat))*Math.PI/180);return {x:(lon+180)/360*size,y:(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*size};}
 function unproject(x,y,z){const size=256*2**z;return {lat:Math.atan(Math.sinh(Math.PI*(1-2*y/size)))*180/Math.PI,lon:((x/size*360)%360+360)%360-180};}
 function create(canvas,onChange,onStatus){
  const ctx=canvas.getContext('2d'),layers=['rgb','swir','satellite'];let layer='rgb',center={lat:18.8888,lon:37.18893},zoom=13,width=0,height=0,gps=null,drag=null,frame=0,timer=0,disposed=false;
  const tiles=new Map(),images=[],pointers=new Map();let loaded=0,failed=0,pinch=null,markers=[],cloudPolygons=[],cloudRasters=[],cloudTileLayer=null;
  const bounds=[['center',18.7,20.4],['north',20.3,21.618973809501448],['south',17.588885769479703,18.85]];
  for(const [name,south,north] of bounds)for(const mode of ['rgb','swir']){
   const image=new Image();const row={image,mode,south,north,west:35.74145507509822,east:37.85083007509823,ready:false};
   image.onload=()=>{row.ready=true;loaded++;report();drawSoon();};image.onerror=()=>{failed++;report();};
   images.push(row);image.src=`assets/offline_layers/${name}_offline_${mode}.jpg`;
  }
  function report(){onStatus&&onStatus({layer,loaded,failed,total:6,approximate:layer!=='satellite'});}
  function redraw(){frame=0;if(disposed)return;const dpr=Math.min(root.devicePixelRatio||1,2),rect=canvas.getBoundingClientRect();width=rect.width;height=rect.height;if(!width||!height)return;
   if(canvas.width!==Math.round(width*dpr)||canvas.height!==Math.round(height*dpr)){canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);}
   ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#1a2a30';ctx.fillRect(0,0,width,height);
   const p=project(center.lat,center.lon,zoom),left=p.x-width/2,top=p.y-height/2;
   if(layer==='satellite')drawTiles(left,top);else{
    for(const r of images){if(!r.ready||r.mode!==layer)continue;
     const nw=project(r.north,r.west,zoom),se=project(r.south,r.east,zoom);
     if(se.x<left||nw.x>left+width||se.y<top||nw.y>top+height)continue;
     // Piecewise latitude strips avoid stretching an entire latitude-longitude image as Mercator.
     // The original image CRS/bounds are unverified, so this remains contextual, not survey control.
     const strips=48;
     for(let i=0;i<strips;i++){const a=r.north-(r.north-r.south)*i/strips,b=r.north-(r.north-r.south)*(i+1)/strips,pa=project(a,r.west,zoom),pb=project(b,r.east,zoom);ctx.drawImage(r.image,0,r.image.height*i/strips,r.image.width,r.image.height/strips,pa.x-left,pa.y-top,pb.x-pa.x,pb.y-pa.y+.4);}
    }
   }
   for(const raster of cloudRasters){
    const [[south,west],[north,east]]=raster.bounds,nw=project(north,west,zoom),se=project(south,east,zoom);
    ctx.drawImage(raster.image,nw.x-left,nw.y-top,se.x-nw.x,se.y-nw.y);
   }
   if(cloudTileLayer)cloudTileLayer.draw(ctx,left,top,width,height,zoom,drawSoon);
   // Cloud polygons retain all interior rings; even-odd fill preserves holes.
   for(const feature of cloudPolygons){
    const style=feature.color;
    ctx.beginPath();
    for(const ring of [feature.coordinates,...feature.holes]){
     ring.forEach((v,i)=>{const q=project(v.latitude,v.longitude,zoom);if(i)ctx.lineTo(q.x-left,q.y-top);else ctx.moveTo(q.x-left,q.y-top);});
     ctx.closePath();
    }
    ctx.fillStyle=style.fill;ctx.strokeStyle=style.stroke;ctx.lineWidth=2;
    ctx.fill('evenodd');ctx.stroke();
   }
   // Geographic grid provides orientation even beyond image coverage.
   ctx.strokeStyle='#c9d6d416';ctx.lineWidth=1;const spacing=zoom>=14?.002:zoom>=12?.01:zoom>=10?.05:.2;
   const a=unproject(left,top,zoom),b=unproject(left+width,top+height,zoom);
   for(let lat=Math.floor(b.lat/spacing)*spacing;lat<=a.lat;lat+=spacing){const y=project(lat,center.lon,zoom).y-top;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(width,y);ctx.stroke();}
   if(b.lon>a.lon)for(let lon=Math.floor(a.lon/spacing)*spacing;lon<=b.lon;lon+=spacing){const x=project(center.lat,lon,zoom).x-left;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,height);ctx.stroke();}
   const focus=project(18.8888,37.18893,zoom),fmpp=156543.03392*Math.cos(18.8888*Math.PI/180)/2**zoom;ctx.strokeStyle='#80cfc08a';ctx.lineWidth=1;ctx.beginPath();ctx.arc(focus.x-left,focus.y-top,Math.min(100000,5000/fmpp),0,Math.PI*2);ctx.stroke();
   for(const m of markers){const pos=project(m.lat,m.lon,zoom),x=pos.x-left,y=pos.y-top;if(x<0||y<0||x>width||y>height)continue;ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fillStyle=m.reference_score>=78?'#e6c483':m.reference_score>=64?'#80cfc0':'#a6b2b8';ctx.fill();ctx.strokeStyle='#101d25';ctx.lineWidth=1;ctx.stroke();}
   if(markers.length){ctx.fillStyle='#e6c483';ctx.font='10px Arial';ctx.fillText('Reference ranking · not field detection',12, height-18);}
   if(gps){const g=project(gps.lat,gps.lon,zoom),x=g.x-left,y=g.y-top,mpp=156543.03392*Math.cos(gps.lat*Math.PI/180)/2**zoom;
    ctx.fillStyle='#80cfc022';ctx.strokeStyle='#80cfc080';ctx.beginPath();ctx.arc(x,y,Math.min(300,gps.accuracy/mpp),0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#80cfc0';ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();}
   const mpp=156543.03392*Math.cos(center.lat*Math.PI/180)/2**zoom,meters=10**Math.floor(Math.log10(mpp*70)),px=meters/mpp;
   ctx.strokeStyle='#e6c483';ctx.fillStyle='#e6c483';ctx.font='10px Arial';ctx.beginPath();ctx.moveTo(width-px-15,height-95);ctx.lineTo(width-15,height-95);ctx.stroke();ctx.fillText(meters>=1000?(meters/1000)+' km':meters+' m',width-px-15,height-102);
   ctx.font='9px Arial';ctx.fillStyle='#ffffff9a';ctx.fillText(layer==='satellite'?'Tiles © Esri and contributors':'Legacy contextual image · unverified georeferencing',12,height-4);
  }
  function drawTiles(left,top){const z=Math.floor(zoom),factor=2**(zoom-z),size=256*factor,limit=2**z;
   for(let y=Math.floor(top/size);y<=Math.floor((top+height)/size);y++)for(let x=Math.floor(left/size);x<=Math.floor((left+width)/size);x++){
    if(y<0||y>=limit)continue;const tx=((x%limit)+limit)%limit,key=z+'/'+y+'/'+tx;let item=tiles.get(key);
    if(!item){item={image:new Image(),ready:false};tiles.set(key,item);item.image.onload=()=>{item.ready=true;drawSoon();};item.image.onerror=()=>{item.failed=true;onStatus&&onStatus({layer,loaded,failed,total:6,tileError:true});};item.image.src=`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${key}`;}
    if(item.ready)ctx.drawImage(item.image,x*size-left,y*size-top,size+.4,size+.4);
   }
   if(tiles.size>200)for(const k of [...tiles.keys()].slice(0,tiles.size-150))tiles.delete(k);
  }
  function drawSoon(){if(!frame)frame=requestAnimationFrame(redraw);}
  function notify(){clearTimeout(timer);timer=setTimeout(()=>onChange&&onChange({...center,zoom}),120);}
  function touchGeometry(){const a=[...pointers.values()],r=canvas.getBoundingClientRect();return {x:(a[0].x+a[1].x)/2-(r.left||0),y:(a[0].y+a[1].y)/2-(r.top||0),distance:Math.max(1,Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)),width:r.width,height:r.height};}
  canvas.addEventListener('pointerdown',e=>{
   pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});canvas.setPointerCapture(e.pointerId);
   if(pointers.size===1)drag={id:e.pointerId,x:e.clientX,y:e.clientY,p:project(center.lat,center.lon,zoom)};
   else if(pointers.size===2){const g=touchGeometry(),p=project(center.lat,center.lon,zoom);pinch={zoom,distance:g.distance,anchor:unproject(p.x+g.x-g.width/2,p.y+g.y-g.height/2,zoom)};drag=null;}
  });
  canvas.addEventListener('pointermove',e=>{
   if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
   if(pointers.size>=2&&pinch){const g=touchGeometry();zoom=Math.max(3,Math.min(19,pinch.zoom+Math.log2(g.distance/pinch.distance)));const anchor=project(pinch.anchor.lat,pinch.anchor.lon,zoom),p=unproject(anchor.x-g.x+g.width/2,anchor.y-g.y+g.height/2,zoom);center={lat:Math.max(-MAXLAT,Math.min(MAXLAT,p.lat)),lon:p.lon};}
   else if(drag&&e.pointerId===drag.id){const p=unproject(drag.p.x-(e.clientX-drag.x),drag.p.y-(e.clientY-drag.y),zoom);center={lat:Math.max(-MAXLAT,Math.min(MAXLAT,p.lat)),lon:p.lon};}
   drawSoon();notify();
  });
  function up(e){pointers.delete(e.pointerId);pinch=null;if(pointers.size===1){const [id,p]=[...pointers.entries()][0];drag={id,x:p.x,y:p.y,p:project(center.lat,center.lon,zoom)};}else drag=null;notify();}
  canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
  canvas.addEventListener('wheel',e=>{e.preventDefault();setZoom(zoom+(e.deltaY<0?.5:-.5));},{passive:false});
  function setZoom(z){zoom=Math.max(3,Math.min(19,z));drawSoon();notify();}
  function setView(lat,lon,z){if(!root.BOUHEngine.validPoint(lat,lon))return false;center={lat:Math.max(-MAXLAT,Math.min(MAXLAT,lat)),lon};if(z!==undefined)zoom=Math.max(3,Math.min(19,z));drawSoon();notify();return true;}
  function cycleLayer(){layer=layers[(layers.indexOf(layer)+1)%layers.length];report();drawSoon();}
  function setLayer(name){if(!layers.includes(name))return false;layer=name;report();drawSoon();return true;}
  root.addEventListener('resize',drawSoon);if(root.ResizeObserver)new ResizeObserver(drawSoon).observe(canvas);
  drawSoon();report();notify();
  return {setCloudTileLayer:value=>{if(cloudTileLayer)cloudTileLayer.dispose();cloudTileLayer=value;drawSoon();},setCloudRasters:items=>{cloudRasters=items||[];drawSoon();},getBounds:()=>{const r=canvas.getBoundingClientRect(),p=project(center.lat,center.lon,zoom),nw=unproject(p.x-r.width/2,p.y-r.height/2,zoom),se=unproject(p.x+r.width/2,p.y+r.height/2,zoom);return [nw.lon,se.lat,se.lon,nw.lat];},setCloudAnomalies:fc=>{cloudPolygons=fc?root.BOUHCloudGeometry.polygonsForMap(fc):[];drawSoon();return cloudPolygons.length;},setMarkers:items=>{markers=Array.isArray(items)?items:[];drawSoon();},setView,setZoom,cycleLayer,setLayer,getLayer:()=>layer,getCenter:()=>({...center}),getZoom:()=>zoom,setGPS:p=>{gps=p;drawSoon();},project,unproject};
 }
 root.BOUHMap={create,project,unproject};
})(window);
