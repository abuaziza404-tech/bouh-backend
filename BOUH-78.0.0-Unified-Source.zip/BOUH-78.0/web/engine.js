/* BOUH 77.2: interface adapter. All scores come from the audited 1.5 engine. */
(function(root){
'use strict';
const E=root.BouhUnifiedEngine,VERSION='78.0.0',STEP=.02;
const validPoint=(lat,lon)=>typeof lat==='number'&&typeof lon==='number'&&E.isValidGeographicCoordinate(lat,lon);
function createEngine(rows){
 const inputRows=Array.isArray(rows)?rows:[],audit={input_rows:inputRows.length,invalid_rows:0,zero_value_rows:0};
 rows=inputRows.filter(r=>{if(!Array.isArray(r)||r.length<15||!validPoint(r[2],r[3])||[5,6,7,8].some(i=>r[i]!==null&&(typeof r[i]!=='number'||!Number.isFinite(r[i])||r[i]<0||r[i]>100))){audit.invalid_rows++;return false;}if([5,6,7,8].some(i=>r[i]===0))audit.zero_value_rows++;return true;});
 const bridge=root.BouhUIBridge.createUnifiedUIBridge(rows),core=bridge.engine,bins=new Map(),cache=new Map();
 const active=[],seen=new Set();
 for(const row of rows){const n=E.normalizeCellRecord(row);if(!n||!n.enabled_now||!n.eligible_when_verified||n.is_forbidden_category||n.has_unresolved_aster_bounds_conflict)continue;const coord=n.lat+','+n.lon;if(seen.has(coord))continue;seen.add(coord);const c={id:n.id,lat:n.lat,lon:n.lon};active.push(c);const k=Math.floor(n.lat/STEP)+','+Math.floor(n.lon/STEP);if(!bins.has(k))bins.set(k,[]);bins.get(k).push(c);}
 function adapt(r,lat,lon){
  const ok=r.valid_analysis===true,c=r.reference_cell||{},ind=r.computed_remote_indicators;
  return {...r,engine_version:E.ENGINE_VERSION,app_version:VERSION,lat,lon,final_score:r.core_score??null,gold_probability:null,confidence_score:null,depth_m:null,
   classification:ok?'ترتيب مرجعي · '+r.priority_class_ar:'بيانات موثقة غير كافية',reason:ok?'أولوية استطلاع تجريبية من الشبكة القديمة؛ الدرجة الأساسية غير مفعلة.':r.coverage_label_ar,
   nearest_id:c.id||null,nearest_lat:c.lat??null,nearest_lon:c.lon??null,zone:c.zone||'',distance_m:r.distance_from_query_m??null,
   reference_status:ok?'NEAR_LEGACY_REFERENCE':'OUTSIDE_REFERENCE_NEIGHBORHOOD',metrics:ok?ind:null,source_verified:false,zero_value_policy:'PRESERVED_WITH_AMBIGUITY_WARNING',raw_pipeline_executed:false,score_calibration:'UNVALIDATED',
   reference_radius_m:900,reference_radius_note:'حد بحث برمجي؛ ليس دقة المستشعر',reference_visible:true};
 }
 function analyze(lat,lon){return adapt(core.analyzeCoordinate(lat,lon),lat,lon);}
 function candidates(lat,lon,r){if(!validPoint(lat,lon))return [];if(Math.abs(lat)>85)return active;const dy=r/110000+STEP,dx=dy/Math.cos(lat*Math.PI/180);if(lon-dx< -180||lon+dx>180)return active;const out=[];for(let y=Math.floor((lat-dy)/STEP);y<=Math.floor((lat+dy)/STEP);y++)for(let x=Math.floor((lon-dx)/STEP);x<=Math.floor((lon+dx)/STEP);x++){const b=bins.get(y+','+x);if(b)out.push(...b);}return out;}
 function atCell(c){if(!cache.has(c.id)){cache.set(c.id,analyze(c.lat,c.lon));if(cache.size>5000)cache.delete(cache.keys().next().value);}return cache.get(c.id);}
 function nearestTargets(lat,lon,options={}){
  if(!validPoint(lat,lon))return [];const radius=Math.max(100,Math.min(50000,Number(options.radius_m)||10000)),limit=Math.max(1,Math.min(200,Number(options.limit)||20));
  let items=candidates(lat,lon,radius).map(c=>({c,d:E.calculateDistanceMeters(lat,lon,c.lat,c.lon)})).filter(x=>x.d<=radius);
  items.sort((a,b)=>a.d-b.d||a.c.id.localeCompare(b.c.id));if(options.sort!=='reference')items=items.slice(0,limit);
  let result=items.map(({c,d})=>({...atCell(c),query_lat:lat,query_lon:lon,query_distance_m:Math.round(d),bearing_deg:E.calculateBearing(lat,lon,c.lat,c.lon).bearing_deg,direction_ar:E.calculateBearing(lat,lon,c.lat,c.lon).direction_ar})).filter(r=>r.valid_analysis);
  if(options.sort==='reference')result.sort((a,b)=>b.reference_score-a.reference_score||a.query_distance_m-b.query_distance_m||a.nearest_id.localeCompare(b.nearest_id));return result.slice(0,limit);
 }
 function report(format,targets,center){const records=targets.map(t=>({...t,analysis:analyze(t.lat,t.lon)}));const funcs={csv:'exportTargetsCsvString',kml:'exportTargetsKmlString',geojson:'exportTargetsGeoJsonString'};if(funcs[format])return bridge[funcs[format]](records);if(format==='html')return bridge.exportHtmlFieldReportString(center,records);return bridge.exportFullReportJsonString(center,records);}
 return Object.freeze({version:VERSION,analyze,nearestTargets,report,bridge,summary:()=>({raw_rows:inputRows.length,accepted_input_rows:rows.length,invalid_input_rows:audit.invalid_rows,rows_with_zero_core_indicators:audit.zero_value_rows,unique_active_coordinates:active.length,duplicate_active_coordinates:core.totalActiveCells-active.length,active_cells:core.totalActiveCells,quarantined_cells:core.totalQuarantinedAsterCells,excluded_priors:core.totalExcludedPriorCells,documented_source_rows:0}),distance:E.calculateDistanceMeters});
}
root.BOUHEngine={createEngine,validPoint,version:VERSION};
})(window);
