(function(root){
'use strict';
const $=id=>document.getElementById(id),UI=root.BOUH77,A=root.BOUHCloudAPI;
let areas=[],busy=false,controller=null,current=null,visible=false;
const say=s=>{$('terrainStatus').textContent=s;};
function buttons(){for(const id of ['terrainLoad','terrainRun','terrainResume'])$(id).disabled=busy;$('terrainStop').disabled=!busy;$('terrainHide').disabled=!current;}
function connection(){
 const value=$('cloudUrl').value.trim().replace(/\/$/,''),url=new URL(value);
 if(url.pathname!=='/'||url.protocol!=='https:'||url.search||url.hash||url.username||url.password)throw Error('أدخل رابط HTTPS للخادم دون مسار إضافي');
 if(!$('cloudToken').value.trim())throw Error('أدخل رمز الوصول في إعداد الاتصال');
 localStorage.setItem('bouh_cloud_url_v1',JSON.stringify(value));
 return {baseUrl:value,getToken:()=>$('cloudToken').value.trim()};
}
function client(c){return A.createClient(c);}
async function loadAreas(c,signal){
 const fc=await client(c).getJSON('/terrain/api/coverage',{signal});
 if(fc.type!=='FeatureCollection'||!Array.isArray(fc.features))throw Error('قائمة مناطق غير صالحة');
 areas=fc.features.filter(f=>f.properties?.processing_enabled===true&&/^[A-Za-z0-9_-]{1,64}$/.test(f.id)&&f.geometry?.type==='Polygon');
 const selected=$('terrainArea').value;$('terrainArea').textContent='';
 for(const area of areas){const option=document.createElement('option');option.value=area.id;option.textContent=area.properties.name||area.id;$('terrainArea').appendChild(option);}
 if(areas.some(a=>a.id===selected))$('terrainArea').value=selected;
}
async function action(mode){
 if(busy)return;
 try{
  const c=connection();busy=true;controller=new AbortController();buttons();const signal=controller.signal;
  if(!areas.length||mode==='load')await loadAreas(c,signal);
  if(mode==='load'){say('مناطق قابلة للمعالجة: '+areas.length+'؛ اختر المنطقة ثم ابدأ المعالجة.');return;}
  const area=areas.find(a=>a.id===$('terrainArea').value);if(!area)throw Error('لا توجد منطقة معالجة مفعّلة');
  const api=client(c),prefix='/terrain/api/coverage/'+area.id;
  if(mode==='run')await api.postJSON(prefix+'/refresh',{signal});
  const deadline=Date.now()+12*60*1000;let result;
  for(;;){
   result=await api.getJSON(prefix+'/status',{signal});
   if(result.state==='completed')break;
   if(result.state==='failed')throw Error('رفضت المعالجة المصدر أو جودة البيانات أو نموذج PCA؛ راجع سجل الخادم.');
   if(result.state==='not_processed')throw Error('المنطقة غير معالجة؛ اضغط معالجة وعرض البلاطات.');
   if(Date.now()>deadline)throw Error('انتهت مهلة المتابعة؛ يمكنك متابعة حالة المنطقة لاحقاً.');
   say('تجري قراءة COG وتحليل PCA وحجب ظلال DEM على الخادم…');await A.wait(5000,signal);
  }
  const points=area.geometry.coordinates[0];
  const bbox=[Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))];
  current={...c,area:area.id,revision:result.revision,bbox,onError:say};visible=true;
  UI.setCloudTileLayer(root.BOUHTerrainTiles.create(current));UI.setView((bbox[1]+bbox[3])/2,(bbox[0]+bbox[2])/2);
  $('terrainHide').textContent='إخفاء الطبقة';say('عُرضت طبقة الأدلة النسبية؛ حرّك الخريطة أو كبّرها لجلب البلاطات. النتيجة مقنّعة بظل التضاريس وجودة المشهد.');
 }catch(e){say(e.name==='AbortError'?'توقفت المتابعة على الهاتف؛ قد تستمر المعالجة. استخدم متابعة حالة المنطقة.':e.message);}
 finally{busy=false;controller=null;buttons();}
}
$('terrainLoad').onclick=()=>action('load');$('terrainRun').onclick=()=>action('run');$('terrainResume').onclick=()=>action('resume');
$('terrainStop').onclick=()=>controller?.abort();
$('terrainHide').onclick=()=>{visible=!visible;UI.setCloudTileLayer(visible?root.BOUHTerrainTiles.create(current):null);$('terrainHide').textContent=visible?'إخفاء الطبقة':'إظهار الطبقة';};
buttons();
})(window);
