(function(){
 'use strict';
 const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const FOCUS={lat:18.8888,lon:37.18893,radius_m:5000};
 const KEYS={saved:'bouh_v77_saved',field:'bouh_v77_field',prefs:'bouh_v77_prefs'},engine=BOUHEngine.createEngine(window.BOUH_LEGACY_CELLS||[]);
 let activeTab='analysis',legacy=true,analysis=null,exportPayload=null,toastTimer=0,heatmap=false,mission=[];let gpsFix=null;
 function toast(t){$('toast').textContent=t;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),4000);}
 function read(k,fallback){try{const x=JSON.parse(localStorage.getItem(k));return x===null?fallback:x;}catch(e){return fallback;}}
 function write(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){toast('تعذر الحفظ على هذا الجهاز؛ صدّر البيانات لنسخها.');return false;}}
 function list(k){const x=read(k,[]);return Array.isArray(x)?x:[];}
 function uid(){return rootCrypto()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
 function rootCrypto(){try{return crypto.randomUUID();}catch(e){return null;}}
 function mapStatus(s){const names={rgb:'صور RGB محفوظة · إسناد تقريبي',swir:'صور SWIR محفوظة · إسناد تقريبي',satellite:'صور Esri · لا تغيّر الحسابات'};$('mapMode').textContent=names[s.layer];$('mapLoading').hidden=s.loaded>0;if(s.failed===6){$('mapLoading').hidden=false;$('mapLoading').textContent='تعذر تحميل الصور. الإحداثيات والحسابات متاحة.';}if(s.tileError){$('mapMode').textContent='تعذر جلب البلاطات؛ اختر الصور المحفوظة';}}
 const map=BOUHMap.create($('map'),()=>{update();if(activeTab==='targets')renderTargets();if(heatmap)refreshMarkers();},mapStatus);
 // No automatic restoration of an old result; every displayed analysis is recalculated.
 const prefs=read(KEYS.prefs,{});if(prefs&&BOUHEngine.validPoint(prefs.lat,prefs.lon))map.setView(prefs.lat,prefs.lon,prefs.zoom);
 if(prefs&&['rgb','swir','satellite'].includes(prefs.layer))map.setLayer(prefs.layer);
 legacy=read('bouh_v77_show_legacy',true)===true;$('legacyToggle').checked=legacy;
 function update(){
  const p=map.getCenter();analysis=engine.analyze(p.lat,p.lon,{includeLegacy:legacy});
  $('mapCoordinates').textContent=p.lat.toFixed(6)+', '+p.lon.toFixed(6);$('primaryTitle').textContent=analysis.valid_analysis?'ترتيب مرجعي متاح':'بيانات غير كافية';$('primaryReason').textContent=analysis.reason;$('legacyDetails').hidden=!legacy;
  $('referenceScore').textContent=analysis.reference_score===null?'غير متاح':analysis.reference_score; $('savePoint').disabled=!analysis.valid_analysis;
  const labels={structure:'البنية / الخطيات',alteration:'التحول الطيفي',feox:'أكاسيد الحديد',drainage:'التصريف / التضاريس'};
  $('metrics').innerHTML=Object.entries(labels).map(([k,label])=>{const v=analysis.metrics?analysis.metrics[k]:null;return `<div class="metric"><div><span>${label}</span><b>${v===null?'—':esc(v)}</b></div><div class="bar"><i style="width:${typeof v==='number'?v:0}%"></i></div></div>`;}).join('');
  $('nearestCard').innerHTML=analysis.nearest_id?`<b>أقرب سجل فعلي</b><p dir="ltr">${esc(analysis.nearest_id)}</p><p>المسافة: ${esc(formatDistance(analysis.distance_m))} · ${esc(analysis.zone)}</p><p>الموقع المرجعي: <span dir="ltr">${analysis.nearest_lat.toFixed(6)}, ${analysis.nearest_lon.toFixed(6)}</span></p><p>المصدر: غير متحقق</p><p>${analysis.reference_status==='NEAR_LEGACY_REFERENCE'?'داخل حد البحث المرجعي؛ لا يثبت دقة القياس':'خارج حد البحث المرجعي'}</p>`:'لا يوجد سجل مرجعي.';
  $('resultSummary').textContent=analysis.valid_analysis?'الفئة: '+analysis.priority_class_ar+' · أقرب سجل على '+formatDistance(analysis.distance_m):'لا توجد خلية مفعلة ضمن حد البحث. لا تُعرض درجة تقديرية.';
  const focusDistance=engine.distance(p.lat,p.lon,FOCUS.lat,FOCUS.lon);$('scopeStatus').textContent=focusDistance<=FOCUS.radius_m?'داخل دائرة الدراسة · 5 كم':'خارج دائرة الدراسة · '+formatDistance(Math.round(focusDistance))+' من المركز';
  renderEvidence();
  write(KEYS.prefs,{lat:p.lat,lon:p.lon,zoom:map.getZoom(),layer:map.getLayer()});
  $('savedCount').textContent='النقاط المحفوظة في هذا الإصدار: '+list(KEYS.saved).length;
 }
 function formatDistance(m){return typeof m==='number'?(m>=1000?(m/1000).toFixed(2)+' كم':m+' م'):'غير متاح';}
 let previousTab='analysis';const tabPositions={};
 function activate(tab){const scroller=$('tabScroller');tabPositions[activeTab]=scroller.scrollTop;activeTab=tab;document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.tab').forEach(s=>s.classList.toggle('active',s.id===tab));scroller.scrollTop=tabPositions[tab]||0;if(tab==='targets')renderTargets();if(tab==='field')renderField();}
 document.querySelectorAll('nav button').forEach(b=>b.addEventListener('click',()=>activate(b.dataset.tab)));
 $('settingsBtn').onclick=()=>{if(activeTab!=='settings')previousTab=activeTab;activate('settings');};$('backFromSettings').onclick=()=>activate(previousTab);
 $('legacyToggle').addEventListener('change',()=>{legacy=$('legacyToggle').checked;write('bouh_v77_show_legacy',legacy);update();if(activeTab==='targets')renderTargets();if(heatmap)refreshMarkers();});
 $('zoomIn').onclick=()=>map.setZoom(map.getZoom()+1);$('zoomOut').onclick=()=>map.setZoom(map.getZoom()-1);$('layerBtn').onclick=()=>$('layersDialog').showModal();$('closeLayers').onclick=()=>$('layersDialog').close();
 for(const [id,layer] of [['rgbLayer','rgb'],['swirLayer','swir'],['satelliteLayer','satellite']])$(id).onclick=()=>{map.setLayer(layer);update();$('layersDialog').close();};
 $('coordinateBtn').onclick=()=>{$('layersDialog').close();const p=map.getCenter();$('latitudeInput').value=p.lat.toFixed(6);$('longitudeInput').value=p.lon.toFixed(6);$('coordinatesDialog').showModal();};
 $('cancelCoordinates').onclick=()=>$('coordinatesDialog').close();
 $('coordinatesForm').onsubmit=e=>{e.preventDefault();const lat=Number($('latitudeInput').value),lon=Number($('longitudeInput').value);if(!BOUHEngine.validPoint(lat,lon)){toast('إحداثيات غير صالحة');return;}if(Math.abs(lat)>85.05112878){toast('عرض الخريطة متاح بين خطي عرض ±85.05');return;}map.setView(lat,lon);update();$('coordinatesDialog').close();};
 $('gpsBtn').onclick=()=>{$('layersDialog').close();
  if(!navigator.geolocation){toast('خدمة الموقع غير متاحة');return;}
  $('gpsAccuracy').textContent='جارٍ طلب الموقع…';
  navigator.geolocation.getCurrentPosition(pos=>{const c=pos.coords;if(!BOUHEngine.validPoint(c.latitude,c.longitude)){toast('قراءة GPS غير صالحة');return;}gpsFix={lat:c.latitude,lon:c.longitude,accuracy:typeof c.accuracy==='number'&&Number.isFinite(c.accuracy)&&c.accuracy>=0?c.accuracy:null};map.setGPS(gpsFix);map.setView(c.latitude,c.longitude,15);$('gpsAccuracy').textContent=gpsFix.accuracy===null?'GPS: الدقة غير متاحة':'GPS: دقة مُبلّغ عنها ±'+Math.round(gpsFix.accuracy)+' م';update();},err=>{$('gpsAccuracy').textContent='GPS: لم يُحصل على الموقع';toast(err.code===1?'إذن الموقع غير ممنوح':'تعذر تحديد الموقع الآن');},{enableHighAccuracy:true,timeout:15000,maximumAge:10000});
 };
 function renderTargets(){
  const p=map.getCenter(),sort=$('sort').value;if(sort==='reference'&&!legacy){$('targetList').innerHTML='<p class="note">فعّل عرض المؤشرات المرجعية من قسم التحليل لاستخدام ترتيبها.</p>';return;}
  const arr=engine.nearestTargets(p.lat,p.lon,{radius_m:Number($('radius').value),limit:20,sort,includeLegacy:legacy});
  $('targetList').innerHTML=arr.length?arr.map(r=>`<article class="target"><div class="target-head"><div><b>${esc(r.zone)}</b><small dir="ltr">${esc(r.nearest_id)}</small></div><button data-lat="${r.lat}" data-lon="${r.lon}">فتح</button></div><small>من المركز: ${esc(formatDistance(r.query_distance_m))} · مصدر غير متحقق</small><small>درجة مرجعية عند موقع السجل: ${r.reference_score===null?'مخفية':r.reference_score+'/100'}</small><small dir="ltr">${r.lat.toFixed(6)}, ${r.lon.toFixed(6)}</small></article>`).join(''):'<p class="muted">لا توجد سجلات ضمن النطاق المحدد.</p>';
 }
 $('targetList').onclick=e=>{const b=e.target.closest('button[data-lat]');if(b){map.setView(Number(b.dataset.lat),Number(b.dataset.lon),14);activate('analysis');update();}};
 $('refreshTargets').onclick=renderTargets;$('radius').onchange=renderTargets;$('sort').onchange=renderTargets;
 $('savePoint').onclick=()=>{update();if(!analysis.valid_analysis){toast('لا يمكن حفظ هدف خارج نطاق البيانات المفعلة');return;}const arr=list(KEYS.saved);arr.push({id:uid(),created_at:new Date().toISOString(),lat:analysis.lat,lon:analysis.lon,analysis});if(write(KEYS.saved,arr)){toast('حُفظت نقطة استطلاع؛ لم تُسجّل كاكتشاف ذهب');update();renderSaved();}};
 const draftFields=['fieldResult','fieldDevice','fieldMinutes','fieldArea','fieldOperator','fieldNotes'];
 const draft=read('bouh_v77_field_draft',{});if(draft&&typeof draft==='object')for(const id of draftFields){if(typeof draft[id]==='string')$(id).value=draft[id];}
 function saveDraft(){write('bouh_v77_field_draft',Object.fromEntries(draftFields.map(id=>[id,$(id).value])));}
 $('fieldForm').addEventListener('input',saveDraft);$('fieldForm').addEventListener('change',saveDraft);
 $('fieldForm').onsubmit=e=>{e.preventDefault();const p=map.getCenter(),duration=$('fieldMinutes').value,area=$('fieldArea').value,visits=list(KEYS.field);const allowed=['not_tested','surveyed_no_detection','signal_unconfirmed','reported_find'];if(!allowed.includes($('fieldResult').value))return;
  if((duration!==''&&(!Number.isFinite(Number(duration))||Number(duration)<0||Number(duration)>10000))||(area!==''&&(!Number.isFinite(Number(area))||Number(area)<0))){toast('أدخل مدة ومساحة صحيحتين دون قيم سالبة');return;}
  visits.push({id:uid(),created_at:new Date().toISOString(),lat:p.lat,lon:p.lon,gps_accuracy_m:gpsFix?gpsFix.accuracy:null,gps_location:gpsFix,status:$('fieldResult').value,device:$('fieldDevice').value.trim(),operator:$('fieldOperator').value.trim(),duration_minutes:duration===''?null:Number(duration),survey_area_m2:area===''?null:Number(area),notes:$('fieldNotes').value.trim(),verification_status:'user_report_unverified',analysis:engine.analyze(p.lat,p.lon,{includeLegacy:legacy})});
  if(write(KEYS.field,visits)){toast('حُفظت الزيارة دون تغيير الدرجات');$('fieldNotes').value='';$('fieldMinutes').value='';$('fieldArea').value='';$('fieldResult').value='not_tested';saveDraft();renderField();}
 };
 const statusNames={not_tested:'لم يُفحص',surveyed_no_detection:'فُحص دون اكتشاف',signal_unconfirmed:'إشارة غير مؤكدة',reported_find:'اكتشاف مُبلّغ عنه — غير متحقق'};
 function renderField(){const visits=list(KEYS.field);$('fieldList').innerHTML=visits.slice().reverse().slice(0,100).map(v=>`<article class="visit"><b>${esc(statusNames[v.status]||v.status)}</b><small>${esc(new Date(v.created_at).toLocaleString('ar'))}</small><small dir="ltr">${Number(v.lat).toFixed(6)}, ${Number(v.lon).toFixed(6)}</small><small>${esc(v.device||'الجهاز غير مسجل')} · ${v.duration_minutes===null?'المدة غير مسجلة':esc(v.duration_minutes)+' دقيقة'}</small><p>${esc(v.notes)}</p></article>`).join('')||'<p class="muted">لم تسجل زيارات في هذا الإصدار.</p>';}
 function showExport(filename,text,mime='application/json;charset=utf-8'){exportPayload={filename,text,mime};$('exportText').value=text;$('exportDialog').showModal();}
 function exportJSON(filename,payload){$('exportFormat').disabled=true;$('exportFormat').value='json';showExport(filename,JSON.stringify(payload,null,2));}
 let reportTargets=[];
 function openReport(targets){$('exportFormat').disabled=false;reportTargets=targets;$('exportFormat').value='html';refreshReport();}
 function refreshReport(){const format=$('exportFormat').value,center=map.getCenter(),mime={json:'application/json',csv:'text/csv',geojson:'application/geo+json',kml:'application/vnd.google-earth.kml+xml',html:'text/html'}[format];showExport('BOUH-78.0-report.'+format,engine.report(format,reportTargets,center),mime+';charset=utf-8');}
 $('exportFormat').onchange=refreshReport;
 $('exportAnalysis').onclick=()=>{update();openReport(analysis.valid_analysis?[{lat:analysis.lat,lon:analysis.lon,created_at:new Date().toISOString()}]:[]);};
 $('exportField').onclick=()=>exportJSON('BOUH-78.0-field.json',{engine_version:engine.version,visits:list(KEYS.field),legacy_visits_archived_unverified:list('bouh_field_evidence_v70')});
 $('exportAudit').onclick=()=>exportJSON('BOUH-78.0-data-audit.json',{...BOUH_DATA_AUDIT,operational:engine.summary()});
 $('exportSaved').onclick=()=>openReport(list(KEYS.saved));
 $('closeExport').onclick=()=>$('exportDialog').close();
 $('copyExport').onclick=async()=>{if(!exportPayload)return;try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(exportPayload.text);}else{$('exportText').focus();$('exportText').select();if(!document.execCommand('copy'))throw Error('copy');}toast('نُسخ النص كاملًا');}catch(e){$('exportText').focus();$('exportText').select();toast('النص محدد؛ استخدم أمر النسخ من جهازك');}};
 $('downloadExport').onclick=()=>{if(!exportPayload)return;
  if(window.BOUH&&typeof window.BOUH.writeExport==='function'){try{const r=JSON.parse(window.BOUH.writeExport(exportPayload.filename,exportPayload.text));if(r.ok){toast('حُفظ الملف: '+(r.path||exportPayload.filename));return;}}catch(e){}}
  try{const blob=new Blob([exportPayload.text],{type:exportPayload.mime}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=exportPayload.filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('طُلب تنزيل الملف؛ يتوفر أيضًا نسخ النص');}catch(e){toast('تعذر تنزيل الملف؛ استخدم نسخ النص');}
 };
 function renderEvidence(){const e=analysis.evidence_independence_summary||{},sens=analysis.weight_sensitivity_analysis||{};$('evidenceContent').innerHTML=analysis.valid_analysis?`<b dir="ltr">${esc(analysis.priority_class_code)}</b><p>عائلات داعمة: ${esc(e.positive_supporting_families_count??0)} · مجموعات مصدر داعمة: ${esc(e.positive_supporting_source_groups_count??0)}</p><p>${esc((analysis.contrary_evidence_ar||[]).join(' · '))}</p><p>نطاق الحساسية: ${esc(sens.min_score??'—')} – ${esc(sens.max_score??'—')} / 100</p><small>الأوزان والحراس افتراضات أولية غير معايرة. جودة البيانات ليست ثقة في اكتشاف الذهب.</small>`:'بيانات غير كافية؛ لا يوجد تفسير لدرجة غير متاحة.';}
 $('focusAreaBtn').onclick=()=>{$('layersDialog').close();map.setView(FOCUS.lat,FOCUS.lon,13);update();if(heatmap)refreshMarkers();};
 const zones={home:[19.973186,36.745590,13],center:[19.42,36.323,11],north:[20.65,36.6,10],south:[18.15,37.1,10]};
 for(const [name,p] of Object.entries(zones))$(name+'Btn').onclick=()=>{$('layersDialog').close();map.setView(...p);update();if(heatmap)refreshMarkers();};
 function refreshMarkers(){const p=map.getCenter();map.setMarkers(heatmap&&legacy?engine.nearestTargets(p.lat,p.lon,{radius_m:20000,limit:120,sort:'distance'}):[]);}
 $('heatmapBtn').onclick=()=>{$('layersDialog').close();heatmap=!heatmap;$('heatmapBtn').textContent=heatmap?'إخفاء علامات الدرجات':'إظهار علامات الدرجات';$('heatmapBtn').setAttribute('aria-pressed',String(heatmap));refreshMarkers();toast(heatmap?'ألوان درجات مرجعية عند مواقع السجلات؛ ليست قياسات ذهب':'أُخفيت مؤشرات الخريطة');};
 $('missionBtn').onclick=()=>{$('layersDialog').close();const p=map.getCenter();mission=engine.nearestTargets(p.lat,p.lon,{radius_m:5000,limit:5,sort:'reference'});$('missionList').innerHTML=mission.length?mission.map((r,i)=>`<article class="target"><b>${i+1}. ${esc(r.nearest_id)}</b><small>${esc(formatDistance(r.query_distance_m))} · ${esc(r.direction_ar)} · أولوية ${r.reference_score}/100</small><small dir="ltr">${r.lat.toFixed(6)}, ${r.lon.toFixed(6)}</small><p>وثّق GPS والجهاز والمدة والمساحة والنتيجة. لا ترفع الدرجة بمجرد تسجيل زيارة.</p></article>`).join(''):'لا توجد أهداف مفعلة ضمن 5 كم. غيّر مركز الخريطة.';$('missionDialog').showModal();};
 $('closeMission').onclick=()=>$('missionDialog').close();$('exportMission').onclick=()=>{$('missionDialog').close();openReport(mission);};
 function renderSaved(){const arr=list(KEYS.saved);$('savedList').innerHTML=arr.length?'<h3>نقاطك المحفوظة</h3>'+arr.slice(-100).reverse().map(r=>`<article class="target"><button data-saved-id="${esc(r.id)}">فتح</button><small dir="ltr">${Number(r.lat).toFixed(6)}, ${Number(r.lon).toFixed(6)}</small><small>يُعاد حساب التقييم عند الفتح والتصدير</small></article>`).join(''):'';}
 $('savedList').onclick=e=>{const b=e.target.closest('button[data-saved-id]');if(!b)return;const r=list(KEYS.saved).find(r=>r.id===b.dataset.savedId);if(r){map.setView(r.lat,r.lon,14);activate('analysis');update();}};
 $('backupBtn').onclick=()=>exportJSON('BOUH-78.0-backup.json',{schema:'BOUH_BACKUP_1',saved:list(KEYS.saved),visits:list(KEYS.field),display:read('bouh_v77_display',{}),exported_at:new Date().toISOString()});
 $('restoreFile').onchange=async()=>{const f=$('restoreFile').files&&$('restoreFile').files[0];if(!f)return;try{if(f.size>20000000)throw Error('size');const d=JSON.parse(await f.text());if(d.schema!=='BOUH_BACKUP_1'||!Array.isArray(d.saved)||!Array.isArray(d.visits))throw Error('schema');for(const row of [...d.saved,...d.visits])if(!row||typeof row!=='object'||!BOUHEngine.validPoint(row.lat,row.lon)||typeof row.id!=='string')throw Error('record');const merge=(old,rows)=>[...new Map([...old,...rows].map(r=>[r.id,r])).values()];if(write(KEYS.saved,merge(list(KEYS.saved),d.saved))&&write(KEYS.field,merge(list(KEYS.field),d.visits))){renderSaved();renderField();update();toast('استُعيدت البيانات بدمجها مع السجلات الحالية');}}catch(e){toast('ملف النسخ الاحتياطي غير صالح؛ لم تُستورد بياناته');}$('restoreFile').value='';};
 const q=engine.summary();$('qualityAudit').innerHTML='<b>نتيجة فحص السجلات</b><p>مدخلات غير صالحة مستبعدة: '+q.invalid_input_rows+'</p><p>إحداثيات مفعلة فريدة: '+q.unique_active_coordinates+'</p><p>تكرارات مكانية في الخلايا المفعلة: '+q.duplicate_active_coordinates+'</p><p>سجلات بها صفر في أحد المؤشرات الأساسية: '+q.rows_with_zero_core_indicators+'</p><p>الأصفار محفوظة دون تعويض. مصدر ومعالجة الشبكة القديمة غير متحققين. لا معايرة ميدانية ولا تقدير عمق.</p>';
 const a=BOUH_DATA_AUDIT,stats=[[a.raw_rows,'سجل موروث'],[engine.summary().active_cells,'خلية مرجعية مفعلة'],[engine.summary().quarantined_cells,'خلية ASTER محجورة'],[0,'سجل موثق للتحليل المعتمد']];
 $('auditFacts').innerHTML=stats.map(([n,label])=>`<div><b>${n.toLocaleString('en')}</b><small>${label}</small></div>`).join('');
 $('zoneList').innerHTML=Object.entries(a.zones).sort((x,y)=>y[1]-x[1]).map(([z,n])=>`<div class="zone"><span dir="ltr">${esc(z)}</span><span>${n.toLocaleString('en')}</span></div>`).join('');
 update();renderField();renderSaved();
 // A single read-only diagnostic entry point for tests and future wrappers.
 window.BOUH77={engine,getAnalysis:()=>engine.analyze(map.getCenter().lat,map.getCenter().lon,{includeLegacy:legacy}),setView:(lat,lon)=>{map.setView(lat,lon);update();},version:engine.version,getCenter:()=>map.getCenter(),getBounds:()=>map.getBounds(),setCloudTileLayer:value=>map.setCloudTileLayer(value),setCloudRasters:items=>map.setCloudRasters(items),setCloudAnomalies:fc=>map.setCloudAnomalies(fc),showCloudExport:(filename,text,mime)=>{$('exportFormat').disabled=true;showExport(filename,text,mime);}};
})();
