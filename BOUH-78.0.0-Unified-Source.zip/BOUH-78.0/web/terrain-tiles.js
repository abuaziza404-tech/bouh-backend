/* Authenticated XYZ renderer for the existing native Canvas map. */
(function(root){
'use strict';
function create({baseUrl,area,revision,getToken,bbox,onError=()=>{}}){
 const base=new URL(baseUrl);
 if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash||base.pathname!=='/')throw Error('أدخل أصل خادم HTTPS دون مسار');
 if(!/^[A-Za-z0-9_-]{1,64}$/.test(area)||!/^[a-f0-9]{32}$/.test(revision))throw Error('تعريف طبقة غير صالح');
 if(!Array.isArray(bbox)||bbox.length!==4||!bbox.every(Number.isFinite)||bbox[0]>=bbox[2]||bbox[1]>=bbox[3])throw Error('حدود منطقة غير صالحة');
 const cache=new Map(),active=new Map();let dead=false,wake=()=>{},lastError=0,desired=new Set();
 function report(message){if(Date.now()-lastError>10000){lastError=Date.now();onError(message);}}
 async function load(key,row){
  const ac=new AbortController();active.set(key,ac);const timeout=setTimeout(()=>ac.abort(),30000);let objectURL;
  try{
   const token=getToken();if(!token)throw Error('أدخل رمز الوصول للجلسة الحالية');
   const res=await fetch(base.origin+'/terrain/api/coverage/'+area+'/tiles/'+key+'.png?v='+revision,{headers:{Authorization:'Bearer '+token},signal:ac.signal});
   if(!res.ok)throw Error('تعذر جلب البلاطة: HTTP '+res.status);
   const blob=await res.blob();if(blob.size>1024*1024||!blob.type.startsWith('image/png'))throw Error('بلاطة غير صالحة');
   if(dead)return;
   const image=new Image();objectURL=URL.createObjectURL(blob);
   await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('مهلة فك الصورة')),8000);image.onload=()=>{clearTimeout(t);resolve();};image.onerror=()=>{clearTimeout(t);reject(Error('تعذر قراءة الصورة'));};image.src=objectURL;});
   if(!dead){row.image=image;row.state='ready';}
  }catch(e){row.state='failed';if(!dead&&desired.has(key))report(e.name==='AbortError'?'انتهت مهلة البلاطات؛ أعد متابعة المنطقة.':e.message);}
  finally{clearTimeout(timeout);if(objectURL)URL.revokeObjectURL(objectURL);active.delete(key);if(!dead)wake();}
 }
 return {
  draw(ctx,left,top,width,height,zoom,drawSoon){
   if(dead)return;wake=drawSoon;desired=new Set();const z=Math.floor(zoom),size=256*2**(zoom-z),limit=2**z;
   const nw=root.BOUHMap.project(bbox[3],bbox[0],z),se=root.BOUHMap.project(bbox[1],bbox[2],z);
   for(let y=Math.floor(top/size);y<=Math.floor((top+height)/size);y++)for(let x=Math.floor(left/size);x<=Math.floor((left+width)/size);x++){
    if(y<0||y>=limit)continue;const tx=((x%limit)+limit)%limit;
    if((tx+1)*256<nw.x||tx*256>se.x||(y+1)*256<nw.y||y*256>se.y)continue;
    const key=z+'/'+tx+'/'+y;desired.add(key);let row=cache.get(key);
    if(!row){row={state:'waiting'};cache.set(key,row);}
    // Touch entry for bounded least-recently-used eviction.
    cache.delete(key);cache.set(key,row);
    if(row.state==='ready')ctx.drawImage(row.image,x*size-left,y*size-top,size+.3,size+.3);
   }
   for(const [key,ac] of active)if(!desired.has(key))ac.abort();
   for(const key of desired){const row=cache.get(key);if(row.state==='waiting'&&active.size<3){row.state='loading';load(key,row);}}
   if(cache.size>80)for(const key of cache.keys()){if(cache.size<=80)break;if(!desired.has(key)&&!active.has(key))cache.delete(key);}
  },
  dispose(){dead=true;for(const ac of active.values())ac.abort();cache.clear();desired.clear();}
 };
}
root.BOUHTerrainTiles={create};
})(window);
