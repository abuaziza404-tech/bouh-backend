/* Canvas adapter for the actual WebView APK; Leaflet adapter is separate. */
(function(root){
'use strict';
const $=id=>document.getElementById(id),A=root.BOUHCloudAPI,UI=root.BOUH77;
let pending=null,busy=false,images=[],visible=true;
const KEY='bouh_coverage_job_v1';
function status(s){$('coverageStatus').textContent=s;}
function save(){localStorage.setItem(KEY,JSON.stringify(pending));}
function client(){return A.createClient({baseUrl:$('cloudUrl').value.trim().replace(/\/$/,''),getToken:()=>$('cloudToken').value.trim()});}
function buttons(){for(const id of ['coverageLoad','coverageRefresh','coverageResume'])$(id).disabled=busy;$('coverageResume').hidden=!pending;$('coverageForget').hidden=!pending;$('coverageForget').disabled=busy;$('coverageHide').disabled=!images.length;}
$('coverageLoad').onclick=async()=>{try{busy=true;buttons();const fc=await client().getJSON('/api/v1/coverage');if(fc.type!=='FeatureCollection')throw Error('استجابة مناطق غير صالحة');const select=$('coverageArea');select.textContent='';let n=0;for(const f of fc.features){if(f.properties?.processing_enabled!==true)continue;if(!/^[A-Za-z0-9_-]{1,64}$/.test(f.id))continue;const option=document.createElement('option');option.value=f.id;option.textContent=f.properties.name||f.id;select.appendChild(option);n++;}status('مناطق مفعلة للمعالجة: '+n+'؛ اختر منطقة ثم حدث الصور.');}catch(e){status(e.message);}finally{busy=false;buttons();}};
async function refresh(resume){
 if(busy)return;let urls=[];
 try{
  const apiUrl=$('cloudUrl').value.trim().replace(/\/$/,'');const c=client();
  if(!$('cloudToken').value.trim())throw Error('أدخل رمز الوصول أولًا');
  if(!resume){
   if(pending)throw Error('توجد مهمة محفوظة؛ استأنفها أولًا');
   const area=$('coverageArea').value;if(!/^[A-Za-z0-9_-]{1,64}$/.test(area))throw Error('اقرأ مناطق الخادم واختر إحداها');
   pending={apiUrl,area,key:A.newRequestKey()};save();
  }
  if(!pending||pending.apiUrl!==apiUrl)throw Error('راجع رابط الخادم للمهمة المحفوظة');
  busy=true;buttons();
  if(!pending.id){const job=await c.postJSON('/api/v1/coverage/'+pending.area+'/refresh',{key:pending.key});if(!/^[a-f0-9]{32}$/.test(job.job_id))throw Error('معرف مهمة غير صالح');pending.id=job.job_id;save();}
  const result=await c.resume(pending.id,{onProgress:j=>status(j.state==='queued'?'تحديث الصور في الانتظار':'جلب الحزم ومعالجتها على الخادم…')});
  const layers=result.metadata?.overlays;if(!Array.isArray(layers)||layers.length>3)throw Error('لا توجد طبقات صور صالحة في النتيجة');
  const next=[];
  for(const o of layers){
   if(o.projection!=='EPSG:3857'||!validBounds(o.bounds))throw Error('إسناد طبقة غير صالح');
   const url=new URL(o.url,apiUrl+'/');if(url.origin!==new URL(apiUrl).origin)throw Error('عنوان صورة خارج الخادم');
   const ac=new AbortController(),t=setTimeout(()=>ac.abort(),30000);
   let response;try{response=await fetch(url.href,{signal:ac.signal,headers:{Authorization:'Bearer '+$('cloudToken').value.trim()}});}finally{clearTimeout(t);}
   if(!response.ok)throw Error('تعذر تنزيل طبقة المؤشر: HTTP '+response.status);
   const blob=await response.blob();if(blob.size>8*1024*1024||!blob.type.startsWith('image/png'))throw Error('صورة غير صالحة أو كبيرة جدًا');
   const image=new Image(),blobUrl=URL.createObjectURL(blob);urls.push(blobUrl);
   await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('مهلة فتح الصورة')),15000);image.onload=()=>{clearTimeout(timer);resolve();};image.onerror=()=>{clearTimeout(timer);reject(Error('تعذر فتح الصورة'));};image.src=blobUrl;});
   next.push({image,bounds:o.bounds,layer:o.layer});
  }
  UI.setCloudRasters(next);images=next;visible=true;$('coverageHide').textContent='إخفاء صور المؤشرات';
  status('عُرضت '+next.length+' طبقات · تاريخ التصوير '+result.metadata.acquisition_datetime+' · أحمر للحديد، سماوي للهيدروكسيل، بني لنسبة القبعات الحديدية. ليست خريطة ذهب.');
  pending=null;save();
 }catch(e){status(e.message+(pending?' · المهمة محفوظة للاستئناف.':''));}
 finally{urls.forEach(u=>URL.revokeObjectURL(u));busy=false;buttons();}
}
function validBounds(b){return Array.isArray(b)&&b.length===2&&b.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))&&b[0][0]<b[1][0]&&b[0][1]<b[1][1]&&b[0][0]>=-85.06&&b[1][0]<=85.06&&b[0][1]>=-180&&b[1][1]<=180;}
try{pending=JSON.parse(localStorage.getItem(KEY)||'null');if(pending&&(!pending.area||!pending.key))pending=null;}catch{}
$('coverageForget').onclick=()=>{if(busy)return;pending=null;save();status('نُسيت المهمة على الجهاز؛ قد تستمر على الخادم.');buttons();};
$('coverageRefresh').onclick=()=>refresh(false);$('coverageResume').onclick=()=>refresh(true);
$('coverageHide').onclick=()=>{visible=!visible;UI.setCloudRasters(visible?images:[]);$('coverageHide').textContent=visible?'إخفاء صور المؤشرات':'إظهار صور المؤشرات';};
buttons();
})(window);
