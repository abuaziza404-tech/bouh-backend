(function(){
'use strict';
const $=id=>document.getElementById(id),S=window.BOUHSources,esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KEY='bouh_catalog_discovery_v1';let latest=null;
$('sourceProvider').innerHTML='<option value="all">جميع المصادر · بحث موحد</option>'+Object.entries(S.PROVIDERS).map(([id,p])=>`<option value="${id}">${esc(p.name)}</option>`).join('');$('sourceProvider').value='all';$('sourceExtent').value='regional';$('sourceCloud').value='20';
const end=new Date(),start=new Date(end);start.setUTCFullYear(start.getUTCFullYear()-1);$('sourceStart').value=start.toISOString().slice(0,10);$('sourceEnd').value=end.toISOString().slice(0,10);
function render(result){
 latest=result;const rows=result.records||[];$('sourceResults').innerHTML=rows.length?rows.map(r=>`<article class="target"><b>${esc(r.platform||r.collection)}</b><small dir="ltr">${esc(r.id)}</small><small>التصوير: ${esc(r.datetime||'غير محدد')}</small><small>سحب المشهد: ${r.cloud_cover_scene_pct===null?'غير متاحة':esc(r.cloud_cover_scene_pct)+'%'} · ملفات مدرجة: ${Object.keys(r.assets).length}</small><small>قناع SCL: ${r.has_scl_asset?'مدرج':'لم يظهر'} · QA_PIXEL: ${r.has_qa_pixel_asset?'مدرج':'لم يظهر'} · QA_RADSAT: ${r.has_qa_radsat_asset?'مدرج':'لم يظهر'}</small><small>حالة البيانات: مفهرسة فقط · لم تُنزّل أو تُعالج</small></article>`).join(''):'<p class="muted">لم تظهر منتجات مستوفية للتصفية في هذه الصفحة. لا يعني ذلك عدم وجود بيانات في الأرشيف.</p>';
 $('sourceStatus').textContent=`جُلبت ميتاداتا ${rows.length} منتجًا · ${result.has_more?'توجد صفحات إضافية لم تُجلب':'نهاية الصفحة المتاحة'} · آخر جلب: ${result.metadata_observed_at}. لم تُنزّل ملفات راستر.`;
 if(result.provider_results)$('sourceStatus').textContent+=' مصادر نجحت: '+result.provider_results.length+'؛ تعذرت: '+(result.provider_failures||[]).length+'. المنتجات قد تتكرر عبر الفهارس؛ لم يُدمج دليلها في الدرجة.';
}
try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved&&saved.schema==='BOUH_CATALOG_DISCOVERY_1'&&Array.isArray(saved.records)){render(saved);$('sourceStatus').textContent='نتائج محفوظة من '+saved.metadata_observed_at+'؛ اضغط بحثًا لتحديثها.';}}catch(e){}
$('sourceSearch').onclick=async()=>{
 $('sourceSearch').disabled=true;$('sourceStatus').textContent='جارٍ الاستعلام من المصدر…';
 try{
  const regional=$('sourceExtent').value==='regional',bbox=regional?S.REGIONAL_BBOX:S.focusBBox();
  const provider=$('sourceProvider').value;const options={bbox,start:$('sourceStart').value,end:$('sourceEnd').value,maxCloud:Number($('sourceCloud').value),limit:30,extentNote:regional?'PROVISIONAL_REGIONAL_ENVELOPE; place boundaries and Amur location not verified':'Bounding box of user 5km circle; not exact circle filtering'};
  const result=provider==='all'?await S.searchAll(options,undefined,(done,total)=>{$('sourceStatus').textContent='جارٍ بحث المصادر '+done+' / '+total;}):await S.search(provider,options);
  render(result);try{localStorage.setItem(KEY,JSON.stringify(result));}catch(e){$('sourceStatus').textContent+=' تعذر حفظ النتائج محليًا؛ صدّرها الآن.';}
 }catch(e){$('sourceStatus').textContent='تعذر البحث: '+(String(e.message).startsWith('HTTP_')?e.message:e.message==='INVALID_DATE_RANGE'?'راجع المدى الزمني':e.message==='INVALID_STAC_RESPONSE'?'استجابة المصدر غير متوافقة':'اتصال أو سماح وصول المتصفح؛ قد يحتاج المصدر خادم ربط')+'. '+(latest?'النتائج السابقة محفوظة بتاريخ '+latest.metadata_observed_at:'لم تُجلب منتجات.')+' لم تتغير درجات التحليل.';}
 finally{$('sourceSearch').disabled=false;}
};
$('sourceExport').onclick=()=>{if(!latest){$('sourceStatus').textContent='لا توجد نتائج بحث لتصديرها بعد.';return;}
 const text=JSON.stringify(latest,null,2),name='BOUH-catalog-discovery.json';
 if(window.BOUH&&typeof window.BOUH.writeExport==='function'){try{const r=JSON.parse(window.BOUH.writeExport(name,text));if(r.ok){$('sourceStatus').textContent='حُفظ فهرس النتائج: '+(r.path||name);return;}}catch(e){}}
 try{const blob=new Blob([text],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);$('sourceStatus').textContent='طُلب تنزيل ملف الميتاداتا؛ لا يحتوي صور راستر.';}catch(e){$('sourceStatus').textContent='تعذر تنزيل الفهرس من هذه البيئة.';}
};
window.BOUHSourcePanel={getLatest:()=>latest};
})();
