/* Public catalogue discovery only. No imagery is downloaded or scored here. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BOUHSources=api;})(typeof window==='undefined'?globalThis:window,function(){
'use strict';
const PROVIDERS=Object.freeze({
 earth_s2_c1:{name:'Sentinel-2 L2A · Earth Search C1',endpoint:'https://earth-search.aws.element84.com/v1',collection:'sentinel-2-c1-l2a',kind:'optical',documentation:'https://registry.opendata.aws/sentinel-2-l2a-cogs/'},
 earth_s2:{name:'Sentinel-2 L2A · Earth Search',endpoint:'https://earth-search.aws.element84.com/v1',collection:'sentinel-2-l2a',kind:'optical',documentation:'https://registry.opendata.aws/sentinel-2-l2a-cogs/'},
 earth_landsat:{name:'Landsat C2 L2 · Earth Search',endpoint:'https://earth-search.aws.element84.com/v1',collection:'landsat-c2-l2',kind:'optical',documentation:'https://earth-search.aws.element84.com/v1/collections/landsat-c2-l2'},
 earth_dem:{name:'Copernicus DEM GLO-30 · Earth Search',endpoint:'https://earth-search.aws.element84.com/v1',collection:'cop-dem-glo-30',kind:'elevation',documentation:'https://registry.opendata.aws/copernicus-dem/'},
 cdse_s1:{name:'Sentinel-1 GRD · Copernicus',endpoint:'https://stac.dataspace.copernicus.eu/v1',collection:'sentinel-1-grd',kind:'radar',documentation:'https://documentation.dataspace.copernicus.eu/APIs/STAC.html'},
 cdse_s2:{name:'Sentinel-2 L2A · Copernicus',endpoint:'https://stac.dataspace.copernicus.eu/v1',collection:'sentinel-2-l2a',kind:'optical',documentation:'https://documentation.dataspace.copernicus.eu/APIs/STAC.html'}
});
const REGIONAL_BBOX=Object.freeze([35.5,18,38,21]);
function bboxValid(b){return Array.isArray(b)&&b.length===4&&b.every(Number.isFinite)&&b[0]>=-180&&b[2]<=180&&b[1]>=-90&&b[3]<=90&&b[0]<b[2]&&b[1]<b[3];}
function focusBBox(lat=18.8888,lon=37.18893,radius=5000){const dy=radius/111000,dx=dy/Math.cos(lat*Math.PI/180);return [lon-dx,lat-dy,lon+dx,lat+dy];}
function queryUrl(providerId,options={}){
 const p=PROVIDERS[providerId];if(!p)throw Error('UNKNOWN_PROVIDER');const bbox=options.bbox||REGIONAL_BBOX;if(!bboxValid(bbox))throw Error('INVALID_BBOX');
 const url=new URL(p.endpoint+'/search');url.searchParams.set('collections',p.collection);url.searchParams.set('bbox',bbox.join(','));url.searchParams.set('limit',String(Math.max(1,Math.min(100,Math.trunc(Number(options.limit)||30)))));
 if(p.kind!=='elevation'){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(options.start||'')||!/^\d{4}-\d{2}-\d{2}$/.test(options.end||''))throw Error('INVALID_DATE_RANGE');
  const start=Date.parse(options.start+'T00:00:00Z'),end=Date.parse(options.end+'T23:59:59Z');
  if(!Number.isFinite(start)||!Number.isFinite(end)||new Date(start).toISOString().slice(0,10)!==options.start||new Date(end).toISOString().slice(0,10)!==options.end||start>end||end>Date.now()+86400000)throw Error('INVALID_DATE_RANGE');
  url.searchParams.set('datetime',options.start+'T00:00:00Z/'+options.end+'T23:59:59Z');
  url.searchParams.set('sortby','-datetime');
 }
 return url.href;
}
function cleanHref(value){try{const u=new URL(value);return u.protocol==='https:'?u.href:null;}catch(e){return null;}}
function finiteOrNull(v){return typeof v==='number'&&Number.isFinite(v)?v:null;}
function normalizeItem(item,providerId){
 const p=PROVIDERS[providerId];if(!p||!item||item.type!=='Feature'||typeof item.id!=='string'||!item.properties||!item.geometry||!Array.isArray(item.bbox)||![4,6].includes(item.bbox.length)||!bboxValid([item.bbox[0],item.bbox[1],item.bbox[item.bbox.length===6?3:2],item.bbox[item.bbox.length===6?4:3]]))return null;
 const props=item.properties,assets={};for(const [key,a] of Object.entries(item.assets||{})){
  if(!a||typeof a!=='object')continue;const rb=Array.isArray(a['raster:bands'])?a['raster:bands']:[];
  assets[key]={href:cleanHref(a.href),type:typeof a.type==='string'?a.type:null,roles:Array.isArray(a.roles)?a.roles:[],bands:a['eo:bands']||a.bands||null,raster_bands:rb.map(b=>({scale:finiteOrNull(b.scale),offset:finiteOrNull(b.offset),nodata:b.nodata??null,data_type:b.data_type||null,spatial_resolution:finiteOrNull(b.spatial_resolution)})),gsd:finiteOrNull(a.gsd),proj_code:a['proj:code']||a['proj:epsg']||null};
 }
 const keys=Object.keys(assets);return {id:item.id,collection:item.collection||p.collection,provider_id:providerId,provider_name:p.name,datetime:props.datetime||props.start_datetime||null,bbox:item.bbox,geometry:item.geometry,cloud_cover_scene_pct:finiteOrNull(props['eo:cloud_cover']),native_gsd:finiteOrNull(props.gsd),proj_code:props['proj:code']||props['proj:epsg']||null,platform:props.platform||null,assets,
  has_scl_asset:keys.some(k=>/^scl$|scene.?classification/i.test(k)),has_qa_pixel_asset:keys.some(k=>/qa.?pixel/i.test(k)),has_qa_radsat_asset:keys.some(k=>/qa.?radsat/i.test(k)),
  acquisition_status:'CATALOGUED',download_status:'NOT_DOWNLOADED',processing_status:'NOT_PROCESSED',qa_mask_applied:false,field_validation_status:'UNVALIDATED',core_score:null,
  metadata_observed_at:new Date().toISOString(),metadata_links:(item.links||[]).filter(l=>l.rel==='self'||l.rel==='license').map(l=>({rel:l.rel,href:cleanHref(l.href)}))};
}
async function search(providerId,options={},fetchImpl){
 const requestUrl=queryUrl(providerId,options),doFetch=fetchImpl||(typeof fetch==='function'?fetch:null);if(!doFetch)throw Error('FETCH_UNAVAILABLE');
 const controller=typeof AbortController!=='undefined'?new AbortController():null,timer=controller?setTimeout(()=>controller.abort(),25000):null;
 try{
  const response=await doFetch(requestUrl,{method:'GET',headers:{Accept:'application/geo+json, application/json'},credentials:'omit',...(controller?{signal:controller.signal}:{})});
  if(!response.ok)throw Error('HTTP_'+response.status);const data=await response.json();if(data.type!=='FeatureCollection'||!Array.isArray(data.features))throw Error('INVALID_STAC_RESPONSE');
  const bbox=options.bbox||REGIONAL_BBOX,raw=data.features.map(f=>normalizeItem(f,providerId)).filter(Boolean);
  const overlap=r=>{const b=r.bbox,e=b.length===6?[b[0],b[1],b[3],b[4]]:b;return e[0]<=bbox[2]&&e[2]>=bbox[0]&&e[1]<=bbox[3]&&e[3]>=bbox[1];};
  const records=raw.filter(overlap).filter(r=>r.cloud_cover_scene_pct===null||r.cloud_cover_scene_pct<=(Number.isFinite(options.maxCloud)?options.maxCloud:100));
  return {schema:'BOUH_CATALOG_DISCOVERY_1',provider_id:providerId,request_url:requestUrl,bbox,search_extent_note:options.extentNote||'Catalogue search extent; not a verified coverage footprint',start:options.start||null,end:options.end||null,metadata_observed_at:new Date().toISOString(),returned_items:data.features.length,invalid_items:data.features.length-raw.length,filtered_items:raw.length-records.length,records,has_more:Array.isArray(data.links)&&data.links.some(l=>l.rel==='next'),number_matched:finiteOrNull(data.numberMatched)??finiteOrNull(data.context&&data.context.matched),raster_files_downloaded:0,raw_processing_executed:false};
 }finally{if(timer)clearTimeout(timer);}
}
async function searchAll(options={},fetchImpl,onProgress){
 const results=[],failures=[],ids=Object.keys(PROVIDERS);
 // Bound concurrency to two requests to avoid overwhelming a mobile connection.
 let cursor=0,completed=0;
 async function worker(){while(cursor<ids.length){const id=ids[cursor++];try{results.push(await search(id,options,fetchImpl));}catch(e){failures.push({provider_id:id,error:String(e.message||e)});}completed++;if(onProgress)onProgress(completed,ids.length);}}
 await Promise.all([worker(),worker()]);
 if(!results.length)throw Error('ALL_PROVIDERS_FAILED');
 return {schema:'BOUH_CATALOG_DISCOVERY_1',provider_id:'all',metadata_observed_at:new Date().toISOString(),bbox:options.bbox||REGIONAL_BBOX,records:results.flatMap(r=>r.records),has_more:results.some(r=>r.has_more),provider_results:results.map(r=>({provider_id:r.provider_id,returned_items:r.returned_items,has_more:r.has_more})),provider_failures:failures,partial_success:failures.length>0,raster_files_downloaded:0,raw_processing_executed:false};
}
return Object.freeze({PROVIDERS,REGIONAL_BBOX,focusBBox,bboxValid,queryUrl,normalizeItem,search,searchAll});
});
