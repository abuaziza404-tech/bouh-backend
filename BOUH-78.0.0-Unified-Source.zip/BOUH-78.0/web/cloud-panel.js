/* Cloud bridge panel: durable job identifiers, session-only credentials. */
(function(root){
'use strict';
const $=id=>document.getElementById(id),UI=root.BOUH77,G=root.BOUHCloudGeometry,A=root.BOUHCloudAPI;
const KEYS={url:'bouh_cloud_url_v1',pending:'bouh_cloud_pending_v1',result:'bouh_cloud_result_v1'};
let pending=null,latest=null,busy=false,controller=null,visible=true;
function read(key){try{return JSON.parse(localStorage.getItem(key)||'null');}catch{return null;}}
function persist(key,value,required=false){try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{if(required)throw Error('تعذر حفظ معرف المهمة؛ صدّر بياناتك أو حرّر مساحة قبل بدء تحليل جديد');return false;}}
function remove(key){try{localStorage.removeItem(key);}catch{try{localStorage.setItem(key,'null');}catch{}}}
function say(text){$('cloudStatus').textContent=text;}
function buttons(){
 $('cloudAnalyze').disabled=busy||!!pending;
 $('cloudResume').hidden=!pending;$('cloudResume').disabled=busy;
 $('cloudForget').hidden=!pending;$('cloudForget').disabled=busy;
 $('cloudStop').hidden=!busy;
 for(const id of ['cloudKml','cloudGeojson','cloudToggle'])$(id).disabled=!latest||busy;
 $('cloudUrl').disabled=busy;$('cloudExtent').disabled=busy;
}
function validatePayload(payload){
 const b=payload.bbox;if(!Array.isArray(b)||b.length!==4||!b.every(Number.isFinite))throw Error('حدود المنطقة غير صالحة');
 const [w,s,e,n]=b;
 if(w< -180||e>180||s< -60||n>75||w>=e||s>=n)throw Error('منطقة خارج النطاق المدعوم');
 const area=(e-w)*111.32*Math.cos((s+n)/2*Math.PI/180)*(n-s)*111.32;
 if(e-w>.2||n-s>.2||area<.05||area>150)throw Error('كبّر الخريطة؛ المساحة المدعومة بين 0.05 و150 كم² وكل ضلع أقل من 0.2 درجة');
 const start=Date.parse(payload.start_date+'T00:00:00Z'),end=Date.parse(payload.end_date+'T00:00:00Z'),days=(end-start)/86400000;
 if(!Number.isFinite(days)||days<1||days>45||end>Date.now())throw Error('اختر فترة صحيحة من يوم إلى 45 يومًا دون تاريخ مستقبلي');
 return payload;
}
function payload(){
 const center=UI.getCenter();let bbox;
 if($('cloudExtent').value==='viewport')bbox=UI.getBounds();
 else{const dy=5/111.32,dx=5/(111.32*Math.cos(center.lat*Math.PI/180));bbox=[center.lon-dx,center.lat-dy,center.lon+dx,center.lat+dy];}
 return validatePayload({bbox,start_date:$('cloudStart').value,end_date:$('cloudEnd').value,min_tier:Number($('cloudTier').value)||1,include_proxy_layers:$('cloudProxies').checked});
}
function render(record){
 G.validateGeoJSON(record.fc);latest=record;visible=true;
 const count=UI.setCloudAnomalies(record.fc);$('cloudLegend').hidden=false;
 const groups={ferric:0,hydroxyl:0,intersection:0};
 for(const f of record.fc.features)groups[f.properties.evidence_kind]++;
 $('cloudResultInfo').textContent=`نتيجة محفوظة في ${record.received_at} · ${count} جزء مضلع · حديد ${groups.ferric} · هيدروكسيل ${groups.hydroxyl} · تقاطعات ${groups.intersection}. تبسيط هندسي 5م؛ لا يعني دقة موقع الذهب.`;
 $('cloudToggle').textContent='إخفاء الطبقات';buttons();
}
function makeClient(url){return A.createClient({baseUrl:url,getToken:()=>$('cloudToken').value.trim()});}
async function run(resume){
 if(busy)return;
 if(typeof root.AbortController!=='function'){say('حدّث Android System WebView لدعم الاتصال القابل للإيقاف');return;}
 let ac=null;
 try{
  const url=$('cloudUrl').value.trim().replace(/\/$/,'');
  const client=makeClient(url);
  if(!$('cloudToken').value.trim())throw Error('أدخل رمز الوصول الشخصي في إعداد الاتصال');
  if(resume){if(!pending)throw Error('لا توجد مهمة محفوظة');if(pending.apiUrl!==url)throw Error('رابط الخادم مختلف عن المهمة المحفوظة؛ أعد رابطها أولًا');}
  else{
   if(pending)throw Error('استأنف المهمة الحالية أو انسها على الجهاز أولًا');
   pending={apiUrl:url,key:A.newRequestKey(),payload:payload(),created_at:new Date().toISOString()};
   // Durability before networking prevents duplicate paid jobs after a lost reply.
   try{persist(KEYS.pending,pending,true);}catch(e){pending=null;throw e;}
  }
  persist(KEYS.url,url);busy=true;ac=new AbortController();controller=ac;buttons();
  if(!pending.job_id){
   say('جارٍ إنشاء المهمة على الخادم…');
   const job=await client.create(pending.payload,{signal:ac.signal,key:pending.key});
   if(!/^[0-9a-f]{32}$/.test(job.job_id))throw Error('أعاد الخادم معرف مهمة غير صالح');
   pending={...pending,job_id:job.job_id};persist(KEYS.pending,pending,true);
  }
  const jobId=pending.job_id;
  const fc=await client.resume(jobId,{signal:ac.signal,onProgress:job=>say((job.state==='queued'?'المهمة في انتظار التنفيذ':'تجري معالجة GEE على الخادم')+' · '+jobId)});
  const record={fc,job_id:jobId,apiUrl:url,received_at:new Date().toISOString()};
  render(record);
  if(!persist(KEYS.result,record)){
   say('وصلت النتيجة، لكن تعذر حفظها محليًا؛ صدّر KML الآن. تبقى المهمة قابلة للاستئناف.');
  }else{remove(KEYS.pending);pending=null;say('وصلت النتائج وحُفظت. الألوان أدلة طيفية غير متحققة ميدانيًا؛ الدرجات المرجعية لم تتغير.');}
 }catch(e){
  const message=e.name==='AbortError'?'توقفت المتابعة على الهاتف؛ المهمة قد تستمر على الخادم. استخدم استئناف المهمة.':
   e.status===401?'رفض الخادم رمز الوصول؛ راجع الرمز.':e.status===429?'طابور الخادم ممتلئ؛ انتظر ثم استأنف.':
   /fetch|Network|Failed to fetch/i.test(e.message)?'تعذر الاتصال. راجع الإنترنت ورابط HTTPS وسماح CORS للخادم بالأصل null.':e.message;
  say(message+(pending?' · معرف المهمة أو مفتاح الاستئناف محفوظ.':''));
 }finally{busy=false;controller=null;buttons();}
}
const savedUrl=read(KEYS.url);if(typeof savedUrl==='string')$('cloudUrl').value=savedUrl;
const now=new Date(),end=now.toISOString().slice(0,10),start=new Date(now.getTime()-30*86400000).toISOString().slice(0,10);
$('cloudStart').value=start;$('cloudEnd').value=end;
pending=read(KEYS.pending);if(pending&&(!pending.key||!pending.payload||typeof pending.apiUrl!=='string')){pending=null;remove(KEYS.pending);}
if(pending){$('cloudUrl').value=pending.apiUrl;say('توجد مهمة محفوظة؛ أدخل رمز الوصول ثم اضغط استئناف.');}
const cached=read(KEYS.result);if(cached){try{render(cached);if(!pending)say('تُعرض آخر نتيجة محفوظة؛ لم يبدأ تحليل جديد.');}catch{say('تعذر قراءة النتيجة المحفوظة؛ صدّر نسخة سليمة أو أعد التحليل.');}}
$('cloudAnalyze').onclick=()=>run(false);$('cloudResume').onclick=()=>run(true);
$('cloudStop').onclick=()=>controller&&controller.abort();
$('cloudForget').onclick=()=>{if(busy)return;pending=null;remove(KEYS.pending);say('نُسيت المهمة على الجهاز فقط؛ قد تستمر على الخادم.');buttons();};
$('cloudToggle').onclick=()=>{if(!latest)return;visible=!visible;UI.setCloudAnomalies(visible?latest.fc:null);$('cloudToggle').textContent=visible?'إخفاء الطبقات':'إظهار الطبقات';$('cloudLegend').hidden=!visible;};
$('cloudKml').onclick=()=>{if(latest)UI.showCloudExport('BOUH-cloud-'+latest.job_id+'.kml',G.geojsonToKml(latest.fc),'application/vnd.google-earth.kml+xml;charset=utf-8');};
$('cloudGeojson').onclick=()=>{if(latest)UI.showCloudExport('BOUH-cloud-'+latest.job_id+'.geojson',JSON.stringify(latest.fc),'application/geo+json;charset=utf-8');};
root.BOUHCloudPanel={getPending:()=>pending,getLatest:()=>latest,isBusy:()=>busy,validatePayload};buttons();
})(window);
