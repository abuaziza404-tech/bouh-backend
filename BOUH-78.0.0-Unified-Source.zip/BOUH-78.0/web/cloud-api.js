(function(root){
'use strict';
/** Timeout-safe requests; POST creates a job, GET retrieves a FeatureCollection. */
const {validateGeoJSON}=root.BOUHCloudGeometry;
class APIError extends Error {
  constructor(message,status=0){ super(message); this.name='APIError'; this.status=status; }
}
function newRequestKey(){
  // Correlation/idempotency identifier, not a security credential.
  return `bouh_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}_${Math.random().toString(36).slice(2)}`;
}
function abortError(){ const e=new Error('Polling stopped; server job may continue');e.name='AbortError';return e; }
function wait(ms,signal){
  return new Promise((resolve,reject)=>{
    if(signal?.aborted)return reject(abortError());
    const cleanup=()=>signal?.removeEventListener('abort',cancel);
    const t=setTimeout(()=>{cleanup();resolve();},ms);
    function cancel(){clearTimeout(t);cleanup();reject(abortError());}
    signal?.addEventListener('abort',cancel,{once:true});
  });
}
function createClient({baseUrl,getToken,fetchImpl=fetch}){
  const base=new URL(baseUrl);
  if(base.protocol!=='https:')throw new Error('Use an HTTPS backend URL');
  if(base.username||base.password||base.search||base.hash)throw new Error('Invalid backend URL');
  const root=baseUrl.replace(/\/$/,'');
  async function request(path,{method='GET',body,signal,key,retries=3}={}){
    for(let attempt=0;;attempt++){
      if(signal?.aborted)throw abortError();
      const controller=new AbortController();
      const cancel=()=>controller.abort(); signal?.addEventListener('abort',cancel,{once:true});
      const timer=setTimeout(()=>controller.abort(),25000);
      let retryDelay=0;
      try{
        const token=await getToken();
        if(!token)throw new APIError('Enter your personal access token',401);
        const res=await fetchImpl(root+path,{method,signal:controller.signal,headers:{
          Authorization:`Bearer ${token}`,'Content-Type':'application/json',
          ...(key?{'Idempotency-Key':key}:{})},...(body?{body:JSON.stringify(body)}:{})});
        if(Number(res.headers?.get('content-length')||0)>2100000)throw new APIError('Response too large');
        const text=await res.text();
        if(text.length>2100000)throw new APIError('Response too large');
        let data;try{data=JSON.parse(text);}catch{throw new APIError('Server returned an invalid JSON response',res.status);}
        if(!res.ok){
          if([429,502,503,504].includes(res.status)&&attempt<retries){
            const after=Number(res.headers?.get('retry-after'));
            retryDelay=Number.isFinite(after)&&after>0?Math.min(after*1000,30000):1000*2**attempt;
          }else throw new APIError(typeof data.detail==='string'?data.detail:`API error ${res.status}`,res.status);
        }else return data;
      }catch(e){
        if(signal?.aborted)throw abortError();
        if(e instanceof APIError||attempt>=retries)throw e;
        retryDelay=1000*2**attempt; // Reuse the exact POST idempotency key.
      }finally{clearTimeout(timer);signal?.removeEventListener('abort',cancel);}
      await wait(retryDelay,signal);
    }
  }
  return {
    getJSON:(path,options={})=>request(path,options),
    postJSON:(path,{signal,key}={})=>request(path,{method:"POST",signal,key}),
    create:(payload,{signal,key=newRequestKey()}={})=>request('/api/v1/analyze-terrain',{method:'POST',body:payload,signal,key}),
    async resume(jobId,{signal,onProgress=()=>{},maxWaitMs=25*60*1000}={}){
      if(!/^[0-9a-f]{32}$/.test(jobId))throw new Error('Invalid job id');
      const deadline=Date.now()+maxWaitMs;
      while(Date.now()<deadline){
        const job=await request(`/api/v1/jobs/${jobId}`,{signal}); onProgress(job);
        if(job.state==='completed')return validateGeoJSON(await request(`/api/v1/jobs/${jobId}/result`,{signal}));
        if(job.state==='failed')throw new APIError(job.error_code||'Processing failed');
        if(!['queued','running'].includes(job.state))throw new APIError('Invalid job state');
        await wait(Math.max(3000,Math.min(15000,(job.poll_after_seconds||5)*1000)),signal);
      }
      throw new APIError(`Polling timed out. Resume job ${jobId}; do not create a duplicate.`);
    }
  };
}

root.BOUHCloudAPI={APIError,newRequestKey,wait,createClient};
})(window);
