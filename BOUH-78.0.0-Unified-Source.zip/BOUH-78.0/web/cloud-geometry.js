(function(root){
'use strict';
/** Pure geometry helpers, shared by native rendering, KML and tests. */
const COLORS = {
  ferric: {stroke:'#e4522d', fill:'rgba(228,82,45,0.23)', kml:'992d52e4'},
  hydroxyl: {stroke:'#16a6b6', fill:'rgba(22,166,182,0.23)', kml:'99b6a616'},
  intersection: {stroke:'#b77c00', fill:'rgba(245,185,40,0.32)', kml:'9928b9f5'}
};
function validateGeoJSON(fc) {
  if (!fc || fc.type !== 'FeatureCollection' || !Array.isArray(fc.features) || fc.features.length > 300)
    throw new Error('Invalid or oversized GeoJSON FeatureCollection');
  let vertices=0;
  for (const f of fc.features) {
    const g=f.geometry;
    if(f.type!=='Feature' || !g || !['Polygon','MultiPolygon'].includes(g.type))
      throw new Error('Unsupported geometry');
    if(!COLORS[f.properties?.evidence_kind]) throw new Error('Unknown evidence kind');
    const polygons=g.type==='Polygon'?[g.coordinates]:g.coordinates;
    if(!Array.isArray(polygons)||!polygons.length) throw new Error('Empty geometry');
    for(const poly of polygons) {
      if(!Array.isArray(poly)||!poly.length) throw new Error('Empty polygon');
      for(const ring of poly) {
        if(!Array.isArray(ring)||ring.length<4) throw new Error('Invalid ring');
        for(const p of ring) {
          if(++vertices>40000 || !Array.isArray(p) || p.length<2 ||
             !Number.isFinite(p[0]) || !Number.isFinite(p[1]) ||
             Math.abs(p[0])>180 || Math.abs(p[1])>90) throw new Error('Invalid coordinates');
        }
        if(ring[0][0]!==ring[ring.length-1][0]||ring[0][1]!==ring[ring.length-1][1]) throw new Error('Unclosed ring');
      }
    }
  }
  return fc;
}
function polygonsForMap(fc) {
  validateGeoJSON(fc);
  return fc.features.flatMap((f,i)=>{
    const polygons=f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates;
    const convert=ring=>ring.map(([longitude,latitude])=>({latitude,longitude}));
    return polygons.map((rings,j)=>({key:`${i}-${j}`,properties:f.properties,
      coordinates:convert(rings[0]),holes:rings.slice(1).map(convert),
      color:COLORS[f.properties.evidence_kind]}));
  });
}
const xml = value=>String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function geojsonToKml(fc) {
  validateGeoJSON(fc);
  const styles=Object.entries(COLORS).map(([id,c])=>`<Style id="${id}"><LineStyle><color>${c.kml}</color><width>2</width></LineStyle><PolyStyle><color>${c.kml}</color></PolyStyle></Style>`).join('');
  const ring = r=>`<LinearRing><coordinates>${r.map(p=>`${p[0]},${p[1]},0`).join(' ')}</coordinates></LinearRing>`;
  const polygon = rs=>`<Polygon><tessellate>1</tessellate><outerBoundaryIs>${ring(rs[0])}</outerBoundaryIs>${rs.slice(1).map(r=>`<innerBoundaryIs>${ring(r)}</innerBoundaryIs>`).join('')}</Polygon>`;
  const marks=fc.features.map((f,i)=>{
    const p=f.properties; const polys=f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates;
    const geom=polys.length===1?polygon(polys[0]):`<MultiGeometry>${polys.map(polygon).join('')}</MultiGeometry>`;
    const data=Object.entries(p).filter(([,v])=>v===null||['string','number','boolean'].includes(typeof v))
      .map(([k,v])=>`<Data name="${xml(k)}"><value>${xml(v)}</value></Data>`).join('');
    return `<Placemark><name>${xml(p.target_id||`BOUH ${i+1}`)}</name><description>${xml('Unvalidated spectral evidence; not a gold location or probability.')}</description><styleUrl>#${p.evidence_kind}</styleUrl><ExtendedData>${data}</ExtendedData>${geom}</Placemark>`;
  }).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>BOUH Terrain</name>${styles}${marks}</Document></kml>`;
}
function regionToBBox(r) {
  const w=r.longitude-r.longitudeDelta/2,e=r.longitude+r.longitudeDelta/2;
  const s=r.latitude-r.latitudeDelta/2,n=r.latitude+r.latitudeDelta/2;
  if(![w,s,e,n].every(Number.isFinite)||w>=e||s>=n||w< -180||e>180||s< -60||n>75)
    throw new Error('Invalid map extent');
  if(e-w>.2||n-s>.2) throw new Error('Zoom in: each side must be no wider than 0.2 degrees');
  return [w,s,e,n];
}

root.BOUHCloudGeometry={COLORS,validateGeoJSON,polygonsForMap,geojsonToKml,regionToBBox};
})(window);
