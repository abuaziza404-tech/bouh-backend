/** ES module: works with your existing Leaflet map, not an assumed global map. */
export function createCoverageLayerManager({map,L,apiUrl,getToken,fetchImpl=fetch}){
 const base=new URL(apiUrl);if(base.protocol!=='https:')throw Error('HTTPS required');
 const root=apiUrl.replace(/\/$/,'');let active=[],urls=[];
 async function request(path,options={}){
  const u=new URL(path,root+'/');if(u.origin!==base.origin)throw Error('Unexpected API origin');
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),30000);
  const cancel=()=>c.abort();options.signal?.addEventListener('abort',cancel,{once:true});
  try{
   if(options.signal?.aborted)throw Error('Stopped');
   const res=await fetchImpl(u.href,{...options,signal:c.signal,headers:{Authorization:`Bearer ${await getToken()}`,...options.headers}});
   if(!res.ok)throw Error(`HTTP ${res.status}`);return res;
  }finally{clearTimeout(timer);options.signal?.removeEventListener('abort',cancel);}
 }
 async function refresh(areaId,{signal,key,onJob=()=>{}}={}){
  if(!/^[A-Za-z0-9_-]{1,64}$/.test(areaId))throw Error('Invalid area id');
  if(!key)throw Error('Persist a unique Idempotency-Key before calling refresh');
  const job=await(await request(`/api/v1/coverage/${areaId}/refresh`,{method:'POST',headers:{'Idempotency-Key':key},signal})).json();
  await onJob(job);return resume(job.job_id,{signal});
 }
 async function resume(jobId,{signal}={}){
  if(!/^[0-9a-f]{32}$/.test(jobId))throw Error('Invalid job id');
  const deadline=Date.now()+25*60*1000;
  while(Date.now()<deadline){
   const status=await(await request(`/api/v1/jobs/${jobId}`,{signal})).json();
   if(status.state==='failed')throw Error(status.error_code||'Processing failed');
   if(status.state==='completed'){
    const result=await(await request(`/api/v1/jobs/${jobId}/result`,{signal})).json();
    await show(result,{signal});return result;
   }
   await sleep(5000,signal);
  }
  throw Error('Polling timed out; resume the saved job, do not create another');
 }
 async function show(result,{signal,append=false}={}){
  if(result.type!=='FeatureCollection'||!Array.isArray(result.metadata?.overlays))throw Error('Invalid overlay result');
  const next=[],newUrls=[];
  try{
   if(result.metadata.overlays.length>3)throw Error('Too many layers');
   for(const o of result.metadata.overlays){
    if(o.projection!=='EPSG:3857'||!validBounds(o.bounds))throw Error('Invalid overlay georeferencing');
    const response=await request(o.url,{signal});const blob=await response.blob();
    if(blob.size>8*1024*1024||!blob.type.startsWith('image/png'))throw Error('Invalid overlay image');
    const url=URL.createObjectURL(blob);newUrls.push(url);
    // Authentication is in fetch headers, never a token-bearing image URL.
    const layer=L.imageOverlay(url,o.bounds,{opacity:.75,interactive:false});
    next.push(layer);
    await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Image decode timeout')),15000);
      layer.once('load',()=>{clearTimeout(timer);resolve();});layer.once('error',()=>{clearTimeout(timer);reject(Error('Image decode failed'));});layer.addTo(map);});
   }
   if(!append)clear();active=active.concat(next);urls=urls.concat(newUrls);
  }catch(e){next.forEach(l=>map.removeLayer(l));newUrls.forEach(URL.revokeObjectURL);throw e;}
 }
 function clear(){active.forEach(l=>map.removeLayer(l));urls.forEach(URL.revokeObjectURL);active=[];urls=[];}
 return {refresh,resume,show,clear,coverage:async()=> (await request('/api/v1/coverage')).json()};
}
export function validBounds(b){return Array.isArray(b)&&b.length===2&&b.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))&&b[0][0]<b[1][0]&&b[0][1]<b[1][1]&&b[0][0]>=-85.06&&b[1][0]<=85.06&&b[0][1]>=-180&&b[1][1]<=180;}
function sleep(ms,signal){return new Promise((resolve,reject)=>{if(signal?.aborted)return reject(Error('Stopped'));const t=setTimeout(()=>{cleanup();resolve();},ms);function stop(){clearTimeout(t);cleanup();reject(Error('Stopped'));}function cleanup(){signal?.removeEventListener('abort',stop);}signal?.addEventListener('abort',stop,{once:true});});}

/** Automatic refresh ON APP OPEN, not a scheduled ChatGPT task.
 * Persist job key before networking; caches at most6h to limit repeated work.
 * Call once after the user configures HTTPS and authenticates.
 */
export async function syncEnabledCoverage(manager,{storage=localStorage,onJob=()=>{}}={}){
 const fc=await manager.coverage();const outputs=[];
 for(const f of fc.features){
  if(f.properties?.processing_enabled!==true)continue;
  const name='bouh_coverage_sync_'+f.id;let record;
  try{record=JSON.parse(storage.getItem(name)||'null');}catch{}
  if(record?.result && Date.now()-record.completed<6*3600000){await manager.show(record.result);outputs.push(record.result);continue;}
  if(!record||record.completed){record={key:'coverage_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2)};storage.setItem(name,JSON.stringify(record));}
  let result;
  if(record.jobId)result=await manager.resume(record.jobId);
  else result=await manager.refresh(f.id,{key:record.key,onJob:job=>{record.jobId=job.job_id;storage.setItem(name,JSON.stringify(record));onJob(job);}});
  record.result=result;record.completed=Date.now();storage.setItem(name,JSON.stringify(record));outputs.push(result);
 }
 for(let i=0;i<outputs.length;i++)await manager.show(outputs[i],{append:i>0});
 return outputs;
}
