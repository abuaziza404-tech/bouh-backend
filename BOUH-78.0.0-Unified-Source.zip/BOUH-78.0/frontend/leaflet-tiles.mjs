/** Authenticated XYZ tiles. Never put API tokens into image URLs. */
export async function prepareBOUHTiles({L,map,apiUrl,areaId,getToken,onStatus=()=>{}}){
 const base=new URL(apiUrl);if(base.protocol!=='https:')throw Error('HTTPS required');
 if(!/^[A-Za-z0-9_-]{1,64}$/.test(areaId))throw Error('Invalid area id');
 const root=apiUrl.replace(/\/$/,'');
 async function request(path,options={}){
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),30000);
  try{
   const res=await fetch(root+path,{...options,signal:c.signal,headers:{Authorization:`Bearer ${await getToken()}`}});
   if(!res.ok)throw Error(`HTTP ${res.status}`);return res;
  }finally{clearTimeout(timer);}
 }
 await request(`/terrain/api/coverage/${areaId}/refresh`,{method:'POST'});
 let status;const deadline=Date.now()+12*60000;
 while(Date.now()<deadline){
  status=await(await request(`/terrain/api/coverage/${areaId}/status`)).json();onStatus(status.state);
  if(status.state==='failed')throw Error(status.error||'Processing failed');
  if(status.state==='completed')break;
  await new Promise(resolve=>setTimeout(resolve,5000));
 }
 if(status?.state!=='completed')throw Error('Processing wait timed out; poll the existing area status');
 const aborters=new Set();
 const Layer=L.GridLayer.extend({
  createTile(coords,done){
   const img=document.createElement('img');img.alt='';img.width=256;img.height=256;
   const ac=new AbortController();aborters.add(ac);img._bouhAbort=ac;
   const timeout=setTimeout(()=>ac.abort(),30000);
   let blobUrl=null;
   (async()=>{
    try{
     const path=`/terrain/api/coverage/${areaId}/tiles/${coords.z}/${coords.x}/${coords.y}.png?v=${status.revision}`;
     const res=await fetch(root+path,{signal:ac.signal,headers:{Authorization:`Bearer ${await getToken()}`}});
     if(!res.ok)throw Error(`Tile HTTP ${res.status}`);
     const blob=await res.blob();if(blob.size>1024*1024||!blob.type.startsWith('image/png'))throw Error('Invalid tile response');
     blobUrl=URL.createObjectURL(blob);
     img.onload=()=>{clearTimeout(timeout);URL.revokeObjectURL(blobUrl);aborters.delete(ac);done(null,img);};
     img.onerror=()=>{clearTimeout(timeout);URL.revokeObjectURL(blobUrl);aborters.delete(ac);done(Error('Tile decode failed'),img);};
     img.src=blobUrl;
    }catch(e){clearTimeout(timeout);if(blobUrl)URL.revokeObjectURL(blobUrl);aborters.delete(ac);done(e,img);}
   })();
   return img;
  }
 });
 const layer=new Layer({tileSize:256,maxZoom:20,opacity:.8,updateWhenIdle:true,keepBuffer:1});
 layer.on('tileunload',e=>e.tile?._bouhAbort?.abort());
 layer.on('remove',()=>{aborters.forEach(c=>c.abort());aborters.clear();});
 layer.addTo(map);
 return {layer,metadata:status.manifest};
}
