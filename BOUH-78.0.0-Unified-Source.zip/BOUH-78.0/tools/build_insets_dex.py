#!/usr/bin/env python3
"""Emit the small MobileActivity adapter's DEX without requiring an Android SDK.

This is a narrowly scoped assembler, not a general Java compiler. The readable
equivalent is in android-src/.../MobileActivity.java. Original DEX is untouched.
References: AOSP dex-format and dalvik-bytecode specifications.
"""
from pathlib import Path
import struct, hashlib, zlib, json

P=lambda n:struct.pack('<I',n)
H=lambda n:struct.pack('<H',n)
def uleb(n):
    b=bytearray()
    while n>127:b.append((n&127)|128);n>>=7
    b.append(n);return bytes(b)

class Code:
    def __init__(self,methods,fields):self.w=[];self.labels={};self.fix=[];self.methods=methods;self.fields=fields
    def emit(self,*w):self.w.extend(w);return self
    def const(self,r,v):return self.emit(0x14|(r<<8),v&65535,(v>>16)&65535)
    def const16(self,r,v):return self.emit(0x13|(r<<8),v&65535)
    def invoke(self,op,m,args):
        regs=list(args)+[0]*(5-len(args));a,b,c,d,e=regs
        return self.emit(op|(len(args)<<12)|(e<<8),self.methods[m],a|(b<<4)|(c<<8)|(d<<12))
    def move(self,r,obj=False):return self.emit((0x0c if obj else 0x0a)|(r<<8))
    def sget(self,r,f,obj=False):return self.emit((0x62 if obj else 0x60)|(r<<8),self.fields[f])
    def iget(self,r,src,f):return self.emit(0x52|(r<<8)|(src<<12),self.fields[f])
    def label(self,n):self.labels[n]=len(self.w);return self
    def iflt(self,a,b,label):self.fix.append((len(self.w),label));return self.emit(0x34|(a<<8)|(b<<12),0)
    def goto(self,label):self.fix.append((len(self.w),label));return self.emit(0x29,0)
    def finish(self):
        for pos,label in self.fix:
            diff=self.labels[label]-pos;assert -32768<=diff<=32767;self.w[pos+1]=diff&65535
        return b''.join(H(x) for x in self.w)

def build(output):
    mobile='Lcom/bouh/terrainradar/MobileActivity;';main='Lcom/bouh/terrainradar/MainActivity;'
    activity='Landroid/app/Activity;';view='Landroid/view/View;';listener='Landroid/view/View$OnApplyWindowInsetsListener;'
    wi='Landroid/view/WindowInsets;';wt='Landroid/view/WindowInsets$Type;';ins='Landroid/graphics/Insets;';bundle='Landroid/os/Bundle;';window='Landroid/view/Window;';sdk='Landroid/os/Build$VERSION;'
    # Every method is (declaring type, name, return type, argument tuple).
    def m(c,n,r='V',*a):return (c,n,r,tuple(a))
    methods={m(mobile,'<init>'),m(main,'<init>'),m(mobile,'onCreate','V',bundle),m(main,'onCreate','V',bundle),m(activity,'findViewById',view,'I'),m(activity,'getWindow',window),m(view,'setOnApplyWindowInsetsListener','V',listener),m(view,'requestApplyInsets'),m(window,'setSoftInputMode','V','I'),m(mobile,'onApplyWindowInsets',wi,view,wi),m(wt,'systemBars','I'),m(wt,'displayCutout','I'),m(wi,'getInsets',ins,'I'),m(wi,'consumeSystemWindowInsets',wi),m(view,'setPadding','V','I','I','I','I')}
    for side in ['Left','Top','Right','Bottom']:methods.add(m(wi,'getSystemWindowInset'+side,'I'))
    fields={(sdk,'SDK_INT','I'),(wi,'CONSUMED',wi)}|{(ins,n,'I') for n in ['left','top','right','bottom']}
    types={mobile,main,activity,view,listener,wi,wt,ins,bundle,window,sdk,'V','I'}
    protos={(r,args) for _,_,r,args in methods}
    def short(t):return 'L' if t.startswith(('L','[')) else t
    def shorty(p):return short(p[0])+''.join(short(t) for t in p[1])
    strings=sorted(types|{n for _,n,_,_ in methods}|{n for _,n,_ in fields}|{shorty(p) for p in protos}|{'MobileActivity.java'})
    si={s:i for i,s in enumerate(strings)};types=sorted(types,key=si.get);ti={t:i for i,t in enumerate(types)}
    protos=sorted(protos,key=lambda p:(ti[p[0]],tuple(ti[t] for t in p[1])));pi={p:i for i,p in enumerate(protos)}
    methods=sorted(methods,key=lambda p:(ti[p[0]],si[p[1]],pi[(p[2],p[3])]));mi={m:i for i,m in enumerate(methods)}
    fields=sorted(fields,key=lambda p:(ti[p[0]],si[p[1]],ti[p[2]]));fi={f:i for i,f in enumerate(fields)}
    off=112;so=off;off+=4*len(strings);to=off;off+=4*len(types);po=off;off+=12*len(protos);fo=off;off+=8*len(fields);mo=off;off+=8*len(methods);co=off;off+=32
    dataoff=(off+3)&~3;b=bytearray(dataoff);maps=[]
    def align():b.extend(b'\0'*((-len(b))%4))
    # String data are ASCII in this adapter, and therefore valid modified UTF-8.
    sd=[];string_start=len(b)
    for s in strings:sd.append(len(b));b.extend(uleb(len(s))+s.encode()+b'\0')
    maps.append((0x2002,len(strings),string_start))
    typelists={};type_list_start=None
    for args in sorted({p[1] for p in protos if p[1]}|{(listener,)},key=lambda a:tuple(ti[t] for t in a)):
        align()
        if type_list_start is None:type_list_start=len(b)
        typelists[args]=len(b);b.extend(P(len(args))+b''.join(H(ti[t]) for t in args))
    maps.append((0x1001,len(typelists),type_list_start))
    ctor=Code(mi,fi).invoke(0x70,m(main,'<init>'),[0]).emit(0x0e)
    oncreate=Code(mi,fi).invoke(0x6f,m(main,'onCreate','V',bundle),[3,4]).const(0,0x01020002).invoke(0x6e,m(activity,'findViewById',view,'I'),[3,0]).move(0,True).invoke(0x6e,m(view,'setOnApplyWindowInsetsListener','V',listener),[0,3]).invoke(0x6e,m(view,'requestApplyInsets'),[0]).invoke(0x6e,m(activity,'getWindow',window),[3]).move(1,True).const16(2,16).invoke(0x6e,m(window,'setSoftInputMode','V','I'),[1,2]).emit(0x0e)
    apply=Code(mi,fi).sget(0,(sdk,'SDK_INT','I')).const16(1,30).iflt(0,1,'legacy')
    apply.invoke(0x71,m(wt,'systemBars','I'),[]).move(0).invoke(0x71,m(wt,'displayCutout','I'),[]).move(1).emit(0xb6|(0<<8)|(1<<12)).invoke(0x6e,m(wi,'getInsets',ins,'I'),[8,0]).move(4,True)
    for r,n in enumerate(['left','top','right','bottom']):apply.iget(r,4,(ins,n,'I'))
    apply.sget(5,(wi,'CONSUMED',wi),True).goto('padding').label('legacy')
    for r,n in enumerate(['Left','Top','Right','Bottom']):apply.invoke(0x6e,m(wi,'getSystemWindowInset'+n,'I'),[8]).move(r)
    apply.invoke(0x6e,m(wi,'consumeSystemWindowInsets',wi),[8]).move(5,True).label('padding').invoke(0x6e,m(view,'setPadding','V','I','I','I','I'),[7,0,1,2,3]).emit(0x11|(5<<8))
    definitions=[(m(mobile,'<init>'),0x10001,1,1,1,ctor),(m(mobile,'onCreate','V',bundle),0x4,5,2,2,oncreate),(m(mobile,'onApplyWindowInsets',wi,view,wi),0x1,9,3,5,apply)]
    codeoffs={};code_start=None
    for meth,flags,regs,inputs,outputs,code in sorted(definitions,key=lambda d:mi[d[0]]):
        align()
        if code_start is None:code_start=len(b)
        codeoffs[meth]=len(b);instructions=code.finish();b.extend(struct.pack('<4H2I',regs,inputs,outputs,0,0,len(instructions)//2)+instructions)
    maps.append((0x2001,len(definitions),code_start))
    classdataoff=len(b);direct=[x for x in definitions if x[0][1]=='<init>'];virtual=[x for x in definitions if x[0][1]!='<init>'];b.extend(uleb(0)+uleb(0)+uleb(len(direct))+uleb(len(virtual)))
    for arr in (direct,virtual):
        last=0
        for meth,flags,*_ in sorted(arr,key=lambda d:mi[d[0]]):idx=mi[meth];b.extend(uleb(idx-last)+uleb(flags)+uleb(codeoffs[meth]));last=idx
    maps.append((0x2000,1,classdataoff))
    align();mapoff=len(b)
    maps.extend([(0,1,0),(1,len(strings),so),(2,len(types),to),(3,len(protos),po),(4,len(fields),fo),(5,len(methods),mo),(6,1,co),(0x1000,1,mapoff)])
    maps.sort(key=lambda x:x[2]);b.extend(P(len(maps)))
    for kind,count,offset in maps:b.extend(struct.pack('<HHII',kind,0,count,offset))
    for i,pos in enumerate(sd):struct.pack_into('<I',b,so+4*i,pos)
    for i,t in enumerate(types):struct.pack_into('<I',b,to+4*i,si[t])
    for i,p in enumerate(protos):struct.pack_into('<III',b,po+12*i,si[shorty(p)],ti[p[0]],typelists.get(p[1],0))
    for i,(c,n,t) in enumerate(fields):struct.pack_into('<HHI',b,fo+8*i,ti[c],ti[t],si[n])
    for i,(c,n,r,a) in enumerate(methods):struct.pack_into('<HHI',b,mo+8*i,ti[c],pi[(r,a)],si[n])
    struct.pack_into('<8I',b,co,ti[mobile],1,ti[main],typelists[(listener,)],si['MobileActivity.java'],0,classdataoff,0)
    b[:8]=b'dex\n035\0'
    header=[len(b),112,0x12345678,0,0,mapoff,len(strings),so,len(types),to,len(protos),po,len(fields),fo,len(methods),mo,1,co,len(b)-dataoff,dataoff]
    struct.pack_into('<20I',b,32,*header);b[12:32]=hashlib.sha1(b[32:]).digest();struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
    output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(b)
    return {'adapter_class':mobile,'bytes':len(b),'method_definitions':len(definitions),'sha256':hashlib.sha256(b).hexdigest()}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();print(json.dumps(build(a.output),indent=2))
