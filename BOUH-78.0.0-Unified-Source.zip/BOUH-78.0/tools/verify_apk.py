#!/usr/bin/env python3
"""Verify ZIP, Android binary manifest, v1 content digests and APK v2 integrity."""
from pathlib import Path
import argparse,base64,hashlib,struct,zipfile,json,re
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding

def lp(b,p=0):
    n=struct.unpack_from('<I',b,p)[0];end=p+4+n
    if end>len(b):raise ValueError('Truncated length-prefixed field')
    return b[p+4:end],end
def sections(b):
    # Unfold manifest continuation lines before parsing.
    return b.replace(b'\r\n ',b'').split(b'\r\n\r\n')
def attributes(section):return dict(x.decode().split(': ',1) for x in section.split(b'\r\n') if b': ' in x)
def verify(path):
    b=Path(path).read_bytes();end=b.rfind(b'PK\x05\x06');assert end>=0
    assert end+22+struct.unpack_from('<H',b,end+20)[0]==len(b)
    cd=struct.unpack_from('<I',b,end+16)[0];assert b[cd-16:cd]==b'APK Sig Block 42'
    size=struct.unpack_from('<Q',b,cd-24)[0];start=cd-size-8
    assert struct.unpack_from('<Q',b,start)[0]==size
    p=start+8;value=None
    while p<cd-24:
        n=struct.unpack_from('<Q',b,p)[0];tag=struct.unpack_from('<I',b,p+8)[0]
        if tag==0x7109871a:value=b[p+12:p+8+n]
        p+=8+n
    assert value is not None
    signers,off=lp(value);assert off==len(value)
    signer,off=lp(signers);assert off==len(signers)
    signed,p=lp(signer);sigseq,p=lp(signer,p);public,p=lp(signer,p);assert p==len(signer)
    record,p=lp(sigseq);assert p==len(sigseq)
    algorithm=struct.unpack_from('<I',record)[0];assert algorithm==0x0103
    signature,p=lp(record,4);assert p==len(record)
    key=serialization.load_der_public_key(public);key.verify(signature,signed,padding.PKCS1v15(),hashes.SHA256())
    digests,p=lp(signed);certseq,p=lp(signed,p);attrs,p=lp(signed,p);assert p==len(signed)
    digestrecord,p=lp(digests);assert p==len(digests);assert struct.unpack_from('<I',digestrecord)[0]==algorithm
    expected,p=lp(digestrecord,4);assert p==len(digestrecord)
    certbytes,_=lp(certseq);cert=x509.load_der_x509_certificate(certbytes)
    assert cert.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)==public
    eocd=bytearray(b[end:]);struct.pack_into('<I',eocd,16,start)
    chunk_hashes=[]
    for part in (b[:start],b[cd:end],bytes(eocd)):
        for i in range(0,len(part),1048576):
            x=part[i:i+1048576];chunk_hashes.append(hashlib.sha256(bytes([165])+struct.pack('<I',len(x))+x).digest())
    calculated=hashlib.sha256(bytes([90])+struct.pack('<I',len(chunk_hashes))+b''.join(chunk_hashes)).digest()
    assert calculated==expected,'APK v2 content digest mismatch'
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        mf=z.read('META-INF/MANIFEST.MF');sf=z.read('META-INF/BOUH77.SF')
        assert attributes(sections(sf)[0])['SHA-256-Digest-Manifest']==base64.b64encode(hashlib.sha256(mf).digest()).decode()
        covered=set()
        for sec in sections(mf)[1:]:
            if not sec:continue
            d=attributes(sec);content=z.read(d['Name']);assert d['SHA-256-Digest']==base64.b64encode(hashlib.sha256(content).digest()).decode();covered.add(d['Name'])
        expected_files={x for x in z.namelist() if x not in ('META-INF/MANIFEST.MF','META-INF/BOUH77.SF','META-INF/BOUH77.RSA')}
        assert expected_files==covered
        for info in z.infolist():
            if info.compress_type==zipfile.ZIP_STORED:
                n,e=struct.unpack_from('<HH',b,info.header_offset+26);assert (info.header_offset+30+n+e)%4==0
        assert z.read('AndroidManifest.xml').find('com.bouh.terrainradar.research77'.encode('utf-16le'))>=0 or z.read('AndroidManifest.xml').find(b'com.bouh.terrainradar.research77')>=0
        for required in ['assets/engine.js','assets/map.js','assets/app.js','assets/mobile-layout.js','assets/mobile-layout.css','assets/assets/legacy-cells.js','classes3.dex','assets/terrain-tiles.js','assets/terrain-panel.js']:assert required in z.namelist()
        assert b'com.bouh.terrainradar.MobileActivity' in z.read('AndroidManifest.xml') or 'com.bouh.terrainradar.MobileActivity'.encode('utf-16le') in z.read('AndroidManifest.xml')
        assert b'v763' not in z.read('assets/engine.js')
        version=re.search(rb"VERSION='([^']+)'",z.read('assets/engine.js')).group(1).decode()
        manifest=z.read('AndroidManifest.xml')
        assert (version+'-unified').encode() in manifest or (version+'-unified').encode('utf-16le') in manifest
    return {'zip_crc':'pass','v1_all_entry_digests':'pass','v1_manifest_digest':'pass','v2_rsa_signature':'pass','v2_whole_file_digest':'pass','stored_entries_4byte_aligned':'pass','version':version,'android_device_installation':'not tested'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('apk');args=p.parse_args();print(json.dumps(verify(args.apk),indent=2))
