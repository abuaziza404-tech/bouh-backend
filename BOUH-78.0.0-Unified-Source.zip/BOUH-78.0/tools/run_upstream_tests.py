from pathlib import Path
import subprocess, tempfile, zipfile
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as folder:
    index=Path(folder)/'index.html'
    with zipfile.ZipFile(root/'android-shell/base.apk') as z:
        index.write_bytes(z.read('assets/index.html'))
    subprocess.run(['node',str(root/'tests/upstream/BOUH_Verify_Audit_And_Engine_Tests.js'),str(index)],check=True)
