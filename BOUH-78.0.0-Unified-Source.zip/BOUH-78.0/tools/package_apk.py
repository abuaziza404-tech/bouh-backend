#!/usr/bin/env python3
"""Repackage the supplied Android WebView shell with v77 assets; sign v1+v2.

No claim of a native rebuild: original DEX/resources are reused unchanged.
Format reference: https://source.android.com/docs/security/features/apksigning/v2
"""
from pathlib import Path
import argparse, base64, datetime, hashlib, io, json, struct, zipfile
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.serialization import pkcs7
from build_insets_dex import build as build_insets

U32=lambda n:struct.pack('<I',n)
U64=lambda n:struct.pack('<Q',n)
LP=lambda b:U32(len(b))+b

def manifest_patch(data):
    chunks=[];offset=8;strings=[]
    while offset<len(data):
        kind,header,size=struct.unpack_from('<HHI',data,offset)
        chunks.append([kind,header,bytearray(data[offset:offset+size])]);offset+=size
    pool=next(c for c in chunks if c[0]==1)
    count,style_count,flags,start,style_start=struct.unpack_from('<5I',pool[2],8)
    assert style_count==0 and style_start==0
    offsets=struct.unpack_from('<'+str(count)+'I',pool[2],pool[1])
    def utf8_len(b,p):
        v=b[p];return (((v&127)<<8)|b[p+1],p+2) if v&128 else (v,p+1)
    for pos in offsets:
        p=start+pos
        if flags&0x100:
            _,p=utf8_len(pool[2],p);n,p=utf8_len(pool[2],p);s=pool[2][p:p+n].decode('utf-8')
        else:
            n=struct.unpack_from('<H',pool[2],p)[0];assert n<0x8000;s=pool[2][p+2:p+2+n*2].decode('utf-16le')
        strings.append(s)
    old_package=strings.index('com.bouh.terrainradar')
    strings[old_package]='com.bouh.terrainradar.research77'
    strings[strings.index('com.bouh.terrainradar.MainActivity')]='com.bouh.terrainradar.MobileActivity'
    version=len(strings);strings.append('78.0.0-unified')
    label=len(strings);strings.append('بوح الاستكشاف 77')
    def enc_len(n):
        return bytes([n]) if n<128 else bytes([(n>>8)|128,n&255])
    text=bytearray();offs=[]
    for s in strings:
        offs.append(len(text))
        if flags&0x100:
            b=s.encode();text+=enc_len(len(s.encode('utf-16le'))//2)+enc_len(len(b))+b+b'\0'
        else:
            b=s.encode('utf-16le');text+=struct.pack('<H',len(b)//2)+b+b'\0\0'
    text+=b'\0'*((-len(text))%4)
    start=28+4*len(strings)
    # Clear SORTED_FLAG: strings have been edited and appended.
    pool[2]=bytearray(struct.pack('<HHI5I',1,28,start+len(text),len(strings),0,flags&~1,start,0)+b''.join(U32(x) for x in offs)+text)
    for kind,header,chunk in chunks:
        if kind!=0x102:continue
        _,name,attrstart,attrsize,count=struct.unpack_from('<IIHHH',chunk,16)
        tag=strings[name]
        for i in range(count):
            off=16+attrstart+i*attrsize
            ns,key,raw,vsize,res0,typ,value=struct.unpack_from('<IIIHBBI',chunk,off)
            attr=strings[key]
            if tag=='manifest' and attr=='versionCode':struct.pack_into('<I',chunk,off+16,7800)
            if tag=='manifest' and attr=='versionName':struct.pack_into('<I',chunk,off+8,version);chunk[off+15]=3;struct.pack_into('<I',chunk,off+16,version)
            if tag=='uses-sdk' and attr=='minSdkVersion':struct.pack_into('<I',chunk,off+16,24)
            if tag=='activity' and attr=='screenOrientation':struct.pack_into('<I',chunk,off+16,2)
            if tag=='application' and attr=='label':struct.pack_into('<I',chunk,off+8,label);chunk[off+15]=3;struct.pack_into('<I',chunk,off+16,label)
            if tag=='application' and attr in ('debuggable','allowBackup'):struct.pack_into('<I',chunk,off+16,0)
    result=b''.join(bytes(c[2]) for c in chunks)
    return struct.pack('<HHI',3,8,len(result)+8)+result

def signing_identity(directory):
    directory.mkdir(parents=True,exist_ok=True)
    kp,cp=directory/'research-signing-key.pem',directory/'research-signing-cert.pem'
    if kp.exists() and cp.exists():
        return serialization.load_pem_private_key(kp.read_bytes(),None),x509.load_pem_x509_certificate(cp.read_bytes())
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'BOUH Research 77 - Ahmed Abuaziza Al-Rashidi')])
    now=datetime.datetime.now(datetime.timezone.utc)
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=365*30)).sign(key,hashes.SHA256()))
    kp.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));kp.chmod(0o600)
    cp.write_bytes(cert.public_bytes(serialization.Encoding.PEM));return key,cert

def b64sha(b):return base64.b64encode(hashlib.sha256(b).digest()).decode()
def jar_line(s):
    # Byte folding at 70 bytes leaves room for CRLF, and supports UTF-8 entry names.
    b=s.encode('utf-8');out=[]
    while len(b)>70:
        n=70
        while n>0 and (b[n]&0xc0)==0x80:n-=1
        out.append(b[:n]+b'\r\n');b=b' '+b[n:]
    return b''.join(out)+b+b'\r\n'
def v1_entries(entries,key,cert):
    sections=[]
    for name,content in entries.items():sections.append(jar_line('Name: '+name)+jar_line('SHA-256-Digest: '+b64sha(content))+b'\r\n')
    manifest=b'Manifest-Version: 1.0\r\nCreated-By: BOUH Research 77\r\n\r\n'+b''.join(sections)
    sf=b'Signature-Version: 1.0\r\nCreated-By: BOUH Research 77\r\nX-Android-APK-Signed: 2\r\n'+jar_line('SHA-256-Digest-Manifest: '+b64sha(manifest))+b'\r\n'
    for (name,_),section in zip(entries.items(),sections):sf+=jar_line('Name: '+name)+jar_line('SHA-256-Digest: '+b64sha(section))+b'\r\n'
    sig=(pkcs7.PKCS7SignatureBuilder().set_data(sf).add_signer(cert,key,hashes.SHA256()).sign(serialization.Encoding.DER,[pkcs7.PKCS7Options.DetachedSignature,pkcs7.PKCS7Options.Binary]))
    return {'META-INF/MANIFEST.MF':manifest,'META-INF/BOUH77.SF':sf,'META-INF/BOUH77.RSA':sig}

def zip_bytes(entries):
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w') as z:
        for name,data in entries.items():
            info=zipfile.ZipInfo(name,(2026,10,26,0,0,0));info.external_attr=0o100644<<16
            info.compress_type=zipfile.ZIP_STORED if name.endswith(('.arsc','.png','.jpg')) else zipfile.ZIP_DEFLATED
            if info.compress_type==zipfile.ZIP_STORED:
                # Align all uncompressed entry payloads to 4 bytes.
                pad=(-(buf.tell()+30+len(name.encode())+4))%4
                info.extra=struct.pack('<HH',0xd935,pad)+b'\0'*pad
            z.writestr(info,data,compresslevel=9)
    return buf.getvalue()

def content_digest(parts):
    digests=[]
    for part in parts:
        for i in range(0,len(part),1024*1024):
            block=part[i:i+1024*1024];digests.append(hashlib.sha256(b'\xa5'+U32(len(block))+block).digest())
    return hashlib.sha256(b'\x5a'+U32(len(digests))+b''.join(digests)).digest()
def sign_v2(raw,key,cert):
    end=raw.rfind(b'PK\x05\x06');assert end>=0
    cdoff=struct.unpack_from('<I',raw,end+16)[0]
    data,cd,eocd=raw[:cdoff],raw[cdoff:end],bytearray(raw[end:])
    digest=content_digest([data,cd,eocd]);algorithm=0x0103
    certbytes=cert.public_bytes(serialization.Encoding.DER)
    signed=LP(LP(U32(algorithm)+LP(digest)))+LP(LP(certbytes))+LP(b'')
    signature=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
    public=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
    signer=LP(signed)+LP(LP(U32(algorithm)+LP(signature)))+LP(public)
    value=LP(LP(signer));pair=U64(4+len(value))+U32(0x7109871a)+value
    size=len(pair)+24;block=U64(size)+pair+U64(size)+b'APK Sig Block 42'
    struct.pack_into('<I',eocd,16,cdoff+len(block))
    return data+block+cd+bytes(eocd)

def build(source,web,out,identity):
    key,cert=signing_identity(identity)
    entries={}
    with zipfile.ZipFile(source) as z:
        for n in z.namelist():
            if n.startswith(('assets/','META-INF/')) or n.endswith('/'):continue
            entries[n]=manifest_patch(z.read(n)) if n=='AndroidManifest.xml' else z.read(n)
    for p in sorted(web.rglob('*')):
        if p.is_file():entries['assets/'+p.relative_to(web).as_posix()]=p.read_bytes()
    adapter=out.parent/'mobile-insets-adapter.dex'
    adapter_info=build_insets(adapter);entries['classes3.dex']=adapter.read_bytes()
    entries.update(v1_entries(entries,key,cert));out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(sign_v2(zip_bytes(entries),key,cert))
    return {'file':out.name,'package':'com.bouh.terrainradar.research77','version_name':'78.0.0-unified','version_code':7800,'min_android_api':24,'target_android_api':35,'signing_schemes':['v1','v2'],'certificate_sha256':cert.fingerprint(hashes.SHA256()).hex(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native_shell':'original DEX/resources retained plus new MobileActivity insets adapter','adapter':adapter_info,'device_install_tested':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--web',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--identity',type=Path,required=True);a=p.parse_args()
    result=build(a.base,a.web,a.output,a.identity);print(json.dumps(result,ensure_ascii=False,indent=2));a.output.with_suffix('.build.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
