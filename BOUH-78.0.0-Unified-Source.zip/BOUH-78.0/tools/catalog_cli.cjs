#!/usr/bin/env node
/* Node 18+; writes a discovery receipt even when the network request fails. */
const fs=require('node:fs'),path=require('node:path'),S=require('../web/sources.js');
const args=process.argv.slice(2),get=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1]};
const provider=get('--provider','earth_s2_c1'),bbox=get('--bbox',S.REGIONAL_BBOX.join(',')).split(',').map(Number),start=get('--start','2025-10-26'),end=get('--end','2026-10-26'),out=path.resolve(get('--out','catalog-result.json'));
(async()=>{let receipt;try{receipt=await S.search(provider,{bbox,start,end,limit:100,maxCloud:20});}catch(e){receipt={schema:'BOUH_CATALOG_DISCOVERY_1',provider_id:provider,status:'BLOCKED_OR_FAILED',error:String(e.message),attempted_at:new Date().toISOString(),request_url:S.queryUrl(provider,{bbox,start,end,limit:100}),records:[],raster_files_downloaded:0,raw_processing_executed:false};process.exitCode=2;}fs.writeFileSync(out,JSON.stringify(receipt,null,2));console.log(JSON.stringify({file:out,status:receipt.status||'CATALOGUE_READ',records:receipt.records.length,raster_files_downloaded:0}));})();
