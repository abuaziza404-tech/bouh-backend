/* Explicit fixtures: no remote STAC service and no real Android runtime. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const prefix=fs.readFileSync(path.join(__dirname,'ui.test.cjs'),'utf8').split('let passed=0;')[0];
function boot(){const h=new Function('require','__dirname',prefix+'return {env,nodes,store,tasks};')(require,__dirname);h.env.AbortController=AbortController;h.env.fetch=async()=>{throw Error('Unconfigured fixture');};return h;}
let passed=0;async function test(n,f){await f();console.log('PASS',n);passed++;}
(async()=>{
await test('terrain panel refuses missing connection without changing local geology',async()=>{const h=boot(),before=JSON.stringify(h.env.BOUH77.getAnalysis());await h.nodes.terrainRun.onclick();assert.equal(JSON.stringify(h.env.BOUH77.getAnalysis()),before);assert.equal(h.nodes.terrainRun.disabled,false);});
await test('advanced engine uses mounted routes and never persists bearer token',async()=>{
 const h=boot(),calls=[];h.nodes.cloudUrl.value='https://fixture.example';h.nodes.cloudToken.value='fixture-secret-session';h.nodes.terrainArea.value='focus-5km';
 const feature={type:'Feature',id:'focus-5km',properties:{processing_enabled:true,name:'Test'},geometry:{type:'Polygon',coordinates:[[[37,18],[37.1,18],[37.1,18.1],[37,18.1],[37,18]]]}};
 h.env.fetch=async(url,options)=>{calls.push({url,options});const body=url.endsWith('/coverage')?{type:'FeatureCollection',features:[feature]}:{state:'completed',revision:'b'.repeat(32)};return {ok:true,status:200,headers:new Map(),text:async()=>JSON.stringify(body)};};
 await h.nodes.terrainRun.onclick();assert.equal(calls.length,3);assert.ok(calls[1].url.endsWith('/terrain/api/coverage/focus-5km/refresh'));assert.equal(calls[1].options.method,'POST');assert.equal(calls[0].options.headers.Authorization,'Bearer fixture-secret-session');assert.ok(!JSON.stringify([...h.store]).includes('fixture-secret'));assert.equal(JSON.parse(h.store.get('bouh_cloud_url_v1')),'https://fixture.example');assert.equal(h.nodes.terrainHide.disabled,false);h.nodes.terrainHide.onclick();h.nodes.terrainHide.onclick();
});
await test('failed QA model displays failure without fabricating rendered data',async()=>{
 const h=boot();h.nodes.cloudUrl.value='https://fixture.example';h.nodes.cloudToken.value='test';h.nodes.terrainArea.value='focus';
 const area={type:'Feature',id:'focus',properties:{processing_enabled:true},geometry:{type:'Polygon',coordinates:[[[37,18],[37.1,18],[37.1,18.1],[37,18]]]}};
 h.env.fetch=async url=>({ok:true,status:200,headers:new Map(),text:async()=>JSON.stringify(url.endsWith('/coverage')?{type:'FeatureCollection',features:[area]}:{state:'failed'})});
 await h.nodes.terrainResume.onclick();assert.match(h.nodes.terrainStatus.textContent,/رفضت/);assert.equal(h.nodes.terrainHide.disabled,true);
});
await test('tile fetching is bounded and disposed requests are aborted',()=>{
 const h=boot(),signals=[];h.env.setTimeout=setTimeout;h.env.clearTimeout=clearTimeout;
 h.env.fetch=(url,o)=>{signals.push(o.signal);return new Promise((resolve,reject)=>o.signal.addEventListener('abort',()=>{const e=Error('abort');e.name='AbortError';reject(e);}));};
 const layer=h.env.BOUHTerrainTiles.create({baseUrl:'https://fixture.example',area:'focus',revision:'a'.repeat(32),getToken:()=> 'test',bbox:[-179,-80,179,80]});
 layer.draw({drawImage(){}},0,0,1024,1024,3,()=>{});assert.equal(signals.length,3);layer.dispose();assert.ok(signals.every(s=>s.aborted));
});
await test('tile requests exclude views outside the configured AOI',()=>{
 const h=boot();let calls=0;h.env.fetch=()=>{calls++;throw Error('Unexpected');};const layer=h.env.BOUHTerrainTiles.create({baseUrl:'https://fixture.example',area:'focus',revision:'a'.repeat(32),getToken:()=> 'test',bbox:[37,18,37.1,18.1]});
 layer.draw({},0,0,256,256,10,()=>{});assert.equal(calls,0);layer.dispose();
});
console.log(JSON.stringify({passed,scope:'HTTP fixtures and renderer harness only'}));
})().catch(e=>{console.error(e);process.exitCode=1;});
