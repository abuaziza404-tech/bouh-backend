"""Actual raster IO only when GDAL/Rasterio is installed; no satellite mock claim."""
import importlib.util
import tempfile
from pathlib import Path
import unittest

@unittest.skipUnless(importlib.util.find_spec('rasterio'),'Rasterio unavailable: raster integration not run')
class RasterTests(unittest.TestCase):
 def test_png_warp_and_geographic_bounds(self):
  import numpy as np
  import rasterio
  from rasterio.transform import from_origin
  from acquisition.overlays import create_overlay
  from PIL import Image
  with tempfile.TemporaryDirectory() as d:
   t=Path(d)/'input.tif';p=Path(d)/'display.png'
   with rasterio.open(t,'w',driver='GTiff',height=32,width=32,count=1,dtype='float32',crs='EPSG:32637',
                      transform=from_origin(300000,2100000,20,20),nodata=-9999) as dst:
    dst.write(np.arange(1024,dtype='float32').reshape(32,32),1)
   meta=create_overlay(t,p,(200,100,50))
   self.assertEqual(meta['projection'],'EPSG:3857')
   self.assertLess(meta['bounds'][0][0],meta['bounds'][1][0])
   self.assertLess(meta['bounds'][0][1],meta['bounds'][1][1])
   self.assertEqual(Image.open(p).mode,'RGBA')
