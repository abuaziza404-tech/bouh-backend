import unittest
import numpy as np
from engine.science import safe_divide,terrain_light,feature_pca,xyz_bounds,colorize
from engine.numeric import QualityGateError


class ScienceTests(unittest.TestCase):
 def test_zero_is_measurement(self):self.assertEqual(safe_divide([0],[2])[0],0)
 def test_nonfinite_and_zero_denominator_missing(self):self.assertTrue(np.isnan(safe_divide([np.inf,1,2],[1,0,np.nan])).all())
 def test_flat_terrain_illuminated(self):
  lit,known,c=terrain_light(np.zeros((32,32)),30,90,45,120)
  self.assertTrue(lit[16,16]);self.assertTrue(known[16,16]);self.assertAlmostEqual(c[16,16],np.sqrt(.5))
 def test_east_ridge_casts_west_shadow(self):
  dem=np.zeros((64,64));dem[:,38]=500
  lit,known,_=terrain_light(dem,30,90,45,240)
  self.assertTrue(known[32,32]);self.assertFalse(lit[32,32])
 def test_ridge_away_from_sun_not_shadow(self):
  dem=np.zeros((64,64));dem[:,38]=500
  lit,known,_=terrain_light(dem,30,270,45,240)
  self.assertTrue(lit[32,32])
 def test_missing_horizon_is_unknown(self):
  dem=np.zeros((64,64));dem[:,35]=np.nan
  lit,known,_=terrain_light(dem,30,90,45,240)
  self.assertFalse(known[32,32]);self.assertFalse(lit[32,32])
 def test_halo_boundary_is_unknown(self):
  lit,known,_=terrain_light(np.zeros((32,32)),30,90,45,120)
  self.assertFalse(known[16,-1])
 def test_pca_insufficient_fails(self):
  a={b:np.ones((10,10)) for b in ['blue','red','nir','swir16','swir22']}
  with self.assertRaises(QualityGateError):feature_pca(a,np.ones((10,10),bool),'iron')
 def test_pca_orients_physical_pair(self):
  rng=np.random.default_rng(48);shape=(40,40)
  albedo=rng.normal(0,1,shape);iron=rng.normal(0,1,shape)
  a={'blue':.3+.01*albedo-.008*iron,'red':.3+.01*albedo+.008*iron,
     'nir':.3+.01*albedo+.004*rng.normal(size=shape),
     'swir16':.3+.01*albedo+.004*rng.normal(size=shape)}
  score,meta=feature_pca(a,np.ones(shape,bool),'iron')
  self.assertGreater(np.corrcoef(score.ravel(),iron.ravel())[0,1],.9)
  self.assertLess(meta['choice']['loadings'][0],0);self.assertGreater(meta['choice']['loadings'][1],0)
 def test_xyz_world(self):
  b=xyz_bounds(0,0,0);self.assertAlmostEqual(b[0],-20037508.342789244);self.assertAlmostEqual(b[3],20037508.342789244)
 def test_adjacent_tiles_share_boundary(self):self.assertEqual(xyz_bounds(4,3,2)[2],xyz_bounds(4,4,2)[0])
 def test_invalid_xyz_rejected(self):
  for p in [(2,4,0),(2,0,-1),(21,0,0)]:
   with self.assertRaises(ValueError):xyz_bounds(*p)
 def test_nodata_transparent(self):self.assertEqual(colorize(np.array([[255]],dtype='uint8'))[0,0,3],0)
