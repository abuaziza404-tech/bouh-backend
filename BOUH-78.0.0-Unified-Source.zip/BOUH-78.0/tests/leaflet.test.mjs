import test from 'node:test';import assert from 'node:assert/strict';
import {validBounds,createCoverageLayerManager} from '../frontend/leaflet-overlays.mjs';
test('Leaflet order is lat lon',()=>assert.equal(validBounds([[18,37],[19,38]]),true));
test('reversed and nonfinite bounds rejected',()=>{assert.equal(validBounds([[19,38],[18,37]]),false);assert.equal(validBounds([[18,NaN],[19,38]]),false);});
test('HTTPS enforced',()=>assert.throws(()=>createCoverageLayerManager({apiUrl:'http://example.com'})));
test('cross-origin image request never receives token',async()=>{
 let calls=0;const manager=createCoverageLayerManager({map:{},L:{},apiUrl:'https://one.example',getToken:()=> 'secret',fetchImpl:async()=>{calls++;throw Error('should not run');}});
 await assert.rejects(manager.show({type:'FeatureCollection',metadata:{overlays:[{projection:'EPSG:3857',bounds:[[18,37],[19,38]],url:'https://two.example/image.png'}]}}),/origin/);assert.equal(calls,0);
});
test('missing idempotency key rejected',async()=>{const m=createCoverageLayerManager({apiUrl:'https://one.example',getToken:()=> 'secret'});await assert.rejects(m.refresh('focus-5km'),/Persist/);});
