/* Exercise the shipping panel against explicit HTTP fixtures, not live GEE. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const prefix=fs.readFileSync(path.join(__dirname,'ui.test.cjs'),'utf8').split('let passed=0;')[0];
function boot(){
 const h=new Function('require','__dirname',prefix+'return {env,nodes,store,tasks};')(require,__dirname);
 h.env.AbortController=AbortController;h.env.fetch=async()=>{throw Error('No fixture');};
 for(const f of ['cloud-geometry.js','cloud-api.js','cloud-panel.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../web',f),'utf8'),h.env,{filename:f});
 h.nodes.cloudExtent.value='center';h.nodes.cloudTier.value='1';h.nodes.cloudProxies.checked=true;
 return h;
}
const fixture={type:'FeatureCollection',metadata:{field_validated:false,gold_probability:null},features:[{
 type:'Feature',properties:{evidence_kind:'intersection',evidence_tier:1,target_id:'fixture-only'},
 geometry:{type:'Polygon',coordinates:[[[37.18,18.88],[37.19,18.88],[37.19,18.89],[37.18,18.88]],[[37.182,18.882],[37.184,18.882],[37.184,18.884],[37.182,18.882]]]}}]};
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS',name);}
(async()=>{
 await test('missing server stays idle and preserves local reference data',async()=>{const h=boot();const before=JSON.stringify(h.env.BOUH77.getAnalysis());await h.nodes.cloudAnalyze.onclick();assert.equal(JSON.stringify(h.env.BOUH77.getAnalysis()),before);assert.equal(h.env.BOUHCloudPanel.isBusy(),false);assert.equal(h.env.BOUHCloudPanel.getPending(),null);});
 await test('rejects invalid dates and oversized AOI before networking',()=>{const h=boot(),validate=h.env.BOUHCloudPanel.validatePayload;assert.throws(()=>validate({bbox:[36,18,38,20],start_date:'2025-01-01',end_date:'2025-02-01'}));assert.throws(()=>validate({bbox:[37.14,18.84,37.24,18.94],start_date:'2025-01-01',end_date:'2025-05-01'}));});
 await test('completed cloud job draws polygons, caches result, preserves core and hides token',async()=>{
 const h=boot(),calls=[],before=JSON.stringify(h.env.BOUH77.getAnalysis());
 h.nodes.cloudUrl.value='https://example.com';h.nodes.cloudToken.value='personal-secret-only-session';h.nodes.cloudStart.value='2025-01-01';h.nodes.cloudEnd.value='2025-02-01';
 h.env.fetch=async(url,options)=>{calls.push({url,options});let body=url.endsWith('analyze-terrain')?{job_id:'a'.repeat(32)}:url.endsWith('/result')?fixture:{state:'completed'};return {ok:true,status:200,headers:new Map(),text:async()=>JSON.stringify(body)};};
 await h.nodes.cloudAnalyze.onclick();assert.equal(calls.length,3);assert.equal(h.env.BOUHCloudPanel.getPending(),null);assert.ok(h.store.get('bouh_cloud_result_v1'));assert.ok(!JSON.stringify([...h.store]).includes('personal-secret-only-session'));assert.equal(JSON.stringify(h.env.BOUH77.getAnalysis()),before);assert.equal(h.nodes.cloudLegend.hidden,false);
 h.nodes.cloudKml.onclick();assert.match(h.nodes.exportText.value,/<innerBoundaryIs>/);assert.match(h.nodes.exportText.value,/37.19,18.88,0/);assert.equal(h.nodes.exportDialog.open,true);
 h.nodes.cloudToggle.onclick();assert.equal(h.nodes.cloudLegend.hidden,true);h.nodes.cloudToggle.onclick();assert.equal(h.nodes.cloudLegend.hidden,false);
 });
 await test('authentication failure keeps nonce for a retry rather than duplicating a job',async()=>{
 const h=boot();h.nodes.cloudUrl.value='https://example.com';h.nodes.cloudToken.value='bad-token';h.nodes.cloudStart.value='2025-01-01';h.nodes.cloudEnd.value='2025-02-01';const keys=[];
 h.env.fetch=async(url,o)=>{keys.push(o.headers['Idempotency-Key']);return {ok:false,status:401,headers:new Map(),text:async()=>'{"detail":"Authentication required"}'};};
 await h.nodes.cloudAnalyze.onclick();assert.ok(h.env.BOUHCloudPanel.getPending());assert.equal(h.nodes.cloudResume.hidden,false);await h.nodes.cloudResume.onclick();assert.equal(keys[0],keys[1]);assert.match(h.nodes.cloudStatus.textContent,/رمز الوصول/);assert.equal(h.env.BOUHCloudPanel.isBusy(),false);
 });
 await test('resuming against another host is refused before credential transmission',async()=>{const h=boot();const record={apiUrl:'https://one.example',key:'fixture_pending_key',payload:{}};h.store.set('bouh_cloud_pending_v1',JSON.stringify(record));vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/cloud-panel.js'),'utf8'),h.env);h.nodes.cloudUrl.value='https://other.example';h.nodes.cloudToken.value='secret';let calls=0;h.env.fetch=async()=>{calls++;throw Error('unreachable');};await h.nodes.cloudResume.onclick();assert.equal(calls,0);assert.match(h.nodes.cloudStatus.textContent,/مختلف/);});
 await test('map extent is geographic and cloud rendering does not alter legacy ranking',()=>{const h=boot();const b=h.env.BOUH77.getBounds();assert.ok(b[0]<b[2]&&b[1]<b[3]);const before=JSON.stringify(h.env.BOUH77.getAnalysis());assert.equal(h.env.BOUH77.setCloudAnomalies(fixture),1);assert.equal(JSON.stringify(h.env.BOUH77.getAnalysis()),before);assert.equal(h.env.BOUH77.setCloudAnomalies(null),0);});
 console.log(JSON.stringify({passed,scope:'HTTP fixtures and DOM/canvas harness; no live GEE or Android execution'}));
})().catch(e=>{console.error(e);process.exitCode=1;});
