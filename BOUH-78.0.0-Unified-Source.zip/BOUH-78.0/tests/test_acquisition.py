import json
import tempfile
from pathlib import Path
import unittest
import numpy as np
from acquisition.bouh_math import safe_divide,compute_indices,calibration
from acquisition.coverage import load_areas,require_processable
from acquisition.collect_bouh import discover,trusted_asset

R=[[37.14,18.84],[37.24,18.84],[37.24,18.94],[37.14,18.94],[37.14,18.84]]
class NumericTests(unittest.TestCase):
 def test_zero_preserved(self):self.assertEqual(safe_divide([0],[2],np)[0],0)
 def test_invalid_missing(self):self.assertTrue(np.isnan(safe_divide([1,np.inf,2],[0,1,np.nan],np)).all())
 def test_overflow_missing(self):self.assertTrue(np.isnan(safe_divide([1e308],[1e-5],np))[0])
 def test_calibration_explicit(self):
  self.assertEqual(calibration({'raster:bands':[{'scale':.0001,'offset':-.1}]}),(.0001,-.1))
  with self.assertRaises(ValueError):calibration({'raster:bands':[{'scale':.0001}]})
 def test_indices_are_calibrated_ratios(self):
  a={k:np.array([[v]],dtype=float) for k,v in {'blue':.1,'green':.1,'red':.2,'nir':.2,'swir16':.4,'swir22':.2}.items()}
  r=compute_indices(a,np.array([[True]]),np)
  self.assertEqual(r['gossan_ratio'][0,0],2);self.assertEqual(r['iron_ratio'][0,0],2);self.assertEqual(r['swir_ratio'][0,0],2)
 def test_bad_denominator_not_zero_signal(self):
  a={k:np.array([[.2]]) for k in ['blue','green','red','nir','swir16','swir22']};a['blue'][0,0]=0
  r=compute_indices(a,np.array([[True]]),np);self.assertTrue(np.isnan(r['iron_ratio'][0,0]))
 def test_grid_mismatch(self):
  with self.assertRaises(ValueError):compute_indices({},np.array([[True]]),np)
 def test_scl_cloud_mask_excludes_all_ratios(self):
  a={k:np.array([[.2]]) for k in ['blue','green','red','nir','swir16','swir22']}
  r=compute_indices(a,np.array([[False]]),np)
  self.assertTrue(all(np.isnan(r[k][0,0]) for k in ['iron_ratio','swir_ratio','gossan_ratio']))

class CoverageTests(unittest.TestCase):
 def area(self,enabled=True):
  return {'type':'FeatureCollection','features':[{'type':'Feature','id':'test','properties':{'processing_enabled':enabled},'geometry':{'type':'Polygon','coordinates':[R]}}]}
 def load(self,data):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text(json.dumps(data));return load_areas(p)
 def test_area_geometry_preserved(self):self.assertEqual(self.load(self.area())['test']['geometry']['coordinates'][0],R)
 def test_context_not_processed(self):
  with self.assertRaises(ValueError):require_processable(self.load(self.area(False))['test'])
 def test_missing_or_duplicate_id_rejected(self):
  a=self.area();a['features']*=2
  with self.assertRaises(ValueError):self.load(a)
 def test_large_area_requires_tiling(self):
  a=self.load(self.area())['test'];a['bbox']=[35,18,38,21]
  with self.assertRaises(ValueError):require_processable(a)
 def test_asset_host_allowlist(self):
  self.assertTrue(trusted_asset('https://sentinel-cogs.s3.us-west-2.amazonaws.com/a.tif'))
  for url in ['http://example.com/a.tif','https://127.0.0.1/a.tif','https://x.s3.us-west-2.amazonaws.com/a.jpg']:
   with self.assertRaises(ValueError):trusted_asset(url)

class CatalogTests(unittest.TestCase):
 class Response:
  def __init__(self,p):self.p=p
  def raise_for_status(self):pass
  def json(self):return self.p
 class Session:
  def __init__(self,p):self.p=p
  def post(self,*args,**kwargs):return CatalogTests.Response(self.p)
 def test_latest_date_not_catalog_order(self):
  items=[{'id':'old','properties':{'datetime':'2025-01-01T00:00:00Z'}},{'id':'new','properties':{'datetime':'2025-01-02T00:00:00Z'}}]
  r,_=discover(self.Session({'type':'FeatureCollection','features':items}),{},max_scenes=1)
  self.assertEqual(r[0]['id'],'new')
 def test_pagination_not_claimed_complete(self):
  with self.assertRaises(ValueError):discover(self.Session({'type':'FeatureCollection','features':[],'links':[{'rel':'next','href':'https://example.com'}]}),{})
