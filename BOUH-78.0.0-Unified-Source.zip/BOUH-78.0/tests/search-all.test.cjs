const assert=require('node:assert/strict'),S=require('../web/sources.js');
(async()=>{
let inFlight=0,max=0,progress=[];
const options={start:'2025-10-27',end:'2026-10-27',bbox:S.focusBBox()};
const fetcher=async url=>{inFlight++;max=Math.max(max,inFlight);await new Promise(r=>setTimeout(r,2));inFlight--;return url.includes('copernicus')?{ok:false,status:403}:{ok:true,json:async()=>({type:'FeatureCollection',features:[],links:[]})};};
const r=await S.searchAll(options,fetcher,(a,b)=>progress.push([a,b]));
assert.equal(max,2);assert.equal(r.provider_results.length,4);assert.equal(r.provider_failures.length,2);assert.equal(r.partial_success,true);assert.equal(progress.length,6);assert.deepEqual(progress.at(-1),[6,6]);assert.equal(r.raw_processing_executed,false);assert.equal(r.raster_files_downloaded,0);
console.log('PASS bounded concurrency, progress, partial-source failure and honest processing state');
await assert.rejects(()=>S.searchAll(options,async()=>({ok:false,status:403})),/ALL_PROVIDERS_FAILED/);
console.log('PASS total failure cannot masquerade as successful empty search');
const ok=await S.searchAll(options,async()=>({ok:true,json:async()=>({type:'FeatureCollection',features:[],links:[{rel:'next'}]})}));assert.equal(ok.has_more,true);assert.equal(ok.partial_success,false);assert.equal(ok.provider_results.length,6);
console.log('PASS all sources retain pagination uncertainty');
})().catch(e=>{console.error(e);process.exitCode=1;});
