/**
 * BOUH Unified Geological Exploration Engine (v1.5.0 - Final Audit-Locked Release)
 * محرك «بوح» الموحد للاستكشاف الجيولوجي الموثق — الإصدار المقفل والمحصّن نهائيًا (1.5.0)
 * المالك والمطور: أحمد أبو عزيزه الرشيدي
 *
 * الإصلاحات الحاسمة المضافة في الإصدار 1.5.0 (إغلاق ثغرات المراجعة المستقلة الثانية):
 * 1. منع تجاوز تحقق المصدر بسجل يبدو مطبّعًا أو معدّلًا (Always Re-Normalize & Deep-Freeze):
 *    - تعيد دالة evaluateCellAtCoordinate تطبيع وفحص أي سجل يمر إليها عبر normalizeCellRecord(cellInput)
 *      في كل استدعاء، بغض النظر عن وجود حقول source_dependency_groups أو raw_provenance_verification.
 *    - يتم تجميد الكائنات المطبّعة تجميدًا عميقًا (deepFreeze) بحيث يُمنع أي تعديل لاحق لحقل
 *      verified_raw_pipeline_cell أو غيره.
 * 2. فحص خيارات المحرك الموحد عبر جميع نقاط الدخول (validateEngineOptions):
 *    - رفض أي قيمة غير رقمية أو سالبة أو خارج المجال [0, 50] لخيار collinearityDiscountPoints،
 *      أو غير منطقية لـ allowQuarantinedAster، مع إرجاع valid_analysis: false و coverage_status: "INVALID_ENGINE_OPTIONS"
 *      بشكل موحد في كل من evaluateCellAtCoordinate و createEngine(...).analyzeCoordinate دون رمي استثناء غير معالج.
 * 3. الحماية من تجاوز المجال العددي العائم (Overflow-Safe Weight Scaling):
 *    - قسمة جميع الأوزان النشطة على أكبر وزن نشط (w / maxActiveWeight) قبل الضرب والجمع، بحيث تعمل الأوزان
 *      الضخمة مثل 1e308 بدقة رياضية تامة دون تجاوز Number.MAX_VALUE إلى Infinity / NaN.
 * 4. اتساق عداد عائلات الأدلة ومجموعات المصدر مع الأوزان الصفرية (Zero-Weight Exclusion Policy):
 *    - المؤشر الذي يُضبط وزنه المخصص على صفر (w === 0) لا يسهم في الدرجة، ولذلك يُستبعد أيضًا من عداد
 *      عائلات الأدلة الفعالة (available_families) ومن عداد العائلات والمصادر الداعمة (positive_supporting_families
 *      و positive_supporting_source_groups)؛ فمثلًا عند جعل وزن البنية وحده = 1 والبقية = 0 لخلية قيمها (88/84/72/80)،
 *      تكون الدرجة المرجعية 88 ولكن بعدد عائلات داعمة = 1 ومجموعة مصدر = 1، فتُحجب الفئتان A و B وتُصنّف REFERENCE_PRIORITY_C.
 * 5. حارس السلامة العددية النهائي (Final Finite Number Guard):
 *    - فحص أن النتيجة النهائية ودرجة جودة البيانات أعداد محدودة (Number.isFinite) قبل إرجاع valid_analysis: true.
 */

(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.BouhUnifiedEngine = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const ENGINE_VERSION = "1.5.0-STAGE1-2-AUDIT-LOCKED";
  const OWNER_NAME_AR = "أحمد أبو عزيزه الرشيدي";
  const EARTH_RADIUS_M = 6371000.0;
  const SPATIAL_BIN_DEG = 0.02; // ~2.2 km spatial index bucket

  // حدود البحث البرمجية المعلنة (Declared Software Search Heuristics)
  const HEURISTIC_DIRECT_CELL_RADIUS_M = 450;
  const HEURISTIC_MAX_SEARCH_RADIUS_M = 900;
  const MIN_REQUIRED_EVIDENCE_FAMILIES = 2;
  const MAX_COLLINEARITY_DISCOUNT_POINTS = 50.0;

  // الفئات المسموح لها بإنتاج درجة (مرجعية أو أساسية)؛ ما عداها يُستبعد حتمًا
  const ALLOWED_SCORING_CATEGORIES = Object.freeze(
    new Set(["COMPUTED_REMOTE_INDICATOR", "RAW_MEASUREMENT_BAND"])
  );

  // الفئات المحظور دخولها في حساب الدرجات حتمًا
  const FORBIDDEN_SCORING_CATEGORIES = Object.freeze(
    new Set([
      "UNVERIFIED_PRIOR",
      "RECYCLED_SCORE_PROXY",
      "DERIVED_PROXY",
      "CONTEXTUAL_HISTORICAL_PRIOR",
      "FIELD_VERIFICATION_RECORD",
      "FIELD_RESULT"
    ])
  );

  // التعريفات الثلاثة الموحدة لحدود بلاطة الارتفاعات الرقمية (n19_e036)
  const SRTM_N19_E036_BOUNDS_DEFINITIONS = Object.freeze({
    NOMINAL_1DEG: Object.freeze({
      lat_min: 19.0,
      lat_max: 20.0,
      lon_min: 36.0,
      lon_max: 37.0,
      description_ar: "المربع الاسمي للبلاطة (19°–20°N, 36°–37°E)"
    }),
    ACTUAL_1ARC_V3: Object.freeze({
      lat_min: 18.999861,
      lat_max: 20.000139,
      lon_min: 35.999861,
      lon_max: 37.000139,
      description_ar: "الحدود الفعلية لبلاطة 1-arc (n19_e036_1arc_v3.tif — 3601x3601)"
    }),
    ACTUAL_3ARC_V2: Object.freeze({
      lat_min: 18.999583,
      lat_max: 20.000417,
      lon_min: 35.999583,
      lon_max: 37.000417,
      description_ar: "الحدود الفعلية لبلاطة 3-arc (n19_e036_3arc_v2.tif — 1201x1201)"
    })
  });

  const SRTM_N19_E036_BOUNDS = SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_1ARC_V3;

  // مصفوفات الارتباط الإحصائي المرصودة فعليًا في بيانات التطبيق (Empirical Pearson Correlations)
  const EMPIRICAL_CORRELATIONS = Object.freeze({
    DP58: Object.freeze({
      r_structure_drainage: 0.890993,
      r_drainage_gpzProxy: 0.805182,
      r_structure_alteration: 0.061394,
      r_alteration_feox: 0.279325,
      r_structure_feox: 0.116068,
      r_feox_drainage: -0.065976
    }),
    ASTER_BOUH_NORTH: Object.freeze({
      r_structure_drainage: -0.509013,
      r_alteration_drainage: -0.850680,
      r_structure_magneticProxy: 0.723308,
      r_drainage_gpzProxy: 0.845309,
      r_structure_alteration: 0.406609,
      r_alteration_feox: 0.290184
    }),
    ASTER07XT_FULL: Object.freeze({
      r_structure_drainage: -0.185691,
      r_feox_drainage: -0.592205,
      r_drainage_gpzProxy: 0.847640,
      r_structure_magneticProxy: 0.422284,
      r_structure_alteration: -0.298599
    })
  });

  // المعاملات الهندسية الأولية غير المعايرة
  const INITIAL_HEURISTIC_PARAMETERS = Object.freeze({
    collinearity_r_threshold: 0.50,
    default_collinearity_discount_points: 8.0,
    max_collinearity_discount_points: MAX_COLLINEARITY_DISCOUNT_POINTS,
    feox_only_cap: 42,
    no_structure_no_alteration_cap: 35,
    require_two_source_groups_for_class_a: true,
    zero_weight_excludes_from_support_count: true,
    calibration_note_ar: "جميع هذه العتبات والخصومات والأوزان هي قواعد هندسية أولية غير معايرة ميدانيًا؛ تخضع لتحليل الحساسية ولا تعني أن الأوزان معايرة."
  });

  // تعريف عائلات الأدلة ومجموعات اعتماد المصدر الافتراضية
  const EVIDENCE_FAMILIES = Object.freeze({
    structure: {
      family_id: "STRUCTURAL_FABRIC",
      default_source_dependency_group: "SRC_GRP_DEM_AND_EDGE",
      name_ar: "عائلة البنية الجيولوجية والخطيات",
      base_weight: 0.35,
      weight_status: "UNVALIDATED_INITIAL_PRIOR",
      indicator_type: "COMPUTED_REMOTE_INDICATOR"
    },
    alteration: {
      family_id: "SPECTRAL_SWIR_ALTERATION",
      default_source_dependency_group: "SRC_GRP_OPTICAL_SWIR_VNIR",
      name_ar: "عائلة التحول الطيفي (SWIR Clay/Hydroxyl & Silica)",
      base_weight: 0.30,
      weight_status: "UNVALIDATED_INITIAL_PRIOR",
      indicator_type: "COMPUTED_REMOTE_INDICATOR"
    },
    drainage: {
      family_id: "TOPOGRAPHIC_MORPHOMETRY",
      default_source_dependency_group: "SRC_GRP_DEM_AND_EDGE",
      name_ar: "عائلة الجيومورفولوجيا وشبكات التصريف ومصائد الرواسب",
      base_weight: 0.20,
      weight_status: "UNVALIDATED_INITIAL_PRIOR",
      indicator_type: "COMPUTED_REMOTE_INDICATOR"
    },
    feox: {
      family_id: "SPECTRAL_VNIR_IRON",
      default_source_dependency_group: "SRC_GRP_OPTICAL_SWIR_VNIR",
      name_ar: "عائلة أكاسيد الحديد السطحية (VNIR Iron Oxides)",
      base_weight: 0.15,
      weight_status: "UNVALIDATED_INITIAL_PRIOR",
      indicator_type: "COMPUTED_REMOTE_INDICATOR"
    }
  });

  const BASE_WEIGHTS = Object.freeze({
    structure: 0.35,
    alteration: 0.30,
    drainage: 0.20,
    feox: 0.15
  });

  const INDICATOR_KEYS = Object.freeze(["structure", "alteration", "drainage", "feox"]);
  const SHA256_HEX_REGEX = /^[a-f0-9]{64}$/i;

  function deepFreeze(obj) {
    if (!obj || typeof obj !== "object") return obj;
    Object.freeze(obj);
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val && typeof val === "object" && !Object.isFrozen(val)) {
        deepFreeze(val);
      }
    }
    return obj;
  }

  function isValidNumber(val) {
    return (
      val !== null &&
      val !== undefined &&
      val !== "" &&
      typeof val !== "boolean" &&
      Number.isFinite(Number(val))
    );
  }

  /**
   * فحص صارم لصلاحية الإحداثيات الجغرافية ضمن حدود كوكب الأرض
   * lat في [-90, 90] و lon في [-180, 180]
   */
  function isValidGeographicCoordinate(lat, lon) {
    if (!isValidNumber(lat) || !isValidNumber(lon)) return false;
    const nLat = Number(lat);
    const nLon = Number(lon);
    return nLat >= -90.0 && nLat <= 90.0 && nLon >= -180.0 && nLon <= 180.0;
  }

  function toValidNumberOrNull(val) {
    if (!isValidNumber(val)) return null;
    const n = Number(val);
    return Math.max(0, Math.min(100, n));
  }

  /**
   * التحقق الصارم من كائن الأوزان المخصصة (Custom Weights Validation)
   * وتطبيعها بطريقة تمنع تجاوز المجال العددي العائم (Overflow-Safe Normalization via maxWeight)
   */
  function validateCustomWeights(customWeights) {
    if (customWeights === null || customWeights === undefined) {
      return { valid: true, weights: BASE_WEIGHTS, error_ar: null };
    }
    if (typeof customWeights !== "object" || Array.isArray(customWeights)) {
      return {
        valid: false,
        weights: null,
        error_ar: "كائن الأوزان المخصصة غير صالح (يجب أن يكون كائنًا)."
      };
    }

    const rawValidated = {};
    let maxWeight = 0;

    for (const k of Object.keys(customWeights)) {
      if (!INDICATOR_KEYS.includes(k)) {
        return {
          valid: false,
          weights: null,
          error_ar: `مفتاح وزن غير معروف (${k}). المفاتيح المسموحة: ${INDICATOR_KEYS.join(", ")}`
        };
      }
      const rawW = customWeights[k];
      if (!isValidNumber(rawW) || Number(rawW) < 0) {
        return {
          valid: false,
          weights: null,
          error_ar: `قيمة الوزن للمؤشر (${k}) غير صالحة (${String(rawW)})؛ يجب أن تكون رقمًا حقيقيًا محدودًا >= 0.`
        };
      }
    }

    for (const k of INDICATOR_KEYS) {
      const w = customWeights[k] !== undefined ? Number(customWeights[k]) : BASE_WEIGHTS[k];
      if (!Number.isFinite(w) || w < 0) {
        return {
          valid: false,
          weights: null,
          error_ar: `قيمة الوزن للمؤشر (${k}) غير صالحة.`
        };
      }
      rawValidated[k] = w;
      if (w > maxWeight) maxWeight = w;
    }

    if (maxWeight <= 0) {
      return {
        valid: false,
        weights: null,
        error_ar: "مجموع الأوزان المخصصة يجب أن يكون أكبر من الصفر."
      };
    }

    // قسمة كل وزن على maxWeight أولًا قبل حساب المجموع لمنع تجاوز المجال العددي (مثل 4 أوزان = 1e308)
    const scaledByMax = {};
    let scaledSum = 0;
    for (const k of INDICATOR_KEYS) {
      scaledByMax[k] = rawValidated[k] / maxWeight;
      scaledSum += scaledByMax[k];
    }

    if (!Number.isFinite(scaledSum) || scaledSum <= 0) {
      return {
        valid: false,
        weights: null,
        error_ar: "الأوزان المخصصة تؤدي إلى عدم استقرار عددي."
      };
    }

    const normalizedWeights = {};
    for (const k of INDICATOR_KEYS) {
      normalizedWeights[k] = scaledByMax[k] / scaledSum;
    }

    return { valid: true, weights: Object.freeze(normalizedWeights), error_ar: null };
  }

  /**
   * التحقق الصارم من خيارات المحرك (validateEngineOptions)
   * يمنع تمرير collinearityDiscountPoints غير رقمية ("bad") أو سالبة (-100) التي تتحول إلى رفع للدرجة
   */
  function validateEngineOptions(engineOptions) {
    if (engineOptions === null || engineOptions === undefined) {
      return {
        valid: true,
        options: {
          allowQuarantinedAster: false,
          collinearityDiscountPoints: INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points
        },
        error_ar: null
      };
    }
    if (typeof engineOptions !== "object" || Array.isArray(engineOptions)) {
      return {
        valid: false,
        options: null,
        error_ar: "خيارات المحرك (engineOptions) يجب أن تكون كائنًا صالحًا."
      };
    }

    let allowQuarantinedAster = false;
    if (engineOptions.allowQuarantinedAster !== undefined) {
      if (typeof engineOptions.allowQuarantinedAster !== "boolean") {
        return {
          valid: false,
          options: null,
          error_ar: "الخيار allowQuarantinedAster يجب أن يكون قيمة منطقية (boolean)."
        };
      }
      allowQuarantinedAster = engineOptions.allowQuarantinedAster;
    }

    let collinearityDiscountPoints = INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points;
    if (engineOptions.collinearityDiscountPoints !== undefined) {
      const rawDisc = engineOptions.collinearityDiscountPoints;
      if (
        !isValidNumber(rawDisc) ||
        Number(rawDisc) < 0 ||
        Number(rawDisc) > MAX_COLLINEARITY_DISCOUNT_POINTS
      ) {
        return {
          valid: false,
          options: null,
          error_ar: `قيمة خصم التلازم (collinearityDiscountPoints = ${String(rawDisc)}) غير صالحة؛ يجب أن تكون رقمًا محدودًا بين 0 و ${MAX_COLLINEARITY_DISCOUNT_POINTS}.`
        };
      }
      collinearityDiscountPoints = Number(rawDisc);
    }

    return {
      valid: true,
      options: {
        allowQuarantinedAster,
        collinearityDiscountPoints
      },
      error_ar: null
    };
  }

  function calculateDistanceMeters(lat1, lon1, lat2, lon2) {
    if (!isValidGeographicCoordinate(lat1, lon1) || !isValidGeographicCoordinate(lat2, lon2)) {
      return null;
    }
    const p = Math.PI / 180.0;
    const phi1 = Number(lat1) * p;
    const phi2 = Number(lat2) * p;
    const dPhi = (Number(lat2) - Number(lat1)) * p;
    const dLambda = (Number(lon2) - Number(lon1)) * p;
    const a =
      Math.sin(dPhi / 2) ** 2 +
      Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) ** 2;
    return 2 * EARTH_RADIUS_M * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function calculateBearing(lat1, lon1, lat2, lon2) {
    if (!isValidGeographicCoordinate(lat1, lon1) || !isValidGeographicCoordinate(lat2, lon2)) {
      return { bearing_deg: null, direction_ar: "غير متاح" };
    }
    const p = Math.PI / 180.0;
    const phi1 = Number(lat1) * p;
    const phi2 = Number(lat2) * p;
    const dLambda = (Number(lon2) - Number(lon1)) * p;
    const y = Math.sin(dLambda) * Math.cos(phi2);
    const x =
      Math.cos(phi1) * Math.sin(phi2) -
      Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLambda);
    const deg = ((Math.atan2(y, x) * 180.0) / Math.PI + 360.0) % 360.0;
    const dirs = ["شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب"];
    const idx = Math.round(deg / 45) % 8;
    return {
      bearing_deg: Math.round(deg),
      direction_ar: dirs[idx]
    };
  }

  function checkSrtmBoundsStatus(lat, lon) {
    if (!isValidGeographicCoordinate(lat, lon)) {
      return {
        outside_actual_1arc_v3: true,
        outside_nominal_1deg: true,
        outside_actual_3arc_v2: true
      };
    }
    const isOutside1Arc =
      lat > SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_1ARC_V3.lat_max ||
      lat < SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_1ARC_V3.lat_min ||
      lon > SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_1ARC_V3.lon_max ||
      lon < SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_1ARC_V3.lon_min;

    const isOutsideNominal =
      lat > SRTM_N19_E036_BOUNDS_DEFINITIONS.NOMINAL_1DEG.lat_max ||
      lat < SRTM_N19_E036_BOUNDS_DEFINITIONS.NOMINAL_1DEG.lat_min ||
      lon > SRTM_N19_E036_BOUNDS_DEFINITIONS.NOMINAL_1DEG.lon_max ||
      lon < SRTM_N19_E036_BOUNDS_DEFINITIONS.NOMINAL_1DEG.lon_min;

    const isOutside3Arc =
      lat > SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_3ARC_V2.lat_max ||
      lat < SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_3ARC_V2.lat_min ||
      lon > SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_3ARC_V2.lon_max ||
      lon < SRTM_N19_E036_BOUNDS_DEFINITIONS.ACTUAL_3ARC_V2.lon_min;

    return {
      outside_actual_1arc_v3: isOutside1Arc,
      outside_nominal_1deg: isOutsideNominal,
      outside_actual_3arc_v2: isOutside3Arc
    };
  }

  function isUnverifiedTop60OrCuratedPattern(id, zone, model, category) {
    const idStr = String(id || "").toUpperCase();
    const zoneStr = String(zone || "").toUpperCase();
    const modelStr = String(model || "").toUpperCase();
    const catStr = String(category || "").toUpperCase();

    return (
      catStr === "UNVERIFIED_PRIOR" ||
      idStr.startsWith("BOUH_TOP60") ||
      idStr.includes("TOP60") ||
      idStr.startsWith("CURATED_") ||
      zoneStr === "BOUH_FINAL_EXPANDED_TOP60" ||
      zoneStr.includes("TOP60") ||
      zoneStr.includes("CURATED") ||
      modelStr.includes("TOP60") ||
      modelStr.includes("BLIND_CONSENSUS")
    );
  }

  const LEGACY_INDEX_HTML_SHA256 = "48246b7094edd61678419685e54be3192ecc02f9d80ca2ae7ef85f9b2093bda9";

  function verifyRawPipelineProvenance(indicators, provenanceByIndicator) {
    if (!provenanceByIndicator || typeof provenanceByIndicator !== "object") {
      return {
        verified: false,
        reason_ar: "غياب كائن توثيق سلسلة المصدر (provenance_by_indicator) اللازم لتفعيل core_score."
      };
    }

    let validProvenanceCount = 0;
    for (const k of INDICATOR_KEYS) {
      const val = indicators[k];
      if (val === null || val === undefined) continue;

      const prov = provenanceByIndicator[k];
      if (!prov || typeof prov !== "object") {
        return {
          verified: false,
          reason_ar: `المؤشر المفعل (${k}) يفتقر إلى سجل توثيق المصدر الخام في provenance_by_indicator.${k}.`
        };
      }

      const srcFile = String(prov.actual_source_file || "").trim();
      const inHash = String(prov.input_file_sha256 || "").trim();
      const scriptHash = String(prov.processing_script_sha256 || "").trim();
      const procVer = String(prov.processing_version || "").trim();
      const maskApplied = prov.qa_or_scl_mask_applied === true;

      if (!srcFile || /index\.html|RAW_CELLS/i.test(srcFile)) {
        return {
          verified: false,
          reason_ar: `المؤشر (${k}) لا يرتبط بملف راستر خام أصلي صالح (${srcFile || "فارغ"}).`
        };
      }
      if (!SHA256_HEX_REGEX.test(inHash) || inHash.toLowerCase() === LEGACY_INDEX_HTML_SHA256) {
        return {
          verified: false,
          reason_ar: `المؤشر (${k}) يفتقر إلى بصمة SHA-256 صالحة لملف الراستر المدخل (input_file_sha256).`
        };
      }
      if (!SHA256_HEX_REGEX.test(scriptHash)) {
        return {
          verified: false,
          reason_ar: `المؤشر (${k}) يفتقر إلى بصمة SHA-256 صالحة لسكربت المعالجة (processing_script_sha256).`
        };
      }
      if (!procVer || /LEGACY/i.test(procVer)) {
        return {
          verified: false,
          reason_ar: `المؤشر (${k}) لا يحمل إصدار معالجة خام معتمد (processing_version).`
        };
      }
      if (!maskApplied) {
        return {
          verified: false,
          reason_ar: `المؤشر (${k}) لم يُثبت تطبيق قناع الجودة/السحب عليه (qa_or_scl_mask_applied !== true).`
        };
      }

      validProvenanceCount += 1;
    }

    if (validProvenanceCount < MIN_REQUIRED_EVIDENCE_FAMILIES) {
      return {
        verified: false,
        reason_ar: "عدد المؤشرات الموثقة بسلسلة مصدر خام كاملة أقل من الحد الأدنى المطلوب (2)."
      };
    }

    return {
      verified: true,
      reason_ar: "تم التحقق الهيكلي من سلسلة المصدر وبصمات SHA-256 وأقنعة الجودة لجميع المؤشرات."
    };
  }

  function resolveSourceDependencyGroups(rawRecord, provenanceByIndicator) {
    const groups = {};
    const customGroups =
      rawRecord && typeof rawRecord === "object" && !Array.isArray(rawRecord)
        ? rawRecord.source_dependency_groups || rawRecord.indicator_source_groups || null
        : null;

    for (const k of INDICATOR_KEYS) {
      const fromCustom = customGroups && typeof customGroups[k] === "string" && customGroups[k].trim()
        ? customGroups[k].trim()
        : null;
      const fromProv = provenanceByIndicator && provenanceByIndicator[k] && typeof provenanceByIndicator[k].source_dependency_group === "string" && provenanceByIndicator[k].source_dependency_group.trim()
        ? provenanceByIndicator[k].source_dependency_group.trim()
        : null;
      groups[k] = fromCustom || fromProv || EVIDENCE_FAMILIES[k].default_source_dependency_group;
    }
    return groups;
  }

  /**
   * تطبيع سجل الخلية الخام بشكل موحد تمامًا وتجميده (deepFreeze) لمنع أي تعديل لاحق
   */
  function normalizeCellRecord(rawRecord) {
    if (!rawRecord || typeof rawRecord !== "object") return null;

    let id = "";
    let zone = "";
    let lat = NaN;
    let lon = NaN;
    let model = "";
    let rawCategory = "COMPUTED_REMOTE_INDICATOR";
    let indSt = null;
    let indAlt = null;
    let indFe = null;
    let indDr = null;
    let proxyMag = null;
    let proxyLith = null;
    let proxyGpz = null;
    let rawHist = null;
    let rawOldFinal = null;
    let explicitEligible = undefined;
    let explicitEnabled = undefined;
    let explicitAsterConflict = undefined;
    let claimedRawPipeline = false;
    let provenanceByIndicator = null;

    if (Array.isArray(rawRecord)) {
      id = String(rawRecord[0] || "");
      zone = String(rawRecord[1] || "");
      lat = isValidNumber(rawRecord[2]) ? Number(rawRecord[2]) : NaN;
      lon = isValidNumber(rawRecord[3]) ? Number(rawRecord[3]) : NaN;
      rawOldFinal = toValidNumberOrNull(rawRecord[4]);
      indSt = toValidNumberOrNull(rawRecord[5]);
      indAlt = toValidNumberOrNull(rawRecord[6]);
      indFe = toValidNumberOrNull(rawRecord[7]);
      indDr = toValidNumberOrNull(rawRecord[8]);
      proxyMag = toValidNumberOrNull(rawRecord[9]);
      proxyLith = toValidNumberOrNull(rawRecord[10]);
      rawHist = rawRecord[11] === 0 ? null : toValidNumberOrNull(rawRecord[11]);
      proxyGpz = toValidNumberOrNull(rawRecord[12]);
      model = String(rawRecord[14] || "");
    } else {
      id = String(rawRecord.id || rawRecord.cell_id || "");
      zone = String(rawRecord.zone || "");
      const rLat = rawRecord.lat ?? rawRecord.latitude;
      const rLon = rawRecord.lon ?? rawRecord.longitude;
      lat = isValidNumber(rLat) ? Number(rLat) : NaN;
      lon = isValidNumber(rLon) ? Number(rLon) : NaN;
      model = String(rawRecord.source_model || rawRecord.source || rawRecord.model || "");
      rawCategory = String(rawRecord.indicator_category || rawRecord.category || "COMPUTED_REMOTE_INDICATOR").trim();
      indSt = toValidNumberOrNull(rawRecord.indicators?.structure ?? rawRecord.structure);
      indAlt = toValidNumberOrNull(rawRecord.indicators?.alteration ?? rawRecord.alteration);
      indFe = toValidNumberOrNull(rawRecord.indicators?.feox ?? rawRecord.feox);
      indDr = toValidNumberOrNull(rawRecord.indicators?.drainage ?? rawRecord.drainage);
      proxyMag = toValidNumberOrNull(rawRecord.proxies?.surface_roughness_proxy ?? rawRecord.magnetic);
      proxyLith = toValidNumberOrNull(rawRecord.proxies?.lithology_contrast_proxy ?? rawRecord.lithology);
      proxyGpz = toValidNumberOrNull(rawRecord.proxies?.gpz_terrain_proxy ?? rawRecord.gpz);
      const hVal = rawRecord.historical_klemm ?? rawRecord.historical;
      rawHist = hVal === 0 ? null : toValidNumberOrNull(hVal);
      rawOldFinal = toValidNumberOrNull(rawRecord.legacy_score_reference_only ?? rawRecord.oldFinal);
      explicitEligible = rawRecord.eligible_when_verified;
      explicitEnabled = rawRecord.enabled_now;
      explicitAsterConflict = rawRecord.has_unresolved_aster_bounds_conflict;
      // نتحقق دائمًا من الادعاء سواء جاء من سجل خام أو من سجل مطبّع عُدلت علامته يدويًا!
      claimedRawPipeline = Boolean(
        rawRecord.verified_raw_pipeline_cell === true || rawRecord.claimed_raw_pipeline_cell === true
      );
      provenanceByIndicator = rawRecord.provenance_by_indicator || null;
    }

    if (!isValidGeographicCoordinate(lat, lon)) {
      return null;
    }

    const isTop60OrCurated = isUnverifiedTop60OrCuratedPattern(id, zone, model, rawCategory);
    const effectiveCategory = isTop60OrCurated ? "UNVERIFIED_PRIOR" : rawCategory;
    const isForbiddenCategory =
      FORBIDDEN_SCORING_CATEGORIES.has(effectiveCategory) ||
      !ALLOWED_SCORING_CATEGORIES.has(effectiveCategory);

    const isAsterCell = Boolean(
      explicitAsterConflict ?? (id.toUpperCase().startsWith("ASTER") || zone.toUpperCase().startsWith("ASTER"))
    );

    const eligibleWhenVerified = isForbiddenCategory
      ? false
      : explicitEligible !== undefined
      ? Boolean(explicitEligible)
      : true;

    const enabledNow =
      isForbiddenCategory || !eligibleWhenVerified || isAsterCell
        ? false
        : explicitEnabled !== undefined
        ? Boolean(explicitEnabled)
        : true;

    const indicatorsObj = {
      structure: indSt,
      alteration: indAlt,
      feox: indFe,
      drainage: indDr
    };

    // يُعاد دائمًا فحص verifyRawPipelineProvenance فعليًا ولا يُقبل أي حقل raw_provenance_verification ممرر من الخارج!
    const provenanceCheck = claimedRawPipeline
      ? verifyRawPipelineProvenance(indicatorsObj, provenanceByIndicator)
      : { verified: false, reason_ar: "خلية مرجعية غير مولدة من خط أنابيب الراسترات الخام الموثق." };

    const verifiedRawPipelineCell = Boolean(claimedRawPipeline && provenanceCheck.verified && enabledNow);

    const sourceDependencyGroups = resolveSourceDependencyGroups(rawRecord, provenanceByIndicator);

    const zeroCols = [];
    if (indSt === 0) zeroCols.push("structure");
    if (indAlt === 0) zeroCols.push("alteration");
    if (indFe === 0) zeroCols.push("feox");
    if (indDr === 0) zeroCols.push("drainage");

    const srtmStatus = checkSrtmBoundsStatus(lat, lon);

    const normalizedObj = {
      id: id,
      zone: zone,
      lat: lat,
      lon: lon,
      source_model: model,
      indicator_category: effectiveCategory,
      is_forbidden_category: isForbiddenCategory,
      claimed_raw_pipeline_cell: claimedRawPipeline,
      verified_raw_pipeline_cell: verifiedRawPipelineCell,
      raw_provenance_verification: provenanceCheck,
      provenance_by_indicator: provenanceByIndicator,
      source_dependency_groups: sourceDependencyGroups,
      eligible_when_verified: eligibleWhenVerified,
      enabled_now: enabledNow,
      has_unresolved_aster_bounds_conflict: isAsterCell,
      verification_status: isTop60OrCurated
        ? "EXCLUDED_SYNTHETIC_PRIOR"
        : isForbiddenCategory
        ? `EXCLUDED_CATEGORY_${effectiveCategory}`
        : isAsterCell
        ? "QUARANTINED_ASTER_GEOSPATIAL_BOUNDS_CONFLICT"
        : !enabledNow
        ? "DISABLED_RECORD"
        : verifiedRawPipelineCell
        ? "VERIFIED_RAW_RASTER_PIPELINE"
        : "PROVISIONAL_LEGACY_REFERENCE_GRID_NO_SCL",
      data_quality_note:
        rawRecord && !Array.isArray(rawRecord) && rawRecord.data_quality_note
          ? String(rawRecord.data_quality_note)
          : isAsterCell
          ? "طبقة ASTER معلقة مؤقتًا لحين حسم تعارض حدود EPSG:32637 (19.50°–20.18°N) مع نطاق ASTER07XT_FULL (18.97°–19.61°N)"
          : verifiedRawPipelineCell
          ? "بيانات مولدة ومتحقق من سلسلة مصدرها الخام وبصماتها وأقنعتها"
          : "قيم مرجعية قديمة من شبكة DP58 (uint8 بدون طبقة SCL)؛ تنتج reference_score استرشادي فقط بينما يبقى core_score = null",
      indicators: indicatorsObj,
      zero_value_ambiguity_warning: Boolean(
        (!Array.isArray(rawRecord) && rawRecord.zero_value_ambiguity_warning !== undefined)
          ? rawRecord.zero_value_ambiguity_warning
          : zeroCols.length > 0
      ),
      zero_value_columns:
        !Array.isArray(rawRecord) && Array.isArray(rawRecord.zero_value_columns)
          ? [...rawRecord.zero_value_columns]
          : zeroCols,
      outside_srtm_n19_e036_tile: srtmStatus.outside_actual_1arc_v3,
      srtm_bounds_check: srtmStatus,
      proxies: {
        surface_roughness_proxy: proxyMag,
        lithology_contrast_proxy: proxyLith,
        gpz_terrain_proxy: proxyGpz
      },
      historical_klemm: rawHist,
      legacy_score_reference_only: rawOldFinal
    };

    return deepFreeze(normalizedObj);
  }

  /**
   * النواة الموحدة لحساب الدرجة وتطبيق جميع الحراس والقيود (Core Scoring & Guard Pipeline)
   * - تستخدم تطبيع أوزان محميًا من تجاوز المجال العددي العائم (Overflow-Safe Scaling via maxActiveWeight).
   * - تستبعد أي مؤشر ذي وزن صفري (w === 0) من عداد عائلات الأدلة الفعالة ومن عداد الدعم الإيجابي
   *   بحيث لا يمكن لمؤشر وزنه 0 أن يمنح الفئة A أو يرفع التقييم.
   */
  function computeGuardedScoreCore(ind, sourceGroupsMap, weightsObj, distFromQueryM, collinearityDiscountPoints) {
    const nonNullPresentFamilies = [];
    const activeWeightedFamilies = [];
    const positiveSupportingFamilies = [];
    const activeSourceGroups = new Set();
    const positiveSupportingSourceGroups = new Set();
    const missingIndicators = [];
    const zeroWeightExcludedIndicators = [];

    // الخطوة 1: إيجاد أقصى وزن بين المؤشرات المتوفرة غير الـ null لمنع تجاوز المجال العددي (مثل 1e308)
    let maxActiveWeight = 0;
    for (const key of INDICATOR_KEYS) {
      const val = ind[key];
      const rawW = Number(weightsObj[key] ?? EVIDENCE_FAMILIES[key].base_weight);
      if (val !== null && val !== undefined) {
        nonNullPresentFamilies.push(EVIDENCE_FAMILIES[key].family_id);
        if (Number.isFinite(rawW) && rawW > 0) {
          if (rawW > maxActiveWeight) maxActiveWeight = rawW;
        } else {
          zeroWeightExcludedIndicators.push(key);
        }
      } else {
        missingIndicators.push(key);
      }
    }

    if (nonNullPresentFamilies.length < MIN_REQUIRED_EVIDENCE_FAMILIES || maxActiveWeight <= 0) {
      return {
        valid: false,
        final_score: null,
        unclamped_weighted_average: null,
        available_families: activeWeightedFamilies,
        non_null_present_families: nonNullPresentFamilies,
        positive_supporting_families: positiveSupportingFamilies,
        available_source_groups: [],
        positive_supporting_source_groups: [],
        missing_indicators: missingIndicators,
        zero_weight_excluded_indicators: zeroWeightExcludedIndicators,
        is_single_source_collinear: false,
        shared_source_discount: 0,
        spatial_decay_penalty: 0,
        guards_applied: []
      };
    }

    // الخطوة 2: حساب المتوسط الموزون باستخدام الأوزان المقسومة على maxActiveWeight (آمن ضد 1e308)
    // مع قصر عداد العائلات الفعالة والداعمة على المؤشرات ذات الوزن الموجب فعليًا (w > 0)
    let weightedSum = 0.0;
    let activeWeightTotal = 0.0;

    for (const key of INDICATOR_KEYS) {
      const familyMeta = EVIDENCE_FAMILIES[key];
      const val = ind[key];
      const rawW = Number(weightsObj[key] ?? familyMeta.base_weight);
      const srcGrp = (sourceGroupsMap && sourceGroupsMap[key]) || familyMeta.default_source_dependency_group;

      if (val !== null && val !== undefined && Number.isFinite(rawW) && rawW > 0) {
        const scaledW = rawW / maxActiveWeight;
        weightedSum += val * scaledW;
        activeWeightTotal += scaledW;
        activeWeightedFamilies.push(familyMeta.family_id);
        activeSourceGroups.add(srcGrp);

        if (val >= 65) {
          positiveSupportingFamilies.push(familyMeta.family_id);
          positiveSupportingSourceGroups.add(srcGrp);
        }
      }
    }

    if (activeWeightTotal <= 0 || !Number.isFinite(weightedSum) || !Number.isFinite(activeWeightTotal)) {
      return {
        valid: false,
        final_score: null,
        unclamped_weighted_average: null,
        available_families: activeWeightedFamilies,
        non_null_present_families: nonNullPresentFamilies,
        positive_supporting_families: positiveSupportingFamilies,
        available_source_groups: Array.from(activeSourceGroups),
        positive_supporting_source_groups: Array.from(positiveSupportingSourceGroups),
        missing_indicators: missingIndicators,
        zero_weight_excluded_indicators: zeroWeightExcludedIndicators,
        is_single_source_collinear: false,
        shared_source_discount: 0,
        spatial_decay_penalty: 0,
        guards_applied: []
      };
    }

    const unclampedWeightedAvg = weightedSum / activeWeightTotal;
    let guardedRawScore = unclampedWeightedAvg;
    const guardsApplied = [];

    if (zeroWeightExcludedIndicators.length > 0) {
      guardsApplied.push("ZERO_WEIGHT_INDICATORS_EXCLUDED_FROM_SUPPORT");
    }

    // الحارس 1: منع رفع الهدف بسبب أكاسيد الحديد وحدها (FeOx-Only Guard)
    const isFeOxOnly =
      ind.feox !== null &&
      ind.feox >= 70 &&
      (ind.structure === null || ind.structure < 50) &&
      (ind.alteration === null || ind.alteration < 50) &&
      (ind.drainage === null || ind.drainage < 50);

    if (isFeOxOnly) {
      guardedRawScore = Math.min(guardedRawScore, INITIAL_HEURISTIC_PARAMETERS.feox_only_cap);
      guardsApplied.push("FEOX_ONLY_CAP_42");
    }

    // الحارس 2: غياب البنية والتحول معًا يمنع الترشيح (No-Structure No-Alteration Cap 35)
    if ((ind.structure === null || ind.structure < 30) && (ind.alteration === null || ind.alteration < 40)) {
      guardedRawScore = Math.min(guardedRawScore, INITIAL_HEURISTIC_PARAMETERS.no_structure_no_alteration_cap);
      guardsApplied.push("NO_STRUCTURE_NO_ALTERATION_CAP_35");
    }

    // الحارس 3: خصم التلازم الإحصائي / وحدة مجموعة المصدر الداعمة
    const isSingleSourceCollinear =
      positiveSupportingFamilies.length >= 2 && positiveSupportingSourceGroups.size === 1;

    let sharedSourceDiscount = 0;
    if (isSingleSourceCollinear) {
      const safeDisc = Number(collinearityDiscountPoints ?? INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points);
      sharedSourceDiscount = Number.isFinite(safeDisc)
        ? Math.max(0, Math.min(MAX_COLLINEARITY_DISCOUNT_POINTS, safeDisc))
        : INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points;
      if (sharedSourceDiscount > 0) {
        guardsApplied.push(`EMPIRICAL_COLLINEARITY_DISCOUNT_${sharedSourceDiscount}`);
      }
    }

    // الحارس 4: خصم عدم اليقين المكاني عند الابتعاد عن مركز الخلية المرجعية
    let spatialDecayPenalty = 0;
    const dM = Number(distFromQueryM || 0);
    if (dM > 150 && dM <= HEURISTIC_DIRECT_CELL_RADIUS_M) {
      spatialDecayPenalty = ((dM - 150) / 300.0) * 6.0;
    } else if (dM > HEURISTIC_DIRECT_CELL_RADIUS_M) {
      spatialDecayPenalty = 6.0 + ((dM - HEURISTIC_DIRECT_CELL_RADIUS_M) / 450.0) * 12.0;
    }

    const finalScore = Math.round(
      Math.max(0, Math.min(95, guardedRawScore - sharedSourceDiscount - spatialDecayPenalty))
    );

    if (!Number.isFinite(finalScore)) {
      return {
        valid: false,
        final_score: null,
        unclamped_weighted_average: null,
        available_families: activeWeightedFamilies,
        non_null_present_families: nonNullPresentFamilies,
        positive_supporting_families: positiveSupportingFamilies,
        available_source_groups: Array.from(activeSourceGroups),
        positive_supporting_source_groups: Array.from(positiveSupportingSourceGroups),
        missing_indicators: missingIndicators,
        zero_weight_excluded_indicators: zeroWeightExcludedIndicators,
        is_single_source_collinear: false,
        shared_source_discount: 0,
        spatial_decay_penalty: 0,
        guards_applied: []
      };
    }

    return {
      valid: true,
      final_score: finalScore,
      unclamped_weighted_average: Math.round(unclampedWeightedAvg),
      guarded_pre_discount_score: Math.round(guardedRawScore),
      available_families: activeWeightedFamilies,
      non_null_present_families: nonNullPresentFamilies,
      positive_supporting_families: positiveSupportingFamilies,
      available_source_groups: Array.from(activeSourceGroups),
      positive_supporting_source_groups: Array.from(positiveSupportingSourceGroups),
      missing_indicators: missingIndicators,
      zero_weight_excluded_indicators: zeroWeightExcludedIndicators,
      is_single_source_collinear: isSingleSourceCollinear,
      shared_source_discount: sharedSourceDiscount,
      spatial_decay_penalty: spatialDecayPenalty,
      guards_applied: guardsApplied
    };
  }

  function runWeightSensitivityAnalysis(
    ind,
    sourceGroupsMap = null,
    distFromQueryM = 0,
    collinearityDiscountPoints = INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points
  ) {
    const scenarios = [
      { name: "baseline_initial_priors", label_ar: "الأوزان الأولية الافتراضية (0.35/0.30/0.20/0.15)", weights: { structure: 0.35, alteration: 0.30, drainage: 0.20, feox: 0.15 } },
      { name: "equal_weights", label_ar: "أوزان متساوية (0.25 لكل مؤشر)", weights: { structure: 0.25, alteration: 0.25, drainage: 0.25, feox: 0.25 } },
      { name: "alteration_dominant", label_ar: "أولوية التحول الطيفي (0.45 تحول / 0.25 بنية)", weights: { structure: 0.25, alteration: 0.45, drainage: 0.15, feox: 0.15 } },
      { name: "structural_dominant", label_ar: "أولوية البنية والكسور (0.50 بنية / 0.25 تحول)", weights: { structure: 0.50, alteration: 0.25, drainage: 0.15, feox: 0.10 } },
      { name: "drainage_placer_dominant", label_ar: "أولوية التصريف الغريني (0.50 تصريف / 0.25 بنية)", weights: { structure: 0.25, alteration: 0.15, drainage: 0.50, feox: 0.10 } }
    ];

    const guardedScores = [];
    const scenarioResults = {};
    const unclampedScenarioResults = {};

    for (const sc of scenarios) {
      const coreRes = computeGuardedScoreCore(
        ind,
        sourceGroupsMap,
        sc.weights,
        distFromQueryM,
        collinearityDiscountPoints
      );
      scenarioResults[sc.name] = coreRes.valid ? coreRes.final_score : null;
      unclampedScenarioResults[sc.name] = coreRes.valid ? coreRes.unclamped_weighted_average : null;
      if (coreRes.valid && coreRes.final_score !== null) {
        guardedScores.push(coreRes.final_score);
      }
    }

    const collinearityDiscountSweep = {};
    for (const disc of [0, 4, 8, 12]) {
      const sweepRes = computeGuardedScoreCore(
        ind,
        sourceGroupsMap,
        BASE_WEIGHTS,
        distFromQueryM,
        disc
      );
      collinearityDiscountSweep[`discount_${disc}pt`] = sweepRes.valid ? sweepRes.final_score : null;
    }

    if (guardedScores.length === 0) {
      return {
        min_score: null,
        max_score: null,
        spread_range: null,
        is_sensitive_to_weights: false,
        scenarios: scenarioResults,
        unclamped_scenarios_before_guards: unclampedScenarioResults,
        collinearity_discount_sweep: collinearityDiscountSweep
      };
    }

    const minScore = Math.min(...guardedScores);
    const maxScore = Math.max(...guardedScores);
    return {
      min_score: minScore,
      max_score: maxScore,
      spread_range: maxScore - minScore,
      is_sensitive_to_weights: (maxScore - minScore) >= 15,
      scenarios: scenarioResults,
      unclamped_scenarios_before_guards: unclampedScenarioResults,
      collinearity_discount_sweep: collinearityDiscountSweep
    };
  }

  function computePathwayScores(ind, nonNullFamiliesCount, validatedWeights) {
    if (nonNullFamiliesCount < MIN_REQUIRED_EVIDENCE_FAMILIES) {
      return {
        placer_alluvial_score: null,
        vein_structural_score: null,
        general_recon_score: null,
        dominant_pathway_code: "INSUFFICIENT_DATA",
        dominant_pathway_ar: "بيانات غير كافية"
      };
    }

    const st = ind.structure ?? 0;
    const alt = ind.alteration ?? 0;
    const dr = ind.drainage ?? 0;
    const fe = ind.feox ?? 0;

    const placerScore =
      ind.drainage !== null
        ? Math.round(0.50 * dr + 0.25 * st + 0.15 * alt + 0.10 * fe)
        : null;

    const veinScore =
      ind.structure !== null && ind.alteration !== null
        ? Math.round(0.45 * st + 0.35 * alt + 0.15 * fe + 0.05 * dr)
        : null;

    const wSt = validatedWeights.structure;
    const wAlt = validatedWeights.alteration;
    const wDr = validatedWeights.drainage;
    const wFe = validatedWeights.feox;
    const wSum =
      (ind.structure !== null ? wSt : 0) +
      (ind.alteration !== null ? wAlt : 0) +
      (ind.drainage !== null ? wDr : 0) +
      (ind.feox !== null ? wFe : 0);

    const reconScore =
      wSum > 0
        ? Math.round(
            ((ind.structure !== null ? st * wSt : 0) +
              (ind.alteration !== null ? alt * wAlt : 0) +
              (ind.drainage !== null ? dr * wDr : 0) +
              (ind.feox !== null ? fe * wFe : 0)) /
              wSum
          )
        : null;

    let dominantCode = "GENERAL_RECON";
    let dominantAr = "استطلاع عام (يحتاج بيانات إضافية)";

    if (veinScore !== null && veinScore >= 65 && st >= 65 && alt >= 60 && (placerScore === null || veinScore >= placerScore)) {
      dominantCode = "VEIN_STRUCTURAL";
      dominantAr = "عروق وتمعدن مرتبط بالبنية";
    } else if (placerScore !== null && placerScore >= 65 && dr >= 65) {
      dominantCode = "PLACER_ALLUVIAL";
      dominantAr = "ذهب غريني ومصائد رواسب";
    }

    return {
      placer_alluvial_score: placerScore,
      vein_structural_score: veinScore,
      general_recon_score: reconScore,
      dominant_pathway_code: dominantCode,
      dominant_pathway_ar: dominantAr
    };
  }

  /**
   * الدالة الأساسية الموحدة لتقييم خلية مرجعية بالنسبة لإحداثية استعلام
   * تعيد تطبيع وفحص أي سجل يمر إليها عبر normalizeCellRecord(cellInput) في كل استدعاء دون استثناء!
   */
  function evaluateCellAtCoordinate(cellInput, queryLat, queryLon, userGpsObj = null, customWeights = null, engineOptions = {}) {
    // 0. فحص صلاحية إحداثية الاستعلام جغرافيًا
    if (!isValidGeographicCoordinate(queryLat, queryLon)) {
      return {
        valid_analysis: false,
        coverage_status: "INVALID_COORDINATE",
        coverage_label_ar: "إحداثية استعلام خارج النطاق الجغرافي الصالح ([-90..90], [-180..180])",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INVALID_INPUT",
        priority_class_ar: "مدخلات غير صالحة",
        engine_version: ENGINE_VERSION
      };
    }

    // 1. فحص صلاحية خيارات المحرك (validateEngineOptions) لمنع collinearityDiscountPoints غير الرقمية أو السالبة
    const optionsCheck = validateEngineOptions(engineOptions);
    if (!optionsCheck.valid) {
      return {
        valid_analysis: false,
        coverage_status: "INVALID_ENGINE_OPTIONS",
        coverage_label_ar: optionsCheck.error_ar,
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INVALID_OPTIONS",
        priority_class_ar: "خطأ في خيارات المحرك",
        error_details_ar: optionsCheck.error_ar,
        engine_version: ENGINE_VERSION
      };
    }

    // 2. فحص صلاحية الأوزان المخصصة وتطبيعها ضد تجاوز المجال العددي قبل أي حساب
    const weightCheck = validateCustomWeights(customWeights);
    if (!weightCheck.valid) {
      return {
        valid_analysis: false,
        coverage_status: "INVALID_CUSTOM_WEIGHTS",
        coverage_label_ar: weightCheck.error_ar,
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INVALID_WEIGHTS",
        priority_class_ar: "خطأ في الأوزان المدخلة",
        error_details_ar: weightCheck.error_ar,
        engine_version: ENGINE_VERSION
      };
    }

    // 3. إعادة تطبيع السجل وإعادة التحقق من سلسلة المصدر في كل استدعاء دون استثناء!
    // (يمنع تمامًا ثغرة تمرير سجل مطبّع تم تعديل verified_raw_pipeline_cell فيه يدويًا إلى true)
    const cell = normalizeCellRecord(cellInput);

    if (!cell) {
      return {
        valid_analysis: false,
        coverage_status: "INVALID_CELL_RECORD",
        coverage_label_ar: "سجل الخلية غير صالح أو يحمل إحداثيات خارج النطاق الجغرافي",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INVALID_CELL",
        priority_class_ar: "سجل غير صالح",
        engine_version: ENGINE_VERSION
      };
    }

    const allowQuarantinedAster = optionsCheck.options.allowQuarantinedAster;
    const collinearityDiscountSetting = optionsCheck.options.collinearityDiscountPoints;

    const distFromQueryM = calculateDistanceMeters(queryLat, queryLon, cell.lat, cell.lon);
    const bearingFromQuery = calculateBearing(queryLat, queryLon, cell.lat, cell.lon);

    const distFromUserGpsM =
      userGpsObj && isValidGeographicCoordinate(userGpsObj.lat, userGpsObj.lon)
        ? calculateDistanceMeters(userGpsObj.lat, userGpsObj.lon, cell.lat, cell.lon)
        : null;

    // 4. استبعاد كافة الفئات المحظورة
    if (cell.indicator_category === "UNVERIFIED_PRIOR" || cell.is_forbidden_category) {
      return {
        valid_analysis: false,
        coverage_status:
          cell.indicator_category === "UNVERIFIED_PRIOR"
            ? "UNVERIFIED_PRIOR_EXCLUDED"
            : `FORBIDDEN_CATEGORY_EXCLUDED_${cell.indicator_category}`,
        coverage_label_ar: `سجل مستبعد من الحساب لأن فئته (${cell.indicator_category}) غير مسموح لها بإنتاج درجة استطلاع`,
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "EXCLUDED_CATEGORY",
        priority_class_ar: "فئة مستبعدة من الحساب",
        distance_from_query_m: distFromQueryM !== null ? Math.round(distFromQueryM) : null,
        distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
        bearing_deg: bearingFromQuery.bearing_deg,
        direction_ar: bearingFromQuery.direction_ar,
        reference_cell: cell
      };
    }

    // 5. إيقاف ربط خلايا ASTER المتعارضة جغرافيًا بالأهداف
    if (cell.has_unresolved_aster_bounds_conflict && !allowQuarantinedAster) {
      return {
        valid_analysis: false,
        coverage_status: "QUARANTINED_GEOSPATIAL_BOUNDS_CONFLICT",
        coverage_label_ar: "بيانات معلقة للتدقيق — تعارض جغرافي في حدود طبقة ASTER يحتاج حسم المصدر",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "QUARANTINED_LAYER",
        priority_class_ar: "طبقة قيد التدقيق الجغرافي (غير مفعلة حاليًا)",
        distance_from_query_m: distFromQueryM !== null ? Math.round(distFromQueryM) : null,
        distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
        bearing_deg: bearingFromQuery.bearing_deg,
        direction_ar: bearingFromQuery.direction_ar,
        reference_cell: cell,
        supporting_evidence_ar: [],
        contrary_evidence_ar: [
          "تم تعليق ربط طبقة ASTER بالأهداف (enabled_now: false) لوجود تعارض بين حدود EPSG:32637 المسجلة في السجل (19.50°–20.18°N) وحدود ASTER07XT_FULL الجنوبية (18.97°–19.61°N)."
        ],
        required_verification_ar: "فحص ترويسات ملفات GeoTIFF الأصلية لمشهدي ASTER (01282007 و06122007) وحسم الإسناد الجغرافي قبل التفعيل."
      };
    }

    // 6. فرض أعلام التعطيل والصلاحية
    if (!cell.eligible_when_verified || (!cell.enabled_now && !(cell.has_unresolved_aster_bounds_conflict && allowQuarantinedAster))) {
      return {
        valid_analysis: false,
        coverage_status: "DISABLED_OR_INELIGIBLE_RECORD",
        coverage_label_ar: "السجل معطل حاليًا (enabled_now: false أو eligible_when_verified: false) ولا يدخل في التقييم",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "DISABLED_RECORD",
        priority_class_ar: "سجل معطل",
        distance_from_query_m: distFromQueryM !== null ? Math.round(distFromQueryM) : null,
        distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
        bearing_deg: bearingFromQuery.bearing_deg,
        direction_ar: bearingFromQuery.direction_ar,
        reference_cell: cell
      };
    }

    // 7. فحص حد البحث البرمجي المعلن (900m)
    if (distFromQueryM === null || distFromQueryM > HEURISTIC_MAX_SEARCH_RADIUS_M) {
      return {
        valid_analysis: false,
        coverage_status: "OUTSIDE_COVERAGE",
        coverage_label_ar: "بيانات غير كافية — خارج نطاق البحث المعلن للخلايا المفعلة",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INSUFFICIENT_DATA",
        priority_class_ar: "بيانات غير كافية",
        distance_from_query_m: distFromQueryM !== null ? Math.round(distFromQueryM) : null,
        distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
        bearing_deg: bearingFromQuery.bearing_deg,
        direction_ar: bearingFromQuery.direction_ar,
        search_radius_policy: {
          max_search_radius_m: HEURISTIC_MAX_SEARCH_RADIUS_M,
          definition_type: "DECLARED_SOFTWARE_SEARCH_HEURISTIC"
        },
        reference_cell: cell,
        supporting_evidence_ar: [],
        contrary_evidence_ar: [
          `الموقع يبعد أكثر من حد البحث البرمجي المعلن (${HEURISTIC_MAX_SEARCH_RADIUS_M}م) عن أقرب خلية مفعلة.`
        ],
        required_verification_ar: "إدخال بيانات أقمار صناعية خام (GeoTIFF) تغطي هذه المنطقة قبل إصدار أي ترشيح."
      };
    }

    // 8. تشغيل النواة الموحدة للحساب والحراس (computeGuardedScoreCore)
    const ind = cell.indicators;
    const validatedWeights = weightCheck.weights;
    const coreCalc = computeGuardedScoreCore(
      ind,
      cell.source_dependency_groups,
      validatedWeights,
      distFromQueryM,
      collinearityDiscountSetting
    );

    if (!coreCalc.valid || !Number.isFinite(coreCalc.final_score)) {
      return {
        valid_analysis: false,
        coverage_status: "INSUFFICIENT_INDICATORS",
        coverage_label_ar: "بيانات غير كافية — نقص في عائلات الأدلة الأساسية",
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        priority_class_code: "INSUFFICIENT_DATA",
        priority_class_ar: "بيانات غير كافية",
        distance_from_query_m: Math.round(distFromQueryM),
        distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
        bearing_deg: bearingFromQuery.bearing_deg,
        direction_ar: bearingFromQuery.direction_ar,
        missing_indicators: coreCalc.missing_indicators,
        reference_cell: cell,
        supporting_evidence_ar: [],
        contrary_evidence_ar: ["عدد عائلات الأدلة المتوفرة في هذه الخلية أقل من الحد الأدنى المطلوب للحساب."],
        required_verification_ar: "استكمال حزم البيانات المفقودة (" + coreCalc.missing_indicators.join(", ") + ")."
      };
    }

    const supportingEvidence = [];
    const contraryEvidence = [];
    const guardsApplied = [...coreCalc.guards_applied];
    const srcGroups = cell.source_dependency_groups;

    if (ind.structure !== null && validatedWeights.structure > 0) {
      if (ind.structure >= 65) supportingEvidence.push(`مؤشر خطيات/بنية مشتق داعم (${ind.structure}/100) [عائلة: STRUCTURAL_FABRIC | مصدر: ${srcGroups.structure}]`);
      else if (ind.structure < 35) contraryEvidence.push(`ضعف في مؤشر الخطيات/البنية المشتق (${ind.structure}/100)`);
    }

    if (ind.alteration !== null && validatedWeights.alteration > 0) {
      if (ind.alteration >= 65) supportingEvidence.push(`مؤشر تحول طيفي SWIR مشتق داعم (${ind.alteration}/100) [عائلة: SPECTRAL_SWIR_ALTERATION | مصدر: ${srcGroups.alteration}]`);
      else if (ind.alteration < 40) contraryEvidence.push(`ضعف في مؤشر التحول الطيفي المشتق (${ind.alteration}/100)`);
    }

    if (ind.drainage !== null && validatedWeights.drainage > 0) {
      if (ind.drainage >= 65) supportingEvidence.push(`مؤشر تصريف/مصائد رواسب مشتق مواتٍ (${ind.drainage}/100) [عائلة: TOPOGRAPHIC_MORPHOMETRY | مصدر: ${srcGroups.drainage}]`);
      else if (ind.drainage < 35) contraryEvidence.push(`ضعف في مؤشر التصريف/المصائد (${ind.drainage}/100)`);
    }

    if (ind.feox !== null && validatedWeights.feox > 0 && ind.feox >= 65 && !guardsApplied.includes("FEOX_ONLY_CAP_42")) {
      supportingEvidence.push(`مؤشر أكاسيد حديد مرافق للبنية/التحول (${ind.feox}/100) [عائلة: SPECTRAL_VNIR_IRON | مصدر: ${srcGroups.feox}]`);
    }

    if (coreCalc.zero_weight_excluded_indicators.length > 0) {
      contraryEvidence.push(
        `تنبيه الأوزان المخصصة: المؤشرات ذات الوزن الصفري (${coreCalc.zero_weight_excluded_indicators.join(", ")}) استُبعدت من دعم التصنيف ومن عداد عائلات الأدلة الفعالة.`
      );
    }

    if (guardsApplied.includes("FEOX_ONLY_CAP_42")) {
      contraryEvidence.push("أكاسيد الحديد مرتفعة منفردة دون بنية أو تحول كافٍ (سقف 42 لمنع إنذارات اللاتريت/البازلت).");
    }
    if (guardsApplied.includes("NO_STRUCTURE_NO_ALTERATION_CAP_35")) {
      contraryEvidence.push("غياب متزامن للبنية الجيولوجية والتحول الطيفي (سقف 35).");
    }
    if (coreCalc.is_single_source_collinear) {
      contraryEvidence.push(
        `تنبيه اعتماد المصدر: جميع المؤشرات الداعمة تنتمي لمجموعة مصدر واحدة (${coreCalc.positive_supporting_source_groups[0]})؛ طُبّق خصم هندسي أولي (${coreCalc.shared_source_discount} نقاط).`
      );
    }

    if (cell.zero_value_ambiguity_warning && cell.zero_value_columns.length > 0) {
      guardsApplied.push("LEGACY_ZERO_AMBIGUITY_FLAGGED");
      contraryEvidence.push(
        `تنبيه تدقيق: المؤشر (${cell.zero_value_columns.join(", ")}) يحمل القيمة 0 في المصفوفة المطبعة؛ أُبقيت القيمة 0 دون تحويل عشوائي إلى null لحين فحص قناع NoData/QA وسكربت التوليد الأصلي.`
      );
    }

    if (cell.claimed_raw_pipeline_cell && !cell.verified_raw_pipeline_cell) {
      guardsApplied.push("UNVERIFIED_RAW_PROVENANCE_DOWNGRADED_TO_REFERENCE");
      contraryEvidence.push(
        `رفض تفعيل core_score رغم وجود علامة verified_raw_pipeline_cell: ${cell.raw_provenance_verification.reason_ar}`
      );
    }

    if (distFromQueryM > HEURISTIC_DIRECT_CELL_RADIUS_M) {
      contraryEvidence.push(`الموقع ضمن نطاق البحث الخارجي (${Math.round(distFromQueryM)}م عن مركز الخلية المرجعية).`);
    }

    const computedScoreValue = coreCalc.final_score;

    // لا يُفعّل core_score إلا إذا اجتاز السجل فحص verifyRawPipelineProvenance الفعلي!
    const coreScore =
      cell.verified_raw_pipeline_cell && cell.raw_provenance_verification.verified === true
        ? computedScoreValue
        : null;
    const referenceScore = computedScoreValue;

    const activeFamiliesCount = coreCalc.available_families.length;
    const nonNullPresentCount = coreCalc.non_null_present_families.length;
    const completenessRatio = nonNullPresentCount / INDICATOR_KEYS.length;
    const distanceFactor = distFromQueryM <= 150 ? 1.0 : distFromQueryM <= 450 ? 0.85 : 0.65;
    const zeroAmbiguityPenalty = cell.zero_value_ambiguity_warning ? 10 : 0;
    const legacyTablePenalty = coreScore !== null ? 0 : 12;
    const dataQualityScore = Math.max(
      10,
      Math.round(100 * (0.65 * completenessRatio + 0.35 * distanceFactor) - zeroAmbiguityPenalty - legacyTablePenalty)
    );

    let priorityClassCode = "LOW_PRIORITY";
    let priorityClassAr = "أولوية استطلاع منخفضة / استبعاد أولي";

    if (
      computedScoreValue >= 78 &&
      dataQualityScore >= 70 &&
      coreCalc.positive_supporting_families.length >= 2 &&
      coreCalc.positive_supporting_source_groups.length >= 2
    ) {
      priorityClassCode = coreScore !== null ? "PRIORITY_A" : "REFERENCE_PRIORITY_A";
      priorityClassAr = coreScore !== null
        ? "أولوية استطلاع قصوى (فئة أ — معتمدة)"
        : "ترتيب مرجعي استرشادي مرتفع (فئة أ مرجعية — بانتظار التحليل الخام)";
    } else if (computedScoreValue >= 64 && dataQualityScore >= 60 && coreCalc.positive_supporting_families.length >= 2) {
      priorityClassCode = coreScore !== null ? "PRIORITY_B" : "REFERENCE_PRIORITY_B";
      priorityClassAr = coreScore !== null
        ? "أولوية استطلاع عالية (فئة ب — معتمدة)"
        : "ترتيب مرجعي استرشادي فوق المتوسط (فئة ب مرجعية — بانتظار التحليل الخام)";
    } else if (computedScoreValue >= 50) {
      priorityClassCode = coreScore !== null ? "PRIORITY_C" : "REFERENCE_PRIORITY_C";
      priorityClassAr = "أولوية استطلاع متوسطة (فئة ج — تحتاج تدقيقًا واستكمال بيانات)";
    }

    const pathways = computePathwayScores(ind, nonNullPresentCount, validatedWeights);
    const weightSensitivity = runWeightSensitivityAnalysis(
      ind,
      cell.source_dependency_groups,
      distFromQueryM,
      collinearityDiscountSetting
    );

    const recommendedSurveyRadiusM =
      pathways.dominant_pathway_code === "VEIN_STRUCTURAL" ? 150 :
      pathways.dominant_pathway_code === "PLACER_ALLUVIAL" ? 300 : 250;

    return {
      valid_analysis: true,
      operational_mode: coreScore !== null
        ? "VERIFIED_RAW_PIPELINE_MODE"
        : "PROVISIONAL_LEGACY_REFERENCE_MODE",
      coverage_status: distFromQueryM <= HEURISTIC_DIRECT_CELL_RADIUS_M ? "DIRECT_CELL_COVERAGE" : "EXTENDED_HEURISTIC_SEARCH_COVERAGE",
      coverage_label_ar: distFromQueryM <= HEURISTIC_DIRECT_CELL_RADIUS_M
        ? "ضمن النطاق المباشر للخلية المرجعية (≤ 450م)"
        : "ضمن حد البحث البرمجي الممتد (450م – 900م؛ عدم يقين مكاني أعلى)",
      search_radius_policy: {
        direct_cell_radius_m: HEURISTIC_DIRECT_CELL_RADIUS_M,
        max_search_radius_m: HEURISTIC_MAX_SEARCH_RADIUS_M,
        definition_type: "DECLARED_SOFTWARE_SEARCH_HEURISTIC"
      },
      score_label_ar: coreScore !== null
        ? "أولوية الاستطلاع المعتمدة (Core Score)"
        : "ترتيب مرجعي استرشادي غير متحقق (Reference Score — بانتظار معالجة الراسترات الخام)",
      core_score: coreScore,
      reference_score: referenceScore,
      reconnaissance_priority_score: referenceScore,
      raw_provenance_verification: cell.raw_provenance_verification,
      weights_calibration_status: "UNVALIDATED_INITIAL_HEURISTIC_PARAMETERS",
      epistemological_disclaimer_ar:
        "التشغيل الحالي على مصفوفة RAW_CELLS يمثل إعادة تنظيم وتقييم استرشادي للمراجع القديمة (reference_score) وليس تحليلًا جديدًا من الراسترات الأصلية؛ لذا يبقى core_score = null ما لم تثبت سلسلة المصدر الخام لكل مؤشر.",
      priority_class_code: priorityClassCode,
      priority_class_ar: priorityClassAr,
      data_quality_score: dataQualityScore,
      evidence_independence_summary: {
        available_families_count: activeFamiliesCount,
        available_families: coreCalc.available_families,
        non_null_present_families_count: nonNullPresentCount,
        non_null_present_families: coreCalc.non_null_present_families,
        zero_weight_excluded_indicators: coreCalc.zero_weight_excluded_indicators,
        positive_supporting_families_count: coreCalc.positive_supporting_families.length,
        positive_supporting_families: coreCalc.positive_supporting_families,
        indicator_source_dependency_groups: cell.source_dependency_groups,
        available_source_dependency_groups: coreCalc.available_source_groups,
        positive_supporting_source_groups_count: coreCalc.positive_supporting_source_groups.length,
        positive_supporting_source_groups: coreCalc.positive_supporting_source_groups,
        shared_source_discount_applied: coreCalc.shared_source_discount
      },
      weight_sensitivity_analysis: weightSensitivity,
      missing_indicators: coreCalc.missing_indicators,
      zero_value_ambiguity_warning: cell.zero_value_ambiguity_warning,
      zero_value_columns: cell.zero_value_columns,
      distance_from_query_m: Math.round(distFromQueryM),
      distance_from_gps_m: distFromUserGpsM !== null ? Math.round(distFromUserGpsM) : null,
      bearing_deg: bearingFromQuery.bearing_deg,
      direction_ar: bearingFromQuery.direction_ar,
      uncertainty_radius_m: Math.round(Math.max(30, distFromQueryM)),
      recommended_survey_area_m2: Math.round(Math.PI * recommendedSurveyRadiusM * recommendedSurveyRadiusM),
      recommended_survey_radius_m: recommendedSurveyRadiusM,
      pathways: pathways,
      computed_remote_indicators: {
        structure: ind.structure,
        alteration: ind.alteration,
        feox: ind.feox,
        drainage: ind.drainage
      },
      contextual_historical_prior: {
        klemm_historical_value: cell.historical_klemm,
        note_ar: "دليل سياقي لتاريخ التعدين القديم فقط وليس قياسًا لوجود خام متبقٍ حاليًا."
      },
      recycled_proxies_display_only: {
        note_ar: "مؤشرات بديلة قديمة للعرض الاسترشادي فقط — مستبعدة من حساب الدرجة الأساسية والمرجعية ومن عداد الأدلة",
        surface_roughness_proxy: cell.proxies.surface_roughness_proxy,
        lithology_contrast_proxy: cell.proxies.lithology_contrast_proxy,
        gpz_terrain_proxy: cell.proxies.gpz_terrain_proxy
      },
      supporting_evidence_ar: supportingEvidence,
      contrary_evidence_ar: contraryEvidence,
      guards_applied: guardsApplied,
      required_verification_ar:
        pathways.dominant_pathway_code === "VEIN_STRUCTURAL"
          ? "التحقق الميداني من أن الخطيات المستخرجة تمثل كسورًا أو عروق مرو حقيقية وليست حواف طبقات أو طرقًا، مع أخذ عينات صخرية وتوثيق الفحص."
          : pathways.dominant_pathway_code === "PLACER_ALLUVIAL"
          ? "فحص حواف الوادي ومصائد الرواسب وانكسار الميل وأخذ عينات مركزات ثقيلة/فحص GPZ منهجي مع تسجيل المساحة والزمن."
          : "فحص استطلاعي عام للتأكد من انكشاف الصخر وعدم وجود غطاء رملي أو تشويش سطحي.",
      reference_cell: {
        id: cell.id,
        zone: cell.zone,
        lat: cell.lat,
        lon: cell.lon,
        source_model: cell.source_model,
        indicator_category: cell.indicator_category,
        verified_raw_pipeline_cell: cell.verified_raw_pipeline_cell,
        eligible_when_verified: cell.eligible_when_verified,
        enabled_now: cell.enabled_now,
        verification_status: cell.verification_status,
        srtm_bounds_check: cell.srtm_bounds_check,
        data_quality_note: cell.data_quality_note
      },
      owner: OWNER_NAME_AR,
      engine_version: ENGINE_VERSION
    };
  }

  /**
   * إنشاء نسخة المحرك الموحد مع الفهرس المكاني المحصّن
   */
  function createEngine(rawCellsArray, engineOptions = {}) {
    const optionsCheck = validateEngineOptions(engineOptions);
    const hasValidInitialOptions = optionsCheck.valid;
    const validatedEngineOptions = hasValidInitialOptions
      ? optionsCheck.options
      : {
          allowQuarantinedAster: false,
          collinearityDiscountPoints: INITIAL_HEURISTIC_PARAMETERS.default_collinearity_discount_points
        };
    const allowQuarantinedAster = validatedEngineOptions.allowQuarantinedAster;

    const buckets = new Map();
    const activeCells = [];
    const quarantinedCells = [];
    const excludedPriorCells = [];
    const disabledOrRejectedCells = [];

    function bucketKey(lat, lon) {
      return Math.floor(lat / SPATIAL_BIN_DEG) + "," + Math.floor(lon / SPATIAL_BIN_DEG);
    }

    if (hasValidInitialOptions && Array.isArray(rawCellsArray)) {
      for (let i = 0; i < rawCellsArray.length; i++) {
        const norm = normalizeCellRecord(rawCellsArray[i]);
        if (!norm) {
          disabledOrRejectedCells.push(rawCellsArray[i]);
          continue;
        }

        if (norm.indicator_category === "UNVERIFIED_PRIOR" || norm.is_forbidden_category) {
          excludedPriorCells.push(norm);
          continue;
        }

        if (norm.has_unresolved_aster_bounds_conflict && !allowQuarantinedAster) {
          quarantinedCells.push(norm);
          continue;
        }

        if (!norm.eligible_when_verified || (!norm.enabled_now && !(norm.has_unresolved_aster_bounds_conflict && allowQuarantinedAster))) {
          disabledOrRejectedCells.push(norm);
          continue;
        }

        activeCells.push(norm);
        const k = bucketKey(norm.lat, norm.lon);
        if (!buckets.has(k)) buckets.set(k, []);
        buckets.get(k).push(norm);
      }
    }

    function getCandidateCellsNear(lat, lon, searchRings = 2) {
      const bi = Math.floor(lat / SPATIAL_BIN_DEG);
      const bj = Math.floor(lon / SPATIAL_BIN_DEG);
      const candidates = [];
      for (let di = -searchRings; di <= searchRings; di++) {
        for (let dj = -searchRings; dj <= searchRings; dj++) {
          const arr = buckets.get(bi + di + "," + (bj + dj));
          if (arr) candidates.push(...arr);
        }
      }
      return candidates;
    }

    function analyzeCoordinate(queryLat, queryLon, userGpsObj = null, customWeights = null, callOptions = null) {
      if (!isValidGeographicCoordinate(queryLat, queryLon)) {
        return {
          valid_analysis: false,
          coverage_status: "INVALID_COORDINATE",
          coverage_label_ar: "إحداثية غير صالحة أو خارج النطاق الجغرافي للأرض ([-90..90], [-180..180])",
          core_score: null,
          reference_score: null,
          reconnaissance_priority_score: null,
          priority_class_code: "INVALID_INPUT",
          priority_class_ar: "إحداثية غير صالحة",
          engine_version: ENGINE_VERSION
        };
      }

      const activeEngineOptions = callOptions !== null ? callOptions : (hasValidInitialOptions ? validatedEngineOptions : engineOptions);
      const optCheck = validateEngineOptions(activeEngineOptions);
      if (!optCheck.valid) {
        return {
          valid_analysis: false,
          coverage_status: "INVALID_ENGINE_OPTIONS",
          coverage_label_ar: optCheck.error_ar,
          core_score: null,
          reference_score: null,
          reconnaissance_priority_score: null,
          priority_class_code: "INVALID_OPTIONS",
          priority_class_ar: "خطأ في خيارات المحرك",
          error_details_ar: optCheck.error_ar,
          engine_version: ENGINE_VERSION
        };
      }

      const weightCheck = validateCustomWeights(customWeights);
      if (!weightCheck.valid) {
        return {
          valid_analysis: false,
          coverage_status: "INVALID_CUSTOM_WEIGHTS",
          coverage_label_ar: weightCheck.error_ar,
          core_score: null,
          reference_score: null,
          reconnaissance_priority_score: null,
          priority_class_code: "INVALID_WEIGHTS",
          priority_class_ar: "خطأ في الأوزان المدخلة",
          error_details_ar: weightCheck.error_ar,
          engine_version: ENGINE_VERSION
        };
      }

      const lat = Number(queryLat);
      const lon = Number(queryLon);
      const candidates = getCandidateCellsNear(lat, lon, 2);

      let nearestCell = null;
      let minDistanceM = Infinity;

      for (let i = 0; i < candidates.length; i++) {
        const c = candidates[i];
        const d = calculateDistanceMeters(lat, lon, c.lat, c.lon);
        if (d !== null && d < minDistanceM) {
          minDistanceM = d;
          nearestCell = c;
        }
      }

      if (!nearestCell || minDistanceM > HEURISTIC_MAX_SEARCH_RADIUS_M) {
        return {
          valid_analysis: false,
          coverage_status: "OUTSIDE_COVERAGE",
          coverage_label_ar: "بيانات غير كافية — المنطقة خارج نطاق البحث المعلن للخلايا المفعلة",
          score_label_ar: "أولوية الاستطلاع",
          core_score: null,
          reference_score: null,
          reconnaissance_priority_score: null,
          priority_class_code: "INSUFFICIENT_DATA",
          priority_class_ar: "بيانات غير كافية",
          distance_from_query_m: Number.isFinite(minDistanceM) ? Math.round(minDistanceM) : null,
          search_radius_policy: {
            max_search_radius_m: HEURISTIC_MAX_SEARCH_RADIUS_M,
            definition_type: "DECLARED_SOFTWARE_SEARCH_HEURISTIC"
          },
          coordinates: {
            map_center: { lat, lon },
            user_gps: userGpsObj || null,
            reference_cell: nearestCell
              ? { id: nearestCell.id, lat: nearestCell.lat, lon: nearestCell.lon, distance_m: Math.round(minDistanceM) }
              : null
          },
          supporting_evidence_ar: [],
          contrary_evidence_ar: [`الموقع يبعد أكثر من حد البحث البرمجي المعلن (${HEURISTIC_MAX_SEARCH_RADIUS_M}م) عن أقرب خلية مفعلة.`],
          required_verification_ar: "لا يظهر ترشيح قابل للاعتماد خارج التغطية؛ انتقل إلى نطاق مغطى أو أضف بيانات خام.",
          owner: OWNER_NAME_AR,
          engine_version: ENGINE_VERSION
        };
      }

      const evaluation = evaluateCellAtCoordinate(
        nearestCell,
        lat,
        lon,
        userGpsObj,
        customWeights,
        optCheck.options
      );
      evaluation.coordinates = {
        map_center: { lat, lon },
        user_gps: userGpsObj || null,
        reference_cell: {
          id: nearestCell.id,
          lat: nearestCell.lat,
          lon: nearestCell.lon,
          zone: nearestCell.zone
        }
      };
      return evaluation;
    }

    function getNearestTargets(queryLat, queryLon, options = {}) {
      if (!isValidGeographicCoordinate(queryLat, queryLon)) {
        return [];
      }
      const customWeights = options.customWeights || null;
      if (!validateCustomWeights(customWeights).valid) {
        return [];
      }
      const callEngineOptions = options.engineOptions !== undefined ? options.engineOptions : (hasValidInitialOptions ? validatedEngineOptions : engineOptions);
      if (!validateEngineOptions(callEngineOptions).valid) {
        return [];
      }

      const maxRadiusM = Number(options.maxRadiusM || 5000);
      const minScore = Number(options.minScore ?? 50);
      const limit = Number(options.limit || 20);
      const pathwayFilter = options.pathwayFilter || null;
      const userGpsObj = options.userGps || null;

      const lat = Number(queryLat);
      const lon = Number(queryLon);
      const rings = Math.max(2, Math.ceil(maxRadiusM / 2200));
      const candidates = getCandidateCellsNear(lat, lon, rings);

      const results = [];
      for (let i = 0; i < candidates.length; i++) {
        const c = candidates[i];
        const distFromQuery = calculateDistanceMeters(lat, lon, c.lat, c.lon);
        if (distFromQuery === null || distFromQuery > maxRadiusM) continue;

        const cellEval = evaluateCellAtCoordinate(
          c,
          c.lat,
          c.lon,
          userGpsObj,
          customWeights,
          callEngineOptions
        );
        if (!cellEval.valid_analysis || cellEval.reference_score === null) continue;
        if (cellEval.reference_score < minScore) continue;
        if (pathwayFilter && cellEval.pathways.dominant_pathway_code !== pathwayFilter) continue;

        const bearingObj = calculateBearing(lat, lon, c.lat, c.lon);
        cellEval.distance_from_query_m = Math.round(distFromQuery);
        cellEval.bearing_deg = bearingObj.bearing_deg;
        cellEval.direction_ar = bearingObj.direction_ar;
        results.push(cellEval);
      }

      results.sort((a, b) => {
        if (b.reference_score !== a.reference_score) {
          return b.reference_score - a.reference_score;
        }
        return (a.distance_from_query_m || 999999) - (b.distance_from_query_m || 999999);
      });

      return results.slice(0, limit);
    }

    return {
      version: ENGINE_VERSION,
      owner: OWNER_NAME_AR,
      engineOptionsValid: hasValidInitialOptions,
      engineOptionsErrorAr: optionsCheck.error_ar,
      totalActiveCells: activeCells.length,
      totalQuarantinedAsterCells: quarantinedCells.length,
      totalExcludedPriorCells: excludedPriorCells.length,
      totalDisabledOrRejectedCells: disabledOrRejectedCells.length,
      analyzeCoordinate,
      getNearestTargets,
      runWeightSensitivityAnalysis,
      checkSrtmBoundsStatus,
      isValidGeographicCoordinate,
      validateCustomWeights,
      validateEngineOptions,
      verifyRawPipelineProvenance,
      calculateDistanceMeters,
      calculateBearing
    };
  }

  return {
    ENGINE_VERSION,
    OWNER_NAME_AR,
    ALLOWED_SCORING_CATEGORIES,
    FORBIDDEN_SCORING_CATEGORIES,
    EVIDENCE_FAMILIES,
    EMPIRICAL_CORRELATIONS,
    INITIAL_HEURISTIC_PARAMETERS,
    BASE_WEIGHTS,
    HEURISTIC_DIRECT_CELL_RADIUS_M,
    HEURISTIC_MAX_SEARCH_RADIUS_M,
    SRTM_N19_E036_BOUNDS_DEFINITIONS,
    SRTM_N19_E036_BOUNDS,
    createEngine,
    normalizeCellRecord,
    evaluateCellAtCoordinate,
    computeGuardedScoreCore,
    runWeightSensitivityAnalysis,
    checkSrtmBoundsStatus,
    isValidGeographicCoordinate,
    validateCustomWeights,
    validateEngineOptions,
    verifyRawPipelineProvenance,
    calculateDistanceMeters,
    calculateBearing
  };
});
