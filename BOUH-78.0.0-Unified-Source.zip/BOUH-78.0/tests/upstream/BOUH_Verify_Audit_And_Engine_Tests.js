/**
 * BOUH Standalone Node.js Verification, Audit & UI Integration Test Suite (v1.5.0 - Integration-Locked Edition)
 * سكربت الاختبار والتحقق الآلي المستقل للمحرك الموحد وجسر الواجهة والتقارير ومصفوفة التطبيق الأصلي
 * المالك: أحمد أبو عزيزه الرشيدي
 *
 * طريقة التشغيل:
 *   node BOUH_Verify_Audit_And_Engine_Tests.js [مسار_اختياري_لملف_index.html] [مسار_اختياري_لحفظ_index_المدمج.html]
 *
 * يتحقق هذا السكربت بالـ Assertions الصارمة من (18/18 فئة اختبار):
 * 1. المطابقة التلقائية لبصمات SHA-256 وأحجام البايتات لجميع الملفات الخمسة مع ملف CHECKSUMS.sha256.
 * 2. الحالات الـ 13 للمحرك الموحد (إغلاق جميع ثغرات قبول السجلات، تحقق المصدر، استقرار الأوزان 1e308، الأوزان الصفرية، وخيارات المحرك).
 * 3. اختبارات الدمج وتطابق الواجهة والتقارير (الحالات 14–18):
 *    - 14. التطابق التام (100% Parity) بين تحليل الخريطة (analyze)، وقائمة الأهداف القريبة (nearestTargets)،
 *          وعلامات الخريطة (cells)، والأهداف المحفوظة، والتقارير الخمسة (CSV, KML, GeoJSON, JSON, HTML).
 *    - 15. ثبات الدرجة المرجعية للهدف عند تحريك الخريطة (Pan-Invariance) ودقة حساب المسافة والاتجاه من مركز الاستعلام.
 *    - 16. فصل المنطقة غير المغطاة والبيانات المفقودة (null / «بيانات غير كافية») عن القيمة صفر، ومنع حفظ أهداف خارج التغطية.
 *    - 17. محاكاة بيئة المتصفح (DOM / window.BOUH) والتحقق من استبدال «احتمال الذهب» بـ «أولوية الاستطلاع» وتعطيل core_score.
 *    - 18. إصلاح خطأ JavaScript النحوي في assets/index.html الأصلي والتحقق بالترجمة الفعلية (vm.Script) وتشغيل اختبار التطابق
 *          المباشر على مصفوفة الـ 119,918 خلية الفعلية.
 */

"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const vm = require("vm");

const dir = __dirname;
const enginePath = path.join(dir, "BOUH_Unified_Engine_v1.js");
const bridgePath = path.join(dir, "BOUH_UI_Unified_Integration_Bridge_v1.js");
const registryPath = path.join(dir, "BOUH_Audited_Database_Registry_v1.json");
const planPath = path.join(dir, "BOUH_Master_Plan_and_Audit_Stages_1_to_6_AR.md");
const checksumsPath = path.join(dir, "CHECKSUMS.sha256");

function sha256File(filePath) {
  const buf = fs.readFileSync(filePath);
  return {
    bytes: buf.length,
    sha256: crypto.createHash("sha256").update(buf).digest("hex")
  };
}

function pearsonCorrelation(xs, ys) {
  assert.strictEqual(xs.length, ys.length, "Arrays must have equal length");
  const n = xs.length;
  let sumX = 0;
  let sumY = 0;
  for (let i = 0; i < n; i++) {
    sumX += xs[i];
    sumY += ys[i];
  }
  const meanX = sumX / n;
  const meanY = sumY / n;
  let num = 0;
  let denX = 0;
  let denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    const dy = ys[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }
  return num / Math.sqrt(denX * denY);
}

console.log("=== [1] التحقق التلقائي من الملفات الخمسة ومطابقة CHECKSUMS.sha256 ===");
for (const [label, p] of [
  ["Engine JS", enginePath],
  ["UI Bridge JS", bridgePath],
  ["Registry JSON", registryPath],
  ["Master Plan MD", planPath]
]) {
  assert.ok(fs.existsSync(p), `Missing file: ${p}`);
  const info = sha256File(p);
  console.log(`  [OK] ${label}: ${path.basename(p)} | Size: ${info.bytes} bytes | SHA-256: ${info.sha256}`);
}

if (fs.existsSync(checksumsPath)) {
  const lines = fs.readFileSync(checksumsPath, "utf8").split(/\r?\n/);
  let verifiedCount = 0;
  for (const line of lines) {
    const m = line.match(/^([a-f0-9]{64})\s+([^\s]+)\s+\((\d+)\s+bytes\)$/i);
    if (m) {
      const [, expectedHash, fileName, expectedBytesStr] = m;
      const targetPath = path.join(dir, fileName);
      assert.ok(fs.existsSync(targetPath), `File listed in CHECKSUMS.sha256 not found: ${fileName}`);
      const actual = sha256File(targetPath);
      assert.strictEqual(actual.sha256, expectedHash.toLowerCase(), `SHA-256 mismatch for ${fileName}`);
      assert.strictEqual(actual.bytes, Number(expectedBytesStr), `Byte size mismatch for ${fileName}`);
      verifiedCount += 1;
    }
  }
  assert.ok(verifiedCount >= 5, "CHECKSUMS.sha256 must verify all 5 deliverable files");
  console.log(`  [OK] تمت المطابقة الآلية الصارمة لـ ${verifiedCount} ملفات مع CHECKSUMS.sha256.`);
}

const BouhEngine = require(enginePath);
const BouhUIBridge = require(bridgePath);
const Registry = JSON.parse(fs.readFileSync(registryPath, "utf8"));

assert.strictEqual(BouhEngine.ENGINE_VERSION, "1.5.0-STAGE1-2-AUDIT-LOCKED");
assert.strictEqual(BouhUIBridge.BRIDGE_VERSION, "1.5.0-STAGE1-2-UI-INTEGRATION-LOCKED");
assert.strictEqual(Registry.schema_version, "2.5.0-stage2-audit-locked");

console.log("\n=== [2] اختبار الحالات الثماني الأساسية (الجولة الأولى) ===");

const disabledObjCell = {
  id: "TEST_DISABLED_01",
  zone: "CENTER",
  lat: 19.5000,
  lon: 36.5000,
  enabled_now: false,
  eligible_when_verified: false,
  indicators: { structure: 88, alteration: 84, feox: 72, drainage: 80 }
};
const eng1 = BouhEngine.createEngine([disabledObjCell]);
assert.strictEqual(eng1.totalActiveCells, 0);
const resDisabled = BouhEngine.evaluateCellAtCoordinate(disabledObjCell, 19.5000, 36.5000);
assert.strictEqual(resDisabled.valid_analysis, false);
assert.strictEqual(resDisabled.coverage_status, "DISABLED_OR_INELIGIBLE_RECORD");

for (const forbiddenCat of ["RECYCLED_SCORE_PROXY", "DERIVED_PROXY", "CONTEXTUAL_HISTORICAL_PRIOR", "FIELD_VERIFICATION_RECORD", "UNVERIFIED_PRIOR"]) {
  const forbiddenCell = {
    id: `TEST_FORBIDDEN_${forbiddenCat}`,
    zone: "CENTER",
    lat: 19.5100,
    lon: 36.5100,
    indicator_category: forbiddenCat,
    enabled_now: true,
    eligible_when_verified: true,
    indicators: { structure: 90, alteration: 88, feox: 75, drainage: 80 }
  };
  assert.strictEqual(BouhEngine.createEngine([forbiddenCell]).totalActiveCells, 0);
  assert.strictEqual(BouhEngine.evaluateCellAtCoordinate(forbiddenCell, 19.5100, 36.5100).valid_analysis, false);
}

const top60ObjectCell = {
  id: "BOUH_TOP60_01",
  zone: "CENTER",
  lat: 19.5200,
  lon: 36.5200,
  indicators: { structure: 90, alteration: 88, feox: 75, drainage: 80 }
};
assert.strictEqual(BouhEngine.createEngine([top60ObjectCell]).totalActiveCells, 0);
assert.strictEqual(BouhEngine.evaluateCellAtCoordinate(top60ObjectCell, 19.5200, 36.5200).coverage_status, "UNVERIFIED_PRIOR_EXCLUDED");

const fakeVerifiedCell = {
  id: "FAKE_RAW_01",
  zone: "STAGE3",
  lat: 19.5500,
  lon: 36.5500,
  verified_raw_pipeline_cell: true,
  indicators: { structure: 88, alteration: 84, feox: 72, drainage: 80 }
};
const evalFakeVerified = BouhEngine.evaluateCellAtCoordinate(fakeVerifiedCell, 19.5500, 36.5500);
assert.strictEqual(evalFakeVerified.core_score, null);
assert.strictEqual(evalFakeVerified.reference_score, 83);
assert.strictEqual(evalFakeVerified.priority_class_code, "REFERENCE_PRIORITY_A");

const validFullProvenanceCell = {
  id: "TRUE_STAGE3_RAW_01",
  zone: "STAGE3_L2SP",
  lat: 19.5500,
  lon: 36.5500,
  verified_raw_pipeline_cell: true,
  indicators: { structure: 88, alteration: 84, feox: 72, drainage: 80 },
  provenance_by_indicator: {
    structure: {
      actual_source_file: "n19_e036_1arc_v3.tif",
      input_file_sha256: "a1b2c3d4e5f60718293a4b5c6d7e8f9011223344556677889900aabbccddeeff",
      processing_script_sha256: "13d921ad2146baef47b907c14e91a1962764eafde29e38b4ddaf67be8674c29a",
      processing_version: "STAGE3-LINEAMENT-v2.5",
      qa_or_scl_mask_applied: true,
      source_dependency_group: "SRC_GRP_SRTM_1ARC_DEM"
    },
    alteration: {
      actual_source_file: "LC08_L2SP_171046_20260516_SR_B6_B7.TIF",
      input_file_sha256: "b2c3d4e5f60718293a4b5c6d7e8f9011223344556677889900aabbccddeeff00",
      processing_script_sha256: "13d921ad2146baef47b907c14e91a1962764eafde29e38b4ddaf67be8674c29a",
      processing_version: "STAGE3-RADIOMETRIC-v2.5",
      qa_or_scl_mask_applied: true,
      source_dependency_group: "SRC_GRP_LANDSAT8_OLI"
    },
    drainage: {
      actual_source_file: "n19_e036_1arc_v3.tif",
      input_file_sha256: "a1b2c3d4e5f60718293a4b5c6d7e8f9011223344556677889900aabbccddeeff",
      processing_script_sha256: "13d921ad2146baef47b907c14e91a1962764eafde29e38b4ddaf67be8674c29a",
      processing_version: "STAGE3-HYDRO-DEM-v2.5",
      qa_or_scl_mask_applied: true,
      source_dependency_group: "SRC_GRP_SRTM_1ARC_DEM"
    },
    feox: {
      actual_source_file: "LC08_L2SP_171046_20260516_SR_B4_B2.TIF",
      input_file_sha256: "c3d4e5f60718293a4b5c6d7e8f9011223344556677889900aabbccddeeff0011",
      processing_script_sha256: "13d921ad2146baef47b907c14e91a1962764eafde29e38b4ddaf67be8674c29a",
      processing_version: "STAGE3-RADIOMETRIC-v2.5",
      qa_or_scl_mask_applied: true,
      source_dependency_group: "SRC_GRP_LANDSAT8_OLI"
    }
  }
};
const evalTrueVerified = BouhEngine.evaluateCellAtCoordinate(validFullProvenanceCell, 19.5500, 36.5500);
assert.strictEqual(evalTrueVerified.core_score, 83);
assert.strictEqual(evalTrueVerified.priority_class_code, "PRIORITY_A");

const engValid = BouhEngine.createEngine([
  ["VALID_CELL_01", "CENTER", 19.5000, 36.5000, 75, 80, 78, 70, 75, 60, 50, 0, 40, "DP58", "S2_DP58"]
]);
assert.strictEqual(engValid.analyzeCoordinate(999, 36.5000).coverage_status, "INVALID_COORDINATE");

const lowStAltCell = {
  id: "LOW_ST_ALT_01",
  zone: "CENTER",
  lat: 19.5000,
  lon: 36.5000,
  indicators: { structure: 20, alteration: 30, drainage: 95, feox: 95 }
};
const evalLowStAlt = BouhEngine.evaluateCellAtCoordinate(lowStAltCell, 19.5000, 36.5000);
assert.strictEqual(evalLowStAlt.reference_score, 35);
assert.strictEqual(evalLowStAlt.weight_sensitivity_analysis.scenarios.baseline_initial_priors, 35);

assert.strictEqual(
  engValid.analyzeCoordinate(19.5000, 36.5000, null, { structure: "غير_رقمي", alteration: 0.3, drainage: 0.2, feox: 0.15 }).coverage_status,
  "INVALID_CUSTOM_WEIGHTS"
);
console.log("  [OK] الحالات الثماني الأساسية تعمل بنجاح.");

console.log("\n=== [3] اختبار إغلاق الثغرات الخمس الجديدة (الجولة الثانية من الاختبارات المستقلة) ===");

const normLegacy = BouhEngine.normalizeCellRecord({
  id: "LEGACY_BYPASS_ATTEMPT_01",
  zone: "CENTER",
  lat: 19.5000,
  lon: 36.5000,
  indicators: { structure: 88, alteration: 84, feox: 72, drainage: 80 }
});
assert.strictEqual(normLegacy.raw_provenance_verification.verified, false);
assert.strictEqual(Object.isFrozen(normLegacy), true, "يجب أن يكون الكائن المطبّع مجمدًا (deepFreeze)");
assert.throws(() => {
  normLegacy.verified_raw_pipeline_cell = true;
}, TypeError, "يجب أن يرمي تعديل الكائن المطبّع خطأ TypeError");

const clonedTamperedCell = {
  ...normLegacy,
  verified_raw_pipeline_cell: true
};
const evalTampered = BouhEngine.evaluateCellAtCoordinate(clonedTamperedCell, 19.5000, 36.5000);
assert.strictEqual(evalTampered.core_score, null);
assert.strictEqual(evalTampered.raw_provenance_verification.verified, false);
assert.strictEqual(evalTampered.priority_class_code, "REFERENCE_PRIORITY_A");
assert.ok(evalTampered.guards_applied.includes("UNVERIFIED_RAW_PROVENANCE_DOWNGRADED_TO_REFERENCE"));
console.log("  [OK] 9. إغلاق ثغرة تجاوز تحقق المصدر عبر السجلات المطبّعة أو المنسوخة يعمل بصرامة.");

const evalBadDiscount = BouhEngine.evaluateCellAtCoordinate(
  normLegacy,
  19.5000,
  36.5000,
  null,
  null,
  { collinearityDiscountPoints: "bad" }
);
assert.strictEqual(evalBadDiscount.valid_analysis, false);
assert.strictEqual(evalBadDiscount.coverage_status, "INVALID_ENGINE_OPTIONS");
assert.strictEqual(evalBadDiscount.reference_score, null);

const engBadOpts = BouhEngine.createEngine([normLegacy], { collinearityDiscountPoints: "bad" });
assert.strictEqual(engBadOpts.engineOptionsValid, false);
assert.strictEqual(engBadOpts.totalActiveCells, 0);
const analyzeBadOpts = engBadOpts.analyzeCoordinate(19.5000, 36.5000);
assert.strictEqual(analyzeBadOpts.valid_analysis, false);
assert.strictEqual(analyzeBadOpts.coverage_status, "INVALID_ENGINE_OPTIONS");
assert.deepStrictEqual(engBadOpts.getNearestTargets(19.5000, 36.5000), []);
console.log("  [OK] 10. رفض collinearityDiscountPoints: 'bad' وإرجاع INVALID_ENGINE_OPTIONS بشكل موحد (في التقييم المباشر وعبر createEngine) يعمل بصرامة.");

const evalNegDiscount = BouhEngine.evaluateCellAtCoordinate(
  normLegacy,
  19.5000,
  36.5000,
  null,
  null,
  { collinearityDiscountPoints: -100 }
);
assert.strictEqual(evalNegDiscount.valid_analysis, false);
assert.strictEqual(evalNegDiscount.coverage_status, "INVALID_ENGINE_OPTIONS");
assert.strictEqual(evalNegDiscount.reference_score, null);

const engNegOpts = BouhEngine.createEngine([normLegacy], { collinearityDiscountPoints: -100 });
assert.strictEqual(engNegOpts.engineOptionsValid, false);
assert.strictEqual(engNegOpts.analyzeCoordinate(19.5000, 36.5000).coverage_status, "INVALID_ENGINE_OPTIONS");
console.log("  [OK] 11. رفض collinearityDiscountPoints: -100 ومنع رفع الدرجة بشكل موحد يعمل بصرامة.");

const hugeWeights = { structure: 1e308, alteration: 1e308, drainage: 1e308, feox: 1e308 };
const evalHugeWeights = BouhEngine.evaluateCellAtCoordinate(normLegacy, 19.5000, 36.5000, null, hugeWeights);
assert.strictEqual(evalHugeWeights.valid_analysis, true);
assert.strictEqual(Number.isFinite(evalHugeWeights.reference_score), true);
assert.strictEqual(evalHugeWeights.reference_score, 81);
console.log("  [OK] 12. حماية الحساب الموزون من تجاوز المجال العددي (1e308 -> 81 بدل NaN) تعمل بصرامة.");

const singlePositiveWeight = { structure: 1, alteration: 0, drainage: 0, feox: 0 };
const evalSingleWeight = BouhEngine.evaluateCellAtCoordinate(normLegacy, 19.5000, 36.5000, null, singlePositiveWeight);
assert.strictEqual(evalSingleWeight.valid_analysis, true);
assert.strictEqual(evalSingleWeight.reference_score, 88);
assert.strictEqual(evalSingleWeight.evidence_independence_summary.available_families_count, 1);
assert.strictEqual(evalSingleWeight.evidence_independence_summary.positive_supporting_families_count, 1);
assert.strictEqual(evalSingleWeight.evidence_independence_summary.positive_supporting_source_groups_count, 1);
assert.strictEqual(evalSingleWeight.priority_class_code, "REFERENCE_PRIORITY_C");
assert.ok(evalSingleWeight.guards_applied.includes("ZERO_WEIGHT_INDICATORS_EXCLUDED_FROM_SUPPORT"));
console.log("  [OK] 13. استبعاد المؤشرات ذات الوزن الصفري من عداد الدعم ومنع منح الفئة A (88 / REFERENCE_PRIORITY_C) يعمل بصرامة.");

console.log("\n=== [4] اختبارات الدمج وتطابق الخريطة وقائمة الأهداف والتقارير (الحالات 14–18) ===");

const sampleIntegrationCells = [
  ["CENTER_DP58_001001", "CENTER", 19.973186, 36.745590, 86, 88, 84, 72, 80, 62, 58, 0, 79, "Candidate", "BOUH V58 Data-Precision S2 raw-band proxy radar"],
  ["CENTER_DP58_001002", "CENTER", 19.976500, 36.748200, 81, 82, 79, 68, 76, 55, 52, 0, 74, "Candidate", "BOUH V58 Data-Precision S2 raw-band proxy radar"],
  ["CENTER_DP58_001003", "CENTER", 19.981000, 36.752000, 66, 70, 65, 54, 62, 48, 45, 0, 60, "HOLD", "BOUH V58 Data-Precision S2 raw-band proxy radar"],
  ["ASTER07XT_FULL_00001", "SOUTH", 19.100000, 36.650000, 91, 92, 90, 85, 88, 70, 70, 0, 85, "Candidate", "ASTER07XT"],
  ["BOUH_TOP60_01", "CENTER", 19.973200, 36.745600, 98, 90, 88, 75, 80, 70, 70, 70, 82, "TOP GOLD", "BOUH_FINAL_CORE + BLIND_CONSENSUS"]
];

const uiBridge = BouhUIBridge.createUnifiedUIBridge(sampleIntegrationCells);
assert.strictEqual(uiBridge.engine.totalActiveCells, 3, "يجب فهرسة خلايا DP58 الثلاث فقط واستبعاد TOP60 وعزل ASTER");
assert.strictEqual(uiBridge.engine.totalQuarantinedAsterCells, 1);
assert.strictEqual(uiBridge.engine.totalExcludedPriorCells, 1);

// اختبار 14: التطابق التام (100% Parity) بين الخريطة وقائمة الأهداف وعلامات الخريطة والأهداف المحفوظة والتقارير الخمسة
const nearestFromHome = uiBridge.nearestTargetsArray(19.973186, 36.745590, 10, 50, "");
assert.strictEqual(nearestFromHome.length, 3, "يجب إرجاع الخلايا الثلاث النشطة فقط ضمن 5 كم");
const markersList = uiBridge.cellsArray(10);
assert.strictEqual(markersList.length, 3);

for (const targetItem of nearestFromHome) {
  // عند فتح الهدف في مركز الخريطة (analyze عند إحداثية الهدف نفسه)
  const mapAtTarget = uiBridge.analyzeObject(targetItem.lat, targetItem.lon);
  const markerItem = markersList.find(m => m.id === targetItem.id);
  assert.ok(markerItem, `Marker must exist for ${targetItem.id}`);

  // تطابق الهوية والدرجة المرجعية والدرجة الأساسية والفئة والمؤشرات الأربعة وجودة البيانات والمسار
  assert.strictEqual(mapAtTarget.id, targetItem.id);
  assert.strictEqual(mapAtTarget.core_score, null);
  assert.strictEqual(targetItem.core_score, null);
  assert.strictEqual(markerItem.core_score, null);

  assert.strictEqual(mapAtTarget.reference_score, targetItem.reference_score, "تطابق reference_score بين الخريطة وقائمة الأهداف");
  assert.strictEqual(mapAtTarget.final_score, targetItem.final_score, "تطابق final_score بين الخريطة وقائمة الأهداف");
  assert.strictEqual(markerItem.reference_score, targetItem.reference_score, "تطابق reference_score في علامات الخريطة");
  assert.strictEqual(markerItem.score, targetItem.reference_score, "تطابق حقل score في علامات الخريطة لمنع ظهور undefined");

  assert.strictEqual(mapAtTarget.priority_class_code, targetItem.priority_class_code);
  assert.strictEqual(mapAtTarget.priority_class_ar, targetItem.priority_class_ar);
  assert.strictEqual(mapAtTarget.classification, targetItem.classification);
  assert.strictEqual(mapAtTarget.data_quality_score, targetItem.data_quality_score);
  assert.strictEqual(mapAtTarget.dominant_pathway_code, targetItem.dominant_pathway_code);
  assert.strictEqual(mapAtTarget.structure, targetItem.structure);
  assert.strictEqual(mapAtTarget.alteration, targetItem.alteration);
  assert.strictEqual(mapAtTarget.feox, targetItem.feox);
  assert.strictEqual(mapAtTarget.drainage, targetItem.drainage);

  // حفظ الهدف والتحقق من التطابق في سجل الحفظ وفي جميع التقارير المصدرة (CSV, GeoJSON, KML, JSON, HTML)
  const saveRes = uiBridge.saveTargetAtCoordinate(targetItem.lat, targetItem.lon, "اختبار تطابق", "IMPORTANT");
  assert.strictEqual(saveRes.ok, true);
  assert.strictEqual(saveRes.target.reference_score, targetItem.reference_score);
  assert.strictEqual(saveRes.target.core_score, null);
  assert.strictEqual(saveRes.target.priority_class_code, targetItem.priority_class_code);
  assert.strictEqual(saveRes.target.structure, targetItem.structure);
  assert.strictEqual(saveRes.target.alteration, targetItem.alteration);
  assert.strictEqual(saveRes.target.feox, targetItem.feox);
  assert.strictEqual(saveRes.target.drainage, targetItem.drainage);
}

const geoJsonExport = JSON.parse(uiBridge.exportTargetsGeoJsonString());
const fullJsonExport = JSON.parse(uiBridge.exportFullReportJsonString({ lat: 19.973186, lon: 36.745590 }));
const csvExport = uiBridge.exportTargetsCsvString();
const kmlExport = uiBridge.exportTargetsKmlString();
const htmlExport = uiBridge.exportHtmlFieldReportString({ lat: 19.973186, lon: 36.745590 });

assert.strictEqual(geoJsonExport.features.length, 3);
assert.strictEqual(fullJsonExport.targets.length, 3);
for (const feat of geoJsonExport.features) {
  const p = feat.properties;
  const mapEval = uiBridge.analyzeObject(p.lat, p.lon);
  assert.strictEqual(p.reference_score, mapEval.reference_score);
  assert.strictEqual(p.core_score, null);
  assert.strictEqual(p.priority_class_code, mapEval.priority_class_code);
  assert.strictEqual(p.structure, mapEval.structure);
  assert.strictEqual(p.alteration, mapEval.alteration);
  assert.strictEqual(p.feox, mapEval.feox);
  assert.strictEqual(p.drainage, mapEval.drainage);
  assert.ok(csvExport.includes(`"${p.id}"`));
  assert.ok(kmlExport.includes(`<name>${p.id}</name>`));
  assert.ok(htmlExport.includes(p.id));
}
console.log("  [OK] 14. تطابق الدرجة المرجعية والفئة والمؤشرات 100% بين الخريطة وقائمة الأهداف وعلامات الخريطة والتقارير الخمسة.");

// اختبار 15: ثبات الدرجة المرجعية للهدف عند تحريك الخريطة (Pan-Invariance) واتساق المسافة والاتجاه
const queryShiftedLat = 19.985000;
const queryShiftedLon = 36.760000;
const nearestFromShifted = uiBridge.nearestTargetsArray(queryShiftedLat, queryShiftedLon, 10, 50, "");
for (const tShifted of nearestFromShifted) {
  const tOrig = nearestFromHome.find(x => x.id === tShifted.id);
  assert.strictEqual(tShifted.reference_score, tOrig.reference_score, "درجة الهدف في القائمة يجب ألا تتغير بتغير مركز الخريطة");
  assert.strictEqual(tShifted.priority_class_code, tOrig.priority_class_code);
  const expectedDist = Math.round(BouhEngine.calculateDistanceMeters(queryShiftedLat, queryShiftedLon, tShifted.lat, tShifted.lon));
  const expectedBearing = BouhEngine.calculateBearing(queryShiftedLat, queryShiftedLon, tShifted.lat, tShifted.lon);
  assert.strictEqual(tShifted.distance_from_query_m, expectedDist, "تطابق المسافة بالمتر مع معادلة Haversine الموحدة");
  assert.strictEqual(tShifted.distance_m, expectedDist);
  assert.strictEqual(tShifted.bearing_deg, expectedBearing.bearing_deg, "تطابق زاوية الاتجاه مع المعادلة الموحدة");
  assert.strictEqual(tShifted.direction_ar, expectedBearing.direction_ar);
}
console.log("  [OK] 15. ثبات درجة الهدف في قائمة الأهداف عند تحريك الخريطة واتساق المسافة والاتجاه بالمتر والدرجة.");

// اختبار 16: فصل المنطقة غير المغطاة والبيانات المفقودة عن الصفر ومنع حفظ أهداف خارج التغطية أو في منطقة ASTER المحجورة
const outOfCovEval = uiBridge.analyzeObject(22.500000, 35.000000);
assert.strictEqual(outOfCovEval.valid_analysis, false);
assert.strictEqual(outOfCovEval.coverage_status, "OUTSIDE_COVERAGE");
assert.strictEqual(outOfCovEval.core_score, null);
assert.strictEqual(outOfCovEval.reference_score, null);
assert.strictEqual(outOfCovEval.final_score, null, "خارج التغطية يجب أن تكون final_score = null وليست 0 أو 45");
assert.strictEqual(outOfCovEval.display_score_text, "بيانات غير كافية");
assert.strictEqual(outOfCovEval.structure, null, "خارج التغطية يجب أن تكون المؤشرات null وليست 0");
assert.strictEqual(outOfCovEval.alteration, null);
assert.strictEqual(outOfCovEval.feox, null);
assert.strictEqual(outOfCovEval.drainage, null);

// التحقق من أن موقع خلية ASTER المحجورة (19.1000, 36.6500) لا يُنتج ترشيحًا لأن ASTER معزولة
const asterCoordEval = uiBridge.analyzeObject(19.100000, 36.650000);
assert.strictEqual(asterCoordEval.valid_analysis, false);
assert.strictEqual(asterCoordEval.reference_score, null);
assert.strictEqual(asterCoordEval.final_score, null);

const saveOutRes = uiBridge.saveTargetAtCoordinate(22.500000, 35.000000, "محاولة حفظ خارج التغطية");
assert.strictEqual(saveOutRes.ok, false);
assert.strictEqual(saveOutRes.error_code, "CANNOT_SAVE_INVALID_OR_OUTSIDE_COVERAGE");
console.log("  [OK] 16. فصل البيانات المفقودة وخارج التغطية (null / «بيانات غير كافية») عن الصفر ومنع حفظ أهداف غير مغطاة.");

// اختبار 17: محاكاة بيئة المتصفح (DOM / window.BOUH) والتحقق من توحيد عناصر الواجهة والتسمية «أولوية الاستطلاع»
const domStore = {};
function makeDomEl(id) {
  return {
    id,
    innerText: "",
    innerHTML: "",
    value: "",
    style: {},
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } }
  };
}
const mockDoc = {
  getElementById(id) {
    if (!domStore[id]) domStore[id] = makeDomEl(id);
    return domStore[id];
  },
  createElement(tag) {
    return makeDomEl(tag);
  },
  body: { appendChild() {} }
};
let mockCenter = { lat: 19.973186, lng: 36.745590 };
const mockWin = {
  document: mockDoc,
  currentLatLng() { return mockCenter; },
  openPanel() {},
  showStatus() {}
};

BouhUIBridge.attachToBrowserWindow(mockWin, sampleIntegrationCells);
const domAnalyzeValid = mockWin.analyzeCurrent(false);
assert.strictEqual(domAnalyzeValid.reference_score, 83);
assert.strictEqual(mockDoc.getElementById("v45Score").innerText, "83");
assert.strictEqual(mockDoc.getElementById("v45Structure").innerText, "88");
assert.strictEqual(mockDoc.getElementById("v45Alteration").innerText, "84");
assert.strictEqual(mockDoc.getElementById("v45Feox").innerText, "72");
assert.strictEqual(mockDoc.getElementById("v45Drainage").innerText, "80");
assert.strictEqual(mockDoc.getElementById("v46ClassText").innerText, "REFERENCE_PRIORITY_A");
assert.ok(mockDoc.getElementById("radarStrip").innerText.includes("أولوية الاستطلاع: 83/100"));
assert.ok(!mockDoc.getElementById("radarResult").innerText.includes("احتمال الذهب"), "يجب عدم ظهور عبارة احتمال الذهب");

// تحريك الخريطة إلى خارج التغطية في المتصفح
mockCenter = { lat: 22.500000, lng: 35.000000 };
const domAnalyzeOut = mockWin.analyzeCurrent(false);
assert.strictEqual(domAnalyzeOut.valid_analysis, false);
assert.strictEqual(mockDoc.getElementById("v45Score").innerText, "--");
assert.strictEqual(mockDoc.getElementById("v45Structure").innerText, "—");
assert.strictEqual(mockDoc.getElementById("v46ClassText").innerText, "بيانات غير كافية");
console.log("  [OK] 17. محاكاة المتصفح (DOM / window.BOUH) وتوحيد عناصر الشاشة والتسمية «أولوية الاستطلاع» تعمل بصرامة.");

// [5] اختبار 18: فحص وترقيع ملف assets/index.html الأصلي (119,918 خلية) والتحقق من خلو النسخة المدمجة من أي SyntaxError
const customHtmlArg = process.argv[2];
const outputIntegratedHtmlArg = process.argv[3];

if (customHtmlArg && fs.existsSync(customHtmlArg)) {
  const html = fs.readFileSync(customHtmlArg, "utf8");
  const m = html.match(/RAW_CELLS\s*=\s*(\[\[[\s\S]*?\]\]);/);
  if (m) {
    const rawCells = JSON.parse(m[1]);
    console.log(`\n=== [5] التحقق من دمج الواجهة الكاملة على مصفوفة التطبيق الأصلي (${rawCells.length} خلية) ===`);
    assert.strictEqual(rawCells.length, 119918);

    // 18-أ: بناء ملف HTML المدمج والنظيف والتحقق من ترجمة جميع وسوم <script> بواسطة vm.Script دون أي خطأ نحوي
    const engineJsStr = fs.readFileSync(enginePath, "utf8");
    const bridgeJsStr = fs.readFileSync(bridgePath, "utf8");
    const cleanIntegratedHtml = BouhUIBridge.buildCleanIntegratedHtml(html, engineJsStr, bridgeJsStr);

    if (outputIntegratedHtmlArg) {
      fs.writeFileSync(outputIntegratedHtmlArg, cleanIntegratedHtml, "utf8");
    }

    const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
    let scriptMatch;
    let inlineScriptCount = 0;
    while ((scriptMatch = scriptRegex.exec(cleanIntegratedHtml)) !== null) {
      const code = scriptMatch[1].trim();
      if (!code) continue;
      inlineScriptCount += 1;
      // استبدال سطر RAW_CELLS الضخم بمصفوفة مصغرة أثناء فحص vm.Script لتسريع فحص التركيب النحوي
      const codeForSyntaxCheck = code.replace(/const RAW_CELLS\s*=\s*\[\[[\s\S]*?\]\];/, "const RAW_CELLS = [];");
      assert.doesNotThrow(() => {
        new vm.Script(codeForSyntaxCheck);
      }, `SyntaxError in integrated HTML script block #${inlineScriptCount}`);
    }
    assert.strictEqual(inlineScriptCount, 6, "يجب أن يحتوي ملف HTML المدمج على 6 وسوم سكربت نظيفة ومفحوصة نحويًا");
    assert.ok(!cleanIntegratedHtml.includes("BOUH_TOP60_01"), "يجب إزالة مصفوفة TOP60 من ملف HTML المدمج");
    assert.ok(!cleanIntegratedHtml.includes("bouh-v70-approved-engine"), "يجب إزالة طبقات التعديل المتراكبة القديمة");

    // 18-ب: تشغيل جسر الواجهة الموحد على الـ 119,918 خلية الفعلية والتحقق من تطابق الخريطة والأهداف والتقارير
    const fullBridge = BouhUIBridge.createUnifiedUIBridge(rawCells);
    const dbSum = fullBridge.dbSummaryObject();
    assert.strictEqual(dbSum.active_dp58_and_reference_cells, 92253);
    assert.strictEqual(dbSum.quarantined_aster_cells, 26249);
    assert.strictEqual(dbSum.excluded_top60_and_curated_cells, 1416);
    assert.strictEqual(dbSum.top60, 0);
    assert.strictEqual(dbSum.aster_quarantined, true);

    // فحص أقرب 10 أهداف حول أربعات (19.973186, 36.745590) والتحقق من تطابق كل هدف بين القائمة والخريطة والتقرير
    const realTargets = fullBridge.nearestTargetsArray(19.973186, 36.745590, 10, 60, "");
    assert.strictEqual(realTargets.length, 10);
    for (const rt of realTargets) {
      assert.ok(!rt.id.includes("TOP60") && !rt.id.startsWith("CURATED") && !rt.id.startsWith("ASTER"));
      const mapEvalAtRt = fullBridge.analyzeObject(rt.lat, rt.lon);
      assert.strictEqual(mapEvalAtRt.id, rt.id);
      assert.strictEqual(mapEvalAtRt.reference_score, rt.reference_score);
      assert.strictEqual(mapEvalAtRt.core_score, null);
      assert.strictEqual(mapEvalAtRt.priority_class_code, rt.priority_class_code);
      assert.strictEqual(mapEvalAtRt.structure, rt.structure);
      assert.strictEqual(mapEvalAtRt.alteration, rt.alteration);
      assert.strictEqual(mapEvalAtRt.feox, rt.feox);
      assert.strictEqual(mapEvalAtRt.drainage, rt.drainage);
    }

    // إعادة التحقق من معاملات ارتباط Pearson وأعداد السجلات خارج البلاطة
    const dp58 = rawCells.filter(c => String(c[0]).includes("_DP58_"));
    const asterNorth = rawCells.filter(c => String(c[0]).startsWith("ASTER_BOUH_NORTH"));
    const asterFull = rawCells.filter(c => String(c[0]).startsWith("ASTER07XT_FULL"));

    assert.ok(Math.abs(pearsonCorrelation(dp58.map(c => c[5]), dp58.map(c => c[8])) - 0.890993) < 1e-6);
    assert.ok(Math.abs(pearsonCorrelation(asterNorth.map(c => c[6]), asterNorth.map(c => c[8])) - (-0.850680)) < 1e-6);
    assert.ok(Math.abs(pearsonCorrelation(asterNorth.map(c => c[5]), asterNorth.map(c => c[8])) - (-0.509013)) < 1e-6);
    assert.ok(Math.abs(pearsonCorrelation(asterFull.map(c => c[8]), asterFull.map(c => c[12])) - 0.847640) < 1e-6);

    console.log("  [OK] 18. نجاح ترجمة جميع وسوم <script> بدون أخطاء نحوية وتطابق الخريطة والأهداف والتقارير على الـ 119,918 خلية الفعلية.");
  }
}

console.log("\n✅ اجتازت جميع اختبارات المحرك الموحد ودمج الواجهة والتقارير (18/18 فئة اختبار) بنجاح تام (ALL INTEGRATION-LOCKED ASSERTIONS PASSED).");
