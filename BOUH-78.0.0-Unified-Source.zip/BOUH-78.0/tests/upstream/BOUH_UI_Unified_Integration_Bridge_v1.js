/**
 * BOUH Unified UI & Report Integration Bridge (v1.5.0-STAGE1-2-UI-INTEGRATION-LOCKED)
 * جسر الربط الموحد بين المحرك الجيولوجي المعتمد (v1.5.0) وواجهة الخريطة وقائمة الأهداف والتقارير
 * المالك والمطور: أحمد أبو عزيزه الرشيدي
 *
 * يضمن هذا الجسر البرمجي:
 * 1. محرك حساب واحد فقط (Single Engine Source of Truth):
 *    - إزالة جميع طبقات التعديل المتراكبة القديمة (v49, v50, v63, v70, v763, v71) وإزالة مصفوفة TOP60.
 *    - تشغيل BouhUnifiedEngine (1.5.0-STAGE1-2-AUDIT-LOCKED) بوصفه المصدر الوحيد لتحليل مركز الخريطة،
 *      وقائمة الأهداف القريبة، وعلامات الخريطة، والأهداف المحفوظة، وجميع صيغ التصدير (CSV, KML, GeoJSON, JSON, HTML).
 * 2. التطابق التام عبر جميع الشاشات والتقارير (100% Cross-Screen & Report Parity):
 *    - أي خلية هدف (lat, lon) تظهر في قائمة الأهداف القريبة (nearestTargets) أو علامات الخريطة (cells)
 *      تعطي عند فتحها في مركز الخريطة (analyze) أو عند حفظها وتصديرها في التقارير نفس الدرجة المرجعية
 *      (reference_score)، ونفس حالة الدرجة الأساسية (core_score = null)، ونفس الفئة (priority_class_code)،
 *      ونفس المؤشرات الأربعة (structure, alteration, feox, drainage)، ونفس درجة جودة البيانات والمسار الجيولوجي.
 * 3. ثبات درجة الهدف عند تحريك الخريطة (Pan-Invariant Target Scoring):
 *    - تُقيَّم كل خلية هدف في قائمة الأهداف القريبة عند إحداثيتها المرجعية الخاصة بها (0م)، بينما تُحسب
 *      المسافة (distance_from_query_m) والاتجاه (bearing_deg / direction_ar) من مركز الخريطة الحالي إليها بدقة.
 * 4. الفصل الصارم للمنطقة غير المغطاة والبيانات المفقودة (Strict Out-of-Coverage & Missing Data Separation):
 *    - خارج نطاق التغطية (> 900م عن أقرب خلية مفعلة، بما في ذلك داخل نطاق ASTER المحجور جغرافيًا):
 *      تكون valid_analysis: false، و core_score: null، و reference_score: null، و final_score: null،
 *      والمؤشرات الأربعة null (وليس 0)، وتُعرض العبارة الصريحة «بيانات غير كافية»، ويُمنع حفظ الموقع كهدف.
 * 5. التسمية العلمية الموحدة:
 *    - استبدال عبارة «احتمال الذهب» في جميع الشاشات والتقارير بعبارة «أولوية الاستطلاع (ترتيب مرجعي استرشادي)»
 *      مع إظهار أن core_score = null حتى التحقق من الراسترات الخام في المرحلة الثالثة.
 */

(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    const BouhUnifiedEngine = require("./BOUH_Unified_Engine_v1.js");
    module.exports = factory(BouhUnifiedEngine);
  } else {
    root.BouhUIBridge = factory(root.BouhUnifiedEngine);
  }
})(typeof self !== "undefined" ? self : this, function (BouhUnifiedEngine) {
  "use strict";

  if (!BouhUnifiedEngine || typeof BouhUnifiedEngine.createEngine !== "function") {
    throw new Error("BouhUnifiedEngine (v1.5.0-STAGE1-2-AUDIT-LOCKED) must be loaded before BouhUIBridge.");
  }

  const BRIDGE_VERSION = "1.5.0-STAGE1-2-UI-INTEGRATION-LOCKED";
  const OWNER_NAME_AR = "أحمد أبو عزيزه الرشيدي";
  const OFFICIAL_SCORE_TITLE_AR = "أولوية الاستطلاع";
  const PROVISIONAL_REFERENCE_BADGE_AR = "ترتيب مرجعي استرشادي (Reference Score) — الدرجة الأساسية غير مفعلة (core_score = null)";
  const INSUFFICIENT_DATA_LABEL_AR = "بيانات غير كافية";

  function safeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, function (m) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[m];
    });
  }

  function formatMetricValueForDisplay(val) {
    return val === null || val === undefined || !Number.isFinite(Number(val))
      ? "—"
      : String(Math.round(Number(val)));
  }

  /**
   * تحويل مخرجات المحرك الموحد إلى سجل قياسي موحد تستخدمه الخريطة وقائمة الأهداف والتقارير معًا
   * دون أي إعادة حساب أو تعديل للدرجات أو المؤشرات.
   */
  function formatUnifiedRecordForUI(evalResult, queryLat, queryLon) {
    const qLat = Number(queryLat);
    const qLon = Number(queryLon);

    if (!evalResult || !evalResult.valid_analysis) {
      const covStatus = (evalResult && evalResult.coverage_status) || "OUTSIDE_COVERAGE";
      const covLabel =
        (evalResult && evalResult.coverage_label_ar) ||
        "بيانات غير كافية — المنطقة خارج نطاق التغطية المعتمد";
      const distM =
        evalResult && evalResult.distance_from_query_m !== undefined && evalResult.distance_from_query_m !== null
          ? Math.round(Number(evalResult.distance_from_query_m))
          : null;
      const brgDeg =
        evalResult && evalResult.bearing_deg !== undefined && evalResult.bearing_deg !== null
          ? Math.round(Number(evalResult.bearing_deg))
          : null;
      const dirAr = (evalResult && evalResult.direction_ar) || "غير متاح";
      const refCell =
        (evalResult && evalResult.reference_cell) ||
        (evalResult && evalResult.coordinates && evalResult.coordinates.reference_cell) ||
        null;

      const contraryList =
        evalResult && Array.isArray(evalResult.contrary_evidence_ar) && evalResult.contrary_evidence_ar.length > 0
          ? evalResult.contrary_evidence_ar
          : [covLabel];

      return Object.freeze({
        ok: true,
        valid_analysis: false,
        operational_mode: "PROVISIONAL_LEGACY_REFERENCE_MODE",
        coverage_status: covStatus,
        status: covStatus,
        coverage_label_ar: covLabel,
        score_title_ar: OFFICIAL_SCORE_TITLE_AR,
        score_label_ar: INSUFFICIENT_DATA_LABEL_AR,
        core_score: null,
        reference_score: null,
        reconnaissance_priority_score: null,
        final_score: null,
        score: null,
        display_score_text: INSUFFICIENT_DATA_LABEL_AR,
        display_score_short: "--",
        priority_class_code: (evalResult && evalResult.priority_class_code) || "INSUFFICIENT_DATA",
        priority_class_ar: (evalResult && evalResult.priority_class_ar) || INSUFFICIENT_DATA_LABEL_AR,
        classification: INSUFFICIENT_DATA_LABEL_AR,
        data_quality_score: null,
        confidence_score: null,
        confidence: "INSUFFICIENT_DATA",
        lat: Number.isFinite(qLat) ? qLat : null,
        lon: Number.isFinite(qLon) ? qLon : null,
        nearest_id: refCell && refCell.id ? refCell.id : null,
        id: refCell && refCell.id ? refCell.id : null,
        zone: refCell && refCell.zone ? refCell.zone : null,
        nearest_lat: refCell && Number.isFinite(Number(refCell.lat)) ? Number(refCell.lat) : null,
        nearest_lon: refCell && Number.isFinite(Number(refCell.lon)) ? Number(refCell.lon) : null,
        distance_from_query_m: distM,
        distance_m: distM,
        bearing_deg: brgDeg,
        bearing: brgDeg,
        direction_ar: dirAr,
        direction: dirAr,
        structure: null,
        alteration: null,
        feox: null,
        drainage: null,
        magnetic: null,
        lithology: null,
        historical: null,
        gpz: null,
        dominant_pathway_code: "INSUFFICIENT_DATA",
        dominant_pathway_ar: INSUFFICIENT_DATA_LABEL_AR,
        pathways: {
          placer_alluvial_score: null,
          vein_structural_score: null,
          general_recon_score: null,
          dominant_pathway_code: "INSUFFICIENT_DATA",
          dominant_pathway_ar: INSUFFICIENT_DATA_LABEL_AR
        },
        zero_value_ambiguity_warning: false,
        zero_value_columns: [],
        guards_applied: (evalResult && evalResult.guards_applied) || [],
        supporting_evidence_ar: [],
        contrary_evidence_ar: contraryList,
        required_verification_ar:
          (evalResult && evalResult.required_verification_ar) ||
          "لا يظهر ترشيح قابل للاعتماد خارج التغطية؛ انتقل إلى نطاق مغطى أو أضف بيانات خام.",
        reason: contraryList.join(" | "),
        gpz_strategy:
          (evalResult && evalResult.required_verification_ar) ||
          "لا يظهر ترشيح قابل للاعتماد خارج التغطية.",
        truth:
          "المنطقة غير مغطاة بخلية مفعلة ضمن حد البحث المعلن (900م)؛ تُفصل القيمة المفقودة (null) عن الصفر ولا يُعرض أي ترشيح.",
        engine_version: BouhUnifiedEngine.ENGINE_VERSION,
        bridge_version: BRIDGE_VERSION
      });
    }

    const refCell = evalResult.reference_cell || {};
    const ind = evalResult.computed_remote_indicators || {};
    const proxies = evalResult.recycled_proxies_display_only || {};
    const histObj = evalResult.contextual_historical_prior || {};
    const pathways = evalResult.pathways || {};
    const refScore = evalResult.reference_score;
    const coreScore = evalResult.core_score;
    const effectiveDisplayScore = coreScore !== null ? coreScore : refScore;
    const distM = Math.round(Number(evalResult.distance_from_query_m ?? 0));
    const brgDeg =
      evalResult.bearing_deg !== null && evalResult.bearing_deg !== undefined
        ? Math.round(Number(evalResult.bearing_deg))
        : 0;
    const dirAr = evalResult.direction_ar || "شمال";

    const classDisplay = `${evalResult.priority_class_code} — ${evalResult.priority_class_ar}`;
    const supportText =
      Array.isArray(evalResult.supporting_evidence_ar) && evalResult.supporting_evidence_ar.length > 0
        ? "الأدلة الداعمة: " + evalResult.supporting_evidence_ar.join(" + ")
        : "الأدلة الداعمة: لا توجد مؤشرات تتجاوز عتبة الدعم العالي (65).";
    const contraryText =
      Array.isArray(evalResult.contrary_evidence_ar) && evalResult.contrary_evidence_ar.length > 0
        ? "ملاحظات وحراس التدقيق: " + evalResult.contrary_evidence_ar.join(" | ")
        : "ملاحظات وحراس التدقيق: لا توجد موانع حرجة مرصودة.";

    const reasonText = `${supportText}\n${contraryText}`;

    return Object.freeze({
      ok: true,
      valid_analysis: true,
      operational_mode: evalResult.operational_mode,
      coverage_status: evalResult.coverage_status,
      status: evalResult.coverage_status,
      coverage_label_ar: evalResult.coverage_label_ar,
      score_title_ar: OFFICIAL_SCORE_TITLE_AR,
      score_label_ar: evalResult.score_label_ar,
      core_score: coreScore,
      reference_score: refScore,
      reconnaissance_priority_score: evalResult.reconnaissance_priority_score,
      final_score: effectiveDisplayScore,
      score: effectiveDisplayScore,
      display_score_text: `${effectiveDisplayScore}/100 (${coreScore !== null ? "درجة أساسية معتمدة" : "ترتيب مرجعي استرشادي"})`,
      display_score_short: String(effectiveDisplayScore),
      priority_class_code: evalResult.priority_class_code,
      priority_class_ar: evalResult.priority_class_ar,
      classification: classDisplay,
      data_quality_score: evalResult.data_quality_score,
      confidence_score: evalResult.data_quality_score,
      confidence:
        evalResult.data_quality_score >= 70
          ? "HIGH_REFERENCE_QUALITY"
          : evalResult.data_quality_score >= 60
          ? "MEDIUM_REFERENCE_QUALITY"
          : "LOW_REFERENCE_QUALITY",
      lat: Number.isFinite(qLat) ? qLat : refCell.lat,
      lon: Number.isFinite(qLon) ? qLon : refCell.lon,
      nearest_id: refCell.id,
      id: refCell.id,
      zone: refCell.zone,
      source_model: refCell.source_model,
      nearest_lat: refCell.lat,
      nearest_lon: refCell.lon,
      distance_from_query_m: distM,
      distance_m: distM,
      bearing_deg: brgDeg,
      bearing: brgDeg,
      direction_ar: dirAr,
      direction: dirAr,
      structure: ind.structure,
      alteration: ind.alteration,
      feox: ind.feox,
      drainage: ind.drainage,
      magnetic: proxies.surface_roughness_proxy ?? null,
      lithology: proxies.lithology_contrast_proxy ?? null,
      historical: histObj.klemm_historical_value ?? null,
      gpz: proxies.gpz_terrain_proxy ?? null,
      dominant_pathway_code: pathways.dominant_pathway_code,
      dominant_pathway_ar: pathways.dominant_pathway_ar,
      pathways: pathways,
      evidence_independence_summary: evalResult.evidence_independence_summary,
      weight_sensitivity_analysis: evalResult.weight_sensitivity_analysis,
      zero_value_ambiguity_warning: evalResult.zero_value_ambiguity_warning,
      zero_value_columns: evalResult.zero_value_columns,
      guards_applied: evalResult.guards_applied,
      supporting_evidence_ar: evalResult.supporting_evidence_ar,
      contrary_evidence_ar: evalResult.contrary_evidence_ar,
      required_verification_ar: evalResult.required_verification_ar,
      epistemological_disclaimer_ar: evalResult.epistemological_disclaimer_ar,
      reason: reasonText,
      gpz_strategy: evalResult.required_verification_ar,
      truth: evalResult.epistemological_disclaimer_ar,
      raw_provenance_verification: evalResult.raw_provenance_verification,
      engine_version: evalResult.engine_version,
      bridge_version: BRIDGE_VERSION
    });
  }

  /**
   * إنشاء الجسر الموحد الذي يغذي window.BOUH وواجهة المستخدم والتقارير من نفس نسخة المحرك
   */
  function createUnifiedUIBridge(rawCellsArray, engineOptions = {}) {
    const engine = BouhUnifiedEngine.createEngine(rawCellsArray, engineOptions);

    // حافظة داخلية للأهداف المحفوظة (تُزامن مع localStorage في المتصفح إن وجد)
    let savedTargetsStore = [];

    // حساب وتخزين المؤشرات المرجعية لأقوى الخلايا النشطة لعرض علامات الخريطة (cells)
    // بنفس دالة evaluateCellAtCoordinate تمامًا دون TOP60 ودون ASTER المحجورة
    let cachedTopMarkers = null;

    function computeActiveCellMarkers(limit = 300) {
      if (!engine.engineOptionsValid || !Array.isArray(rawCellsArray)) return [];
      if (!cachedTopMarkers) {
        const evaluatedMarkers = [];
        // فحص الخلايا النشطة (DP58 + المرجعية) وترتيبها حسب الدرجة المرجعية المحسوبة من المحرك الموحد نفسه
        // لا نعتمد إطلاقًا على العمود القديم c[4] (oldFinal)؛
        // إذا كان حجم المصفوفة <= 2000 نقيّم جميع الخلايا النشطة، وإذا كان أكبر نرتب أوليًا بالمتوسط الموزون الفعلي للمؤشرات الأربعة (5..8)
        let pool = rawCellsArray;
        if (rawCellsArray.length > 2000) {
          const preFiltered = [];
          for (let i = 0; i < rawCellsArray.length; i++) {
            const r = rawCellsArray[i];
            if (Array.isArray(r)) {
              const idStr = String(r[0] || "").toUpperCase();
              if (idStr.startsWith("ASTER") || idStr.includes("TOP60") || idStr.startsWith("CURATED")) continue;
              const wAvg = 0.35 * Number(r[5] || 0) + 0.30 * Number(r[6] || 0) + 0.15 * Number(r[7] || 0) + 0.20 * Number(r[8] || 0);
              if (wAvg >= 75) preFiltered.push({ r, wAvg });
            } else if (r && typeof r === "object") {
              preFiltered.push({ r, wAvg: 100 });
            }
          }
          preFiltered.sort(function (a, b) { return b.wAvg - a.wAvg; });
          pool = preFiltered.slice(0, 1500).map(function (x) { return x.r; });
        }
        for (let i = 0; i < pool.length; i++) {
          const norm = BouhUnifiedEngine.normalizeCellRecord(pool[i]);
          if (!norm || !norm.enabled_now || !norm.eligible_when_verified || norm.has_unresolved_aster_bounds_conflict || norm.is_forbidden_category) {
            continue;
          }
          const ev = BouhUnifiedEngine.evaluateCellAtCoordinate(norm, norm.lat, norm.lon, null, null, engineOptions);
          if (ev && ev.valid_analysis && ev.reference_score !== null) {
            evaluatedMarkers.push(formatUnifiedRecordForUI(ev, norm.lat, norm.lon));
          }
        }

        evaluatedMarkers.sort(function (a, b) {
          if (b.reference_score !== a.reference_score) return b.reference_score - a.reference_score;
          return String(a.id).localeCompare(String(b.id));
        });

        cachedTopMarkers = evaluatedMarkers;
      }
      return cachedTopMarkers.slice(0, Math.max(1, Number(limit) || 300));
    }

    function analyzeObject(lat, lon, userGpsObj = null, customWeights = null, callOptions = null) {
      const rawEval = engine.analyzeCoordinate(lat, lon, userGpsObj, customWeights, callOptions);
      return formatUnifiedRecordForUI(rawEval, lat, lon);
    }

    function analyze(lat, lon, userGpsObj = null, customWeights = null, callOptions = null) {
      return JSON.stringify(analyzeObject(lat, lon, userGpsObj, customWeights, callOptions));
    }

    /**
     * استرجاع أقرب الأهداف المفعلة حول (lat, lon)
     * كل هدف يُقيَّم عند إحداثيته المرجعية الخاصة به (c.lat, c.lon) بحيث تطابق درجته وفئته ومؤشراته
     * تمامًا ما يظهر عند فتح الهدف في مركز الخريطة (analyze(c.lat, c.lon))، بينما تعكس distance_m
     * و bearing و direction المسافة والاتجاه الفعليين من نقطة الاستعلام (lat, lon) إلى الهدف.
     */
    function nearestTargetsArray(lat, lon, n = 20, minScore = 50, filter = "", options = {}) {
      const limitCount = Math.max(1, Number(n) || 20);
      const minScoreNum = Number.isFinite(Number(minScore)) ? Number(minScore) : 50;
      const maxRadiusM = Number(options.maxRadiusM || 5000);
      const customWeights = options.customWeights || null;
      const userGpsObj = options.userGps || null;
      const filterStr = String(filter || "").trim().toUpperCase();

      const rawTargets = engine.getNearestTargets(lat, lon, {
        maxRadiusM: maxRadiusM,
        minScore: minScoreNum,
        limit: Math.max(limitCount * 4, 200),
        customWeights: customWeights,
        userGps: userGpsObj,
        engineOptions: options.engineOptions
      });

      const formatted = [];
      for (let i = 0; i < rawTargets.length; i++) {
        const tEval = rawTargets[i];
        const cellLat = tEval.reference_cell.lat;
        const cellLon = tEval.reference_cell.lon;
        const uiRec = formatUnifiedRecordForUI(tEval, cellLat, cellLon);

        // نحتفظ بالمسافة والاتجاه المحسوبين من نقطة الاستعلام (lat, lon) إلى مركز خلية الهدف (cellLat, cellLon)
        const targetRecord = Object.freeze({
          ...uiRec,
          lat: cellLat,
          lon: cellLon,
          query_lat: Number(lat),
          query_lon: Number(lon),
          distance_from_query_m: tEval.distance_from_query_m,
          distance_m: tEval.distance_from_query_m,
          bearing_deg: tEval.bearing_deg,
          bearing: tEval.bearing_deg,
          direction_ar: tEval.direction_ar,
          direction: tEval.direction_ar,
          status: "ACTIVE_REFERENCE_CELL"
        });

        if (filterStr) {
          const searchable = [
            targetRecord.id,
            targetRecord.zone,
            targetRecord.priority_class_code,
            targetRecord.priority_class_ar,
            targetRecord.classification,
            targetRecord.dominant_pathway_code,
            targetRecord.dominant_pathway_ar
          ]
            .join(" ")
            .toUpperCase();
          if (!searchable.includes(filterStr)) continue;
        }

        formatted.push(targetRecord);
        if (formatted.length >= limitCount) break;
      }

      return formatted;
    }

    function nearestTargets(lat, lon, n = 20, minScore = 50, filter = "", options = {}) {
      return JSON.stringify(nearestTargetsArray(lat, lon, n, minScore, filter, options));
    }

    function cellsArray(limit = 300) {
      return computeActiveCellMarkers(limit);
    }

    function cells(limit = 300) {
      return JSON.stringify(cellsArray(limit));
    }

    function dbSummaryObject() {
      return Object.freeze({
        ok: true,
        engine_version: BouhUnifiedEngine.ENGINE_VERSION,
        bridge_version: BRIDGE_VERSION,
        operational_mode: "PROVISIONAL_LEGACY_REFERENCE_MODE",
        score_terminology_ar: OFFICIAL_SCORE_TITLE_AR,
        core_score_status: null,
        core_score_note_ar: "معطل (null) لجميع الخلايا الحالية حتى التحقق من الراسترات الخام وبصماتها وأقنعتها في المرحلة الثالثة",
        cells: engine.totalActiveCells,
        cells_count: engine.totalActiveCells,
        active_dp58_and_reference_cells: engine.totalActiveCells,
        quarantined_aster_cells: engine.totalQuarantinedAsterCells,
        excluded_top60_and_curated_cells: engine.totalExcludedPriorCells,
        disabled_or_rejected_cells: engine.totalDisabledOrRejectedCells,
        top60: 0,
        aster_quarantined: true,
        zones: "CENTER / NORTH / SOUTH (ASTER QUARANTINED)"
      });
    }

    function dbSummary() {
      return JSON.stringify(dbSummaryObject());
    }

    function fieldStatusObject() {
      return Object.freeze({
        ok: true,
        mode: "STAGE1_2_UNIFIED_REFERENCE_MODE",
        engine_version: BouhUnifiedEngine.ENGINE_VERSION,
        bridge_version: BRIDGE_VERSION,
        databaseReady: engine.totalActiveCells > 0,
        cells: engine.totalActiveCells,
        quarantined_aster_cells: engine.totalQuarantinedAsterCells,
        excluded_prior_cells: engine.totalExcludedPriorCells,
        top60: 0,
        core_score_enabled: false,
        aster_quarantined: true
      });
    }

    function fieldStatus() {
      return JSON.stringify(fieldStatusObject());
    }

    function coverageZones() {
      return JSON.stringify([
        {
          zone: "NORTH",
          count: 35664,
          minLat: 20.30,
          maxLat: 21.62,
          minLon: 35.74,
          maxLon: 37.85,
          status: "ACTIVE_REFERENCE_GRID"
        },
        {
          zone: "CENTER",
          count: 42336,
          minLat: 18.70,
          maxLat: 20.40,
          minLon: 35.74,
          maxLon: 37.85,
          status: "ACTIVE_REFERENCE_GRID"
        },
        {
          zone: "SOUTH",
          count: 14250,
          minLat: 17.58,
          maxLat: 18.85,
          minLon: 35.74,
          maxLon: 37.85,
          status: "ACTIVE_REFERENCE_GRID"
        }
      ]);
    }

    /**
     * حفظ هدف من إحداثية استعلام:
     * - يرفض الحفظ إذا كانت المنطقة خارج التغطية أو البيانات غير كافية (valid_analysis === false).
     * - يحفظ الهدف مرتبطًا بمركز الخلية المرجعية وإحداثية الاستعلام مع نفس نتائج analyzeObject تمامًا.
     */
    function saveTargetAtCoordinate(queryLat, queryLon, note = "", status = "NEW") {
      const analysis = analyzeObject(queryLat, queryLon);
      if (!analysis.valid_analysis || analysis.reference_score === null) {
        return {
          ok: false,
          error_code: "CANNOT_SAVE_INVALID_OR_OUTSIDE_COVERAGE",
          message_ar: "لا يمكن حفظ هدف في منطقة خارج التغطية أو ذات بيانات غير كافية.",
          analysis: analysis
        };
      }

      const targetObj = Object.freeze({
        uid: "BOUH-TGT-" + Date.now() + "-" + Math.floor(Math.random() * 10000),
        created_at: new Date().toISOString(),
        status: status || "NEW",
        visited: status === "VISITED",
        note: String(note || "").trim(),
        // نحفظ إحداثية الخلية المرجعية كإحداثية للهدف لضمان تطابق الخريطة والقائمة والتقارير، مع حفظ إحداثية الاستعلام أيضًا
        lat: analysis.nearest_lat,
        lon: analysis.nearest_lon,
        query_lat: analysis.lat,
        query_lon: analysis.lon,
        nearest_id: analysis.nearest_id,
        id: analysis.id,
        zone: analysis.zone,
        core_score: analysis.core_score,
        reference_score: analysis.reference_score,
        reconnaissance_priority_score: analysis.reconnaissance_priority_score,
        final_score: analysis.final_score,
        score: analysis.score,
        priority_class_code: analysis.priority_class_code,
        priority_class_ar: analysis.priority_class_ar,
        classification: analysis.classification,
        data_quality_score: analysis.data_quality_score,
        dominant_pathway_code: analysis.dominant_pathway_code,
        dominant_pathway_ar: analysis.dominant_pathway_ar,
        distance_from_query_m: analysis.distance_from_query_m,
        distance_m: analysis.distance_m,
        bearing_deg: analysis.bearing_deg,
        bearing: analysis.bearing,
        direction_ar: analysis.direction_ar,
        direction: analysis.direction,
        structure: analysis.structure,
        alteration: analysis.alteration,
        feox: analysis.feox,
        drainage: analysis.drainage,
        analysis: analysis
      });

      savedTargetsStore.unshift(targetObj);
      return {
        ok: true,
        target: targetObj,
        analysis: analysis
      };
    }

    function getSavedTargetsList() {
      return savedTargetsStore.slice();
    }

    function setSavedTargetsList(list) {
      savedTargetsStore = Array.isArray(list) ? list.slice() : [];
    }

    function buildTargetRow(t) {
      const a = t.analysis || t;
      return Object.freeze({
        uid: t.uid || a.id || "",
        created_at: t.created_at || "",
        status: t.status || "NEW",
        visited: Boolean(t.visited),
        id: a.id || a.nearest_id || "",
        nearest_id: a.nearest_id || a.id || "",
        zone: a.zone || "",
        lat: Number(t.lat ?? a.nearest_lat ?? a.lat),
        lon: Number(t.lon ?? a.nearest_lon ?? a.lon),
        query_lat: Number(t.query_lat ?? a.lat),
        query_lon: Number(t.query_lon ?? a.lon),
        operational_mode: a.operational_mode || "PROVISIONAL_LEGACY_REFERENCE_MODE",
        core_score: a.core_score ?? null,
        reference_score: a.reference_score ?? null,
        reconnaissance_priority_score: a.reconnaissance_priority_score ?? null,
        final_score: a.final_score ?? null,
        priority_class_code: a.priority_class_code || "INSUFFICIENT_DATA",
        priority_class_ar: a.priority_class_ar || INSUFFICIENT_DATA_LABEL_AR,
        classification: a.classification || INSUFFICIENT_DATA_LABEL_AR,
        data_quality_score: a.data_quality_score ?? null,
        dominant_pathway_code: a.dominant_pathway_code || "INSUFFICIENT_DATA",
        dominant_pathway_ar: a.dominant_pathway_ar || INSUFFICIENT_DATA_LABEL_AR,
        structure: a.structure ?? null,
        alteration: a.alteration ?? null,
        feox: a.feox ?? null,
        drainage: a.drainage ?? null,
        distance_from_query_m: a.distance_from_query_m ?? a.distance_m ?? null,
        distance_m: a.distance_m ?? a.distance_from_query_m ?? null,
        bearing_deg: a.bearing_deg ?? a.bearing ?? null,
        bearing: a.bearing ?? a.bearing_deg ?? null,
        direction_ar: a.direction_ar ?? a.direction ?? "",
        direction: a.direction ?? a.direction_ar ?? "",
        note: t.note || "",
        reason: a.reason || "",
        engine_version: a.engine_version || BouhUnifiedEngine.ENGINE_VERSION
      });
    }

    function rowsTargets(customTargetsList = null) {
      const list = Array.isArray(customTargetsList) ? customTargetsList : savedTargetsStore;
      return list.map(buildTargetRow);
    }

    function exportTargetsCsvString(customTargetsList = null) {
      const rows = rowsTargets(customTargetsList);
      const headers = [
        "uid",
        "id",
        "zone",
        "lat",
        "lon",
        "core_score",
        "reference_score",
        "reconnaissance_priority_score",
        "final_score",
        "priority_class_code",
        "priority_class_ar",
        "classification",
        "data_quality_score",
        "dominant_pathway_code",
        "structure",
        "alteration",
        "feox",
        "drainage",
        "distance_from_query_m",
        "bearing_deg",
        "direction_ar",
        "status",
        "note",
        "engine_version"
      ];
      const lines = [headers.join(",")];
      for (const r of rows) {
        lines.push(
          headers
            .map(function (h) {
              const v = r[h] === null || r[h] === undefined ? "" : String(r[h]);
              return '"' + v.replace(/"/g, '""') + '"';
            })
            .join(",")
        );
      }
      return lines.join("\n");
    }

    function exportTargetsGeoJsonString(customTargetsList = null) {
      const rows = rowsTargets(customTargetsList);
      const features = rows.map(function (r) {
        return {
          type: "Feature",
          geometry: {
            type: "Point",
            coordinates: [Number(r.lon), Number(r.lat)]
          },
          properties: r
        };
      });
      return JSON.stringify(
        {
          type: "FeatureCollection",
          engine_version: BouhUnifiedEngine.ENGINE_VERSION,
          bridge_version: BRIDGE_VERSION,
          score_terminology_ar: OFFICIAL_SCORE_TITLE_AR,
          features: features
        },
        null,
        2
      );
    }

    function exportTargetsKmlString(customTargetsList = null) {
      const rows = rowsTargets(customTargetsList);
      const placemarks = rows
        .map(function (r) {
          const desc =
            `أولوية الاستطلاع (Reference Score): ${r.reference_score ?? "بيانات غير كافية"} | ` +
            `الدرجة الأساسية (Core Score): ${r.core_score ?? "غير مفعلة (null)"} | ` +
            `الفئة: ${r.priority_class_code} (${r.priority_class_ar}) | ` +
            `البنية: ${r.structure} | التحول: ${r.alteration} | الحديد: ${r.feox} | التصريف: ${r.drainage} | ` +
            `المسافة: ${r.distance_from_query_m ?? 0}م ${r.direction_ar}`;
          return (
            `<Placemark>` +
            `<name>${safeHtml(r.id || r.uid)}</name>` +
            `<description>${safeHtml(desc)}</description>` +
            `<Point><coordinates>${r.lon},${r.lat},0</coordinates></Point>` +
            `</Placemark>`
          );
        })
        .join("\n");
      return (
        `<?xml version="1.0" encoding="UTF-8"?>` +
        `<kml xmlns="http://www.opengis.net/kml/2.2"><Document>` +
        `<name>تقرير أهداف بوح التضاريس — ${OFFICIAL_SCORE_TITLE_AR}</name>` +
        `${placemarks}</Document></kml>`
      );
    }

    function exportFullReportJsonString(centerCoord = { lat: 19.973186, lon: 36.74559 }, customTargetsList = null) {
      const cLat = Number(centerCoord.lat ?? centerCoord.latitude ?? 19.973186);
      const cLon = Number(centerCoord.lon ?? centerCoord.lng ?? centerCoord.longitude ?? 36.74559);
      const centerAnalysis = analyzeObject(cLat, cLon);
      const rows = rowsTargets(customTargetsList);
      return JSON.stringify(
        {
          app: "بوح التضاريس — نظام الاستكشاف الجيولوجي الموثق",
          owner: OWNER_NAME_AR,
          engine_version: BouhUnifiedEngine.ENGINE_VERSION,
          bridge_version: BRIDGE_VERSION,
          score_terminology_ar: OFFICIAL_SCORE_TITLE_AR,
          operational_mode: "PROVISIONAL_LEGACY_REFERENCE_MODE",
          core_score_status: null,
          aster_layer_status: "QUARANTINED_GEOSPATIAL_BOUNDS_CONFLICT",
          top60_status: "EXCLUDED_SYNTHETIC_PRIOR",
          created_at: new Date().toISOString(),
          map_center: { lat: cLat, lon: cLon },
          map_center_analysis: centerAnalysis,
          db_summary: dbSummaryObject(),
          field_status: fieldStatusObject(),
          targets: rows
        },
        null,
        2
      );
    }

    function exportHtmlFieldReportString(centerCoord = { lat: 19.973186, lon: 36.74559 }, customTargetsList = null) {
      const cLat = Number(centerCoord.lat ?? centerCoord.latitude ?? 19.973186);
      const cLon = Number(centerCoord.lon ?? centerCoord.lng ?? centerCoord.longitude ?? 36.74559);
      const centerAnalysis = analyzeObject(cLat, cLon);
      const db = dbSummaryObject();
      const rows = rowsTargets(customTargetsList);

      const tableRowsHtml = rows
        .map(function (r, idx) {
          return (
            `<tr>` +
            `<td>${idx + 1}</td>` +
            `<td>${safeHtml(r.id)}</td>` +
            `<td>${safeHtml(r.zone)}</td>` +
            `<td>${Number(r.lat).toFixed(6)}, ${Number(r.lon).toFixed(6)}</td>` +
            `<td>${safeHtml(r.priority_class_code)} — ${safeHtml(r.priority_class_ar)}</td>` +
            `<td>${r.reference_score !== null ? r.reference_score : INSUFFICIENT_DATA_LABEL_AR}</td>` +
            `<td>${r.core_score !== null ? r.core_score : "غير مفعلة (null)"}</td>` +
            `<td>${formatMetricValueForDisplay(r.structure)} / ${formatMetricValueForDisplay(r.alteration)} / ${formatMetricValueForDisplay(r.feox)} / ${formatMetricValueForDisplay(r.drainage)}</td>` +
            `<td>${r.distance_from_query_m !== null ? r.distance_from_query_m + " م (" + safeHtml(r.direction_ar) + ")" : "—"}</td>` +
            `<td>${safeHtml(r.note || r.dominant_pathway_ar)}</td>` +
            `</tr>`
          );
        })
        .join("");

      return (
        `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/>` +
        `<meta name="viewport" content="width=device-width,initial-scale=1"/>` +
        `<title>تقرير الاستطلاع الجيولوجي الموحد — بوح التضاريس (${BouhUnifiedEngine.ENGINE_VERSION})</title>` +
        `<style>body{font-family:system-ui,Tahoma,Arial;background:#101318;color:#f7f7f7;margin:0;padding:24px;line-height:1.6}h1,h2{color:#f4c55e}.card{background:#1b2029;border:1px solid #333b49;border-radius:14px;padding:16px;margin:12px 0}table{width:100%;border-collapse:collapse;background:#161b23;border-radius:12px;overflow:hidden}td,th{border-bottom:1px solid #303846;padding:9px;text-align:right;font-size:13px}th{color:#f4c55e;background:#202736}.muted{color:#b9c0ce;font-size:12px}</style>` +
        `</head><body>` +
        `<h1>تقرير بوح التضاريس — ${OFFICIAL_SCORE_TITLE_AR} (${PROVISIONAL_REFERENCE_BADGE_AR})</h1>` +
        `<div class="card">` +
        `<b>المالك:</b> ${OWNER_NAME_AR}<br/>` +
        `<b>إصدار المحرك الموحد:</b> ${BouhUnifiedEngine.ENGINE_VERSION} | <b>إصدار جسر الواجهة:</b> ${BRIDGE_VERSION}<br/>` +
        `<b>مركز الخريطة عند التقرير:</b> ${cLat.toFixed(6)}, ${cLon.toFixed(6)} | ` +
        `<b>حالة المركز:</b> ${safeHtml(centerAnalysis.coverage_label_ar)} | ` +
        `<b>الدرجة المرجعية للمركز:</b> ${centerAnalysis.reference_score !== null ? centerAnalysis.reference_score + "/100 (" + safeHtml(centerAnalysis.priority_class_code) + ")" : INSUFFICIENT_DATA_LABEL_AR}<br/>` +
        `<b>الخلايا النشطة (DP58 + المرجعية):</b> ${db.active_dp58_and_reference_cells} | ` +
        `<b>خلايا ASTER المحجورة جغرافيًا:</b> ${db.quarantined_aster_cells} | ` +
        `<b>سجلات TOP60/Curated المستبعدة:</b> ${db.excluded_top60_and_curated_cells}` +
        `</div>` +
        `<h2>جدول الأهداف المحفوظة (${rows.length})</h2>` +
        `<table><thead><tr>` +
        `<th>#</th><th>معرف الخلية</th><th>النطاق</th><th>الإحداثيات</th><th>فئة أولوية الاستطلاع</th>` +
        `<th>الدرجة المرجعية (Reference)</th><th>الدرجة الأساسية (Core)</th><th>المؤشرات (بنية/تحول/حديد/تصريف)</th><th>المسافة والاتجاه</th><th>المسار/الملاحظة</th>` +
        `</tr></thead><tbody>` +
        (tableRowsHtml || `<tr><td colspan="10">لا توجد أهداف محفوظة</td></tr>`) +
        `</tbody></table>` +
        `<p class="muted">تنبيه علمي: جميع الدرجات المعروضة هنا تمثل «أولوية الاستطلاع — ترتيب مرجعي استرشادي (reference_score)» من شبكة DP58، بينما تبقى الدرجة الأساسية (core_score = null) معطلة حتى التحقق من الراسترات الخام وأقنعة السحب/الجودة والـ التحقق الميداني.</p>` +
        `</body></html>`
      );
    }

    function ask(queryText, mapCenter = null) {
      const q = String(queryText || "").trim();
      const cLat = mapCenter && Number.isFinite(Number(mapCenter.lat)) ? Number(mapCenter.lat) : 19.973186;
      const cLon = mapCenter && Number.isFinite(Number(mapCenter.lon ?? mapCenter.lng)) ? Number(mapCenter.lon ?? mapCenter.lng) : 36.74559;
      const a = analyzeObject(cLat, cLon);

      if (!a.valid_analysis) {
        return `الموقع الحالي (${cLat.toFixed(5)}, ${cLon.toFixed(5)}): ${INSUFFICIENT_DATA_LABEL_AR} (${a.coverage_label_ar}). لا يُصدر المحرك الموحد أي درجة أو ترشيح خارج التغطية المفعلة.`;
      }

      if (/لماذا|سبب|تفسير|درجة|النتيجة/i.test(q)) {
        return (
          `${OFFICIAL_SCORE_TITLE_AR} للخلية ${a.id} (${a.zone}): ${a.reference_score}/100 ` +
          `[${a.priority_class_code} — ${a.priority_class_ar}] | الدرجة الأساسية (core_score): غير مفعلة (null). ` +
          `المؤشرات: البنية ${a.structure}، التحول ${a.alteration}، أكاسيد الحديد ${a.feox}، التصريف ${a.drainage}. ` +
          `${a.reason}`
        );
      }

      return (
        `تقييم ${OFFICIAL_SCORE_TITLE_AR} عند (${cLat.toFixed(5)}, ${cLon.toFixed(5)}): ` +
        `الخلية ${a.id} على مسافة ${a.distance_from_query_m}م باتجاه ${a.direction_ar} (${a.bearing_deg}°) | ` +
        `الدرجة المرجعية ${a.reference_score}/100 (${a.priority_class_code}) | ` +
        `المسار السائد: ${a.dominant_pathway_ar}. ${a.required_verification_ar}`
      );
    }

    return Object.freeze({
      version: BRIDGE_VERSION,
      engineVersion: BouhUnifiedEngine.ENGINE_VERSION,
      owner: OWNER_NAME_AR,
      engine: engine,
      analyzeObject: analyzeObject,
      analyze: analyze,
      nearestTargetsArray: nearestTargetsArray,
      nearestTargets: nearestTargets,
      cellsArray: cellsArray,
      cells: cells,
      dbSummaryObject: dbSummaryObject,
      dbSummary: dbSummary,
      fieldStatusObject: fieldStatusObject,
      fieldStatus: fieldStatus,
      coverageZones: coverageZones,
      saveTargetAtCoordinate: saveTargetAtCoordinate,
      getSavedTargetsList: getSavedTargetsList,
      setSavedTargetsList: setSavedTargetsList,
      buildTargetRow: buildTargetRow,
      rowsTargets: rowsTargets,
      exportTargetsCsvString: exportTargetsCsvString,
      exportTargetsGeoJsonString: exportTargetsGeoJsonString,
      exportTargetsKmlString: exportTargetsKmlString,
      exportFullReportJsonString: exportFullReportJsonString,
      exportHtmlFieldReportString: exportHtmlFieldReportString,
      ask: ask
    });
  }

  /**
   * ربط الجسر الموحد ببيئة المتصفح (DOM / window.BOUH) عند تشغيل assets/index.html
   * بحيث تعمل الخريطة وقائمة الأهداف والتقارير من مصدر حساب واحد فقط دون أي تعارض.
   */
  function attachToBrowserWindow(win, rawCellsArray, engineOptions = {}) {
    if (!win) return null;
    const bridge = createUnifiedUIBridge(rawCellsArray, engineOptions);

    // مزامنة الأهداف المحفوظة من localStorage إن وجدت (بعد إعادة تقييمها بالمحرك الموحد لضمان عدم بقاء درجات قديمة)
    try {
      if (win.localStorage) {
        const stored = JSON.parse(win.localStorage.getItem("bouh_targets_unified_v15") || "[]");
        if (Array.isArray(stored) && stored.length > 0) {
          const revalidated = [];
          for (const item of stored) {
            const tLat = Number(item.lat ?? item.nearest_lat);
            const tLon = Number(item.lon ?? item.nearest_lon);
            if (BouhUnifiedEngine.isValidGeographicCoordinate(tLat, tLon)) {
              const res = bridge.saveTargetAtCoordinate(tLat, tLon, item.note || "", item.status || "NEW");
              if (res.ok) revalidated.push(res.target);
            }
          }
          bridge.setSavedTargetsList(revalidated);
        }
      }
    } catch (_) {}

    win.BOUH = {
      __unifiedV15: true,
      version: BRIDGE_VERSION,
      engineVersion: BouhUnifiedEngine.ENGINE_VERSION,
      bridge: bridge,
      analyze: function (lat, lon) {
        return bridge.analyze(lat, lon);
      },
      nearestTargets: function (lat, lon, n, minScore, filter) {
        return bridge.nearestTargets(lat, lon, n, minScore, filter);
      },
      cells: function (limit) {
        return bridge.cells(limit);
      },
      dbSummary: function () {
        return bridge.dbSummary();
      },
      fieldStatus: function () {
        return bridge.fieldStatus();
      },
      coverageZones: function () {
        return bridge.coverageZones();
      },
      gps: function () {
        return JSON.stringify({
          ok: false,
          message: "استخدم زر GPS في الواجهة؛ يطلب المتصفح الإذن مباشرة."
        });
      },
      sensors: function () {
        return JSON.stringify({
          ok: true,
          ax: 0,
          ay: 0,
          az: 0,
          lux: 0,
          message: "حساسات التوجيه مساندة للتصفح فقط وليست قياسات جيولوجية."
        });
      },
      pickKmlKmz: function () {
        if (typeof win.htmlPickKmlKmz === "function") win.htmlPickKmlKmz();
      },
      ask: function (q) {
        const center = win.map && typeof win.map.getCenter === "function" ? win.map.getCenter() : null;
        return bridge.ask(q, center);
      },
      speak: function (t) {
        try {
          if ("speechSynthesis" in win) {
            const u = new win.SpeechSynthesisUtterance(String(t || ""));
            u.lang = "ar";
            win.speechSynthesis.cancel();
            win.speechSynthesis.speak(u);
          }
        } catch (_) {}
      },
      writeExport: function (name, content) {
        try {
          if (win.document && win.Blob && win.URL) {
            const blob = new win.Blob([String(content || "")], { type: "application/octet-stream" });
            const a = win.document.createElement("a");
            a.href = win.URL.createObjectURL(blob);
            a.download = name || "bouh_export.txt";
            win.document.body.appendChild(a);
            a.click();
            setTimeout(function () {
              win.URL.revokeObjectURL(a.href);
              a.remove();
            }, 1200);
          }
          return JSON.stringify({ ok: true, path: name });
        } catch (e) {
          return JSON.stringify({ ok: false, message: e.message });
        }
      },
      readLogs: function () {
        return JSON.stringify([]);
      }
    };

    // توحيد دوال العرض والتقارير في الواجهة لتقرأ مباشرة من السجل القياسي الموحد
    win.probabilityLabel = function (score, rec) {
      if (rec && !rec.valid_analysis) return INSUFFICIENT_DATA_LABEL_AR;
      if (score === null || score === undefined || !Number.isFinite(Number(score))) return INSUFFICIENT_DATA_LABEL_AR;
      const s = Number(score);
      if (s >= 78) return "أولوية استطلاع مرتفعة (ترتيب مرجعي)";
      if (s >= 64) return "أولوية استطلاع فوق المتوسطة (ترتيب مرجعي)";
      if (s >= 50) return "أولوية استطلاع متوسطة (ترتيب مرجعي)";
      return "أولوية استطلاع منخفضة / استبعاد أولي";
    };

    win.expectedType = function (o) {
      if (!o || !o.valid_analysis) return INSUFFICIENT_DATA_LABEL_AR;
      return o.dominant_pathway_ar || "استطلاع عام";
    };

    win.inds = function (o) {
      if (!o || !o.valid_analysis) return "البنية: — • التحول: — • الحديد: — • التصريف: —";
      return (
        `البنية ${formatMetricValueForDisplay(o.structure)} • ` +
        `التحول ${formatMetricValueForDisplay(o.alteration)} • ` +
        `الحديد ${formatMetricValueForDisplay(o.feox)} • ` +
        `التصريف ${formatMetricValueForDisplay(o.drainage)}`
      );
    };

    win.drawGauge = function (score, o) {
      if (!win.document) return;
      const valid = Boolean(o && o.valid_analysis && o.reference_score !== null);
      const pct = valid ? Math.max(0, Math.min(100, Number(o.reference_score))) : 0;
      const textVal = valid ? String(o.reference_score) : "--";
      const box = win.document.getElementById("radarGaugeBox");
      if (box) {
        box.innerHTML =
          `<div class="gaugeBox">` +
          `<div class="gauge" style="--p:${pct}%"><div class="gaugeInner">${safeHtml(textVal)}</div></div>` +
          `<div><b style="font-size:16px;color:#f4c55e">${safeHtml(o ? o.priority_class_ar : INSUFFICIENT_DATA_LABEL_AR)}</b>` +
          `<div>${safeHtml(win.expectedType(o))}</div>` +
          `<small>${safeHtml(win.inds(o))}</small></div></div>`;
      }
      const strip = win.document.getElementById("radarStrip");
      if (strip) {
        strip.innerText =
          `${OFFICIAL_SCORE_TITLE_AR}: ${valid ? o.reference_score + "/100" : INSUFFICIENT_DATA_LABEL_AR} | ` +
          `الدرجة الأساسية (core_score): غير مفعلة (null) | ${win.inds(o)}`;
      }
    };

    win.renderMetrics = function (o) {
      if (!win.document) return;
      const valid = Boolean(o && o.valid_analysis);
      const keys = [
        ["structure", "البنية والخطيات"],
        ["alteration", "التحول الطيفي (SWIR)"],
        ["feox", "أكاسيد الحديد (FeOx)"],
        ["drainage", "التصريف والمصائد"],
        ["data_quality_score", "درجة جودة البيانات"]
      ];
      const el = win.document.getElementById("radarMetrics");
      if (el) {
        el.innerHTML = keys
          .map(function (k) {
            const rawVal = valid && o ? o[k[0]] : null;
            const disp = formatMetricValueForDisplay(rawVal);
            const pct = rawVal !== null && Number.isFinite(Number(rawVal)) ? Math.max(0, Math.min(100, Number(rawVal))) : 0;
            return (
              `<div class="metric">${k[1]}: <b>${disp}</b>` +
              `<div class="bar"><div class="fill" style="width:${pct}%"></div></div></div>`
            );
          })
          .join("");
      }
    };

    win.analyzeCurrent = function (open = true) {
      const p = typeof win.currentLatLng === "function" ? win.currentLatLng() : { lat: 19.973186, lng: 36.74559 };
      const o = bridge.analyzeObject(p.lat, p.lng);
      const valid = o.valid_analysis && o.reference_score !== null;

      win.drawGauge(o.reference_score, o);
      win.renderMetrics(o);

      if (win.document) {
        const setTxt = function (id, val) {
          const e = win.document.getElementById(id);
          if (e) e.innerText = val;
        };
        setTxt("v45Score", valid ? String(o.reference_score) : "--");
        setTxt("v45Structure", formatMetricValueForDisplay(o.structure));
        setTxt("v45Alteration", formatMetricValueForDisplay(o.alteration));
        setTxt("v45Feox", formatMetricValueForDisplay(o.feox));
        setTxt("v45Drainage", formatMetricValueForDisplay(o.drainage));
        setTxt("v46ClassText", valid ? o.priority_class_code : INSUFFICIENT_DATA_LABEL_AR);
        setTxt("v46DistanceText", o.distance_from_query_m !== null ? o.distance_from_query_m + " م" : "—");
        setTxt(
          "quickMini",
          valid
            ? `${OFFICIAL_SCORE_TITLE_AR}: ${o.reference_score}/100 • ${o.priority_class_code} • ${o.distance_from_query_m}م`
            : `${INSUFFICIENT_DATA_LABEL_AR} • خارج التغطية`
        );
        setTxt(
          "v48TargetBand",
          valid
            ? `🎯 ${o.id} (${o.zone}) • ${o.priority_class_code} • ${o.reference_score}/100 • ${o.distance_from_query_m}م`
            : `🎯 ${INSUFFICIENT_DATA_LABEL_AR} — خارج نطاق البحث المعلن (900م)`
        );

        const rr = win.document.getElementById("radarResult");
        if (rr) {
          rr.innerText =
            `📍 الإحداثية: ${Number(p.lat).toFixed(6)}, ${Number(p.lng).toFixed(6)}\n` +
            `🛰️ حالة التغطية: ${o.coverage_label_ar}\n` +
            `📦 الخلية المرجعية: ${o.id || "—"} | النطاق: ${o.zone || "—"}\n` +
            `📏 المسافة والاتجاه: ${o.distance_from_query_m !== null ? o.distance_from_query_m + " م (" + o.direction_ar + " " + o.bearing_deg + "°)" : "—"}\n` +
            `📊 ${OFFICIAL_SCORE_TITLE_AR} (Reference Score): ${valid ? o.reference_score + "/100" : INSUFFICIENT_DATA_LABEL_AR}\n` +
            `🔒 الدرجة الأساسية (Core Score): غير مفعلة (null — بانتظار التحقق من الراسترات الخام)\n` +
            `🏷️ الفئة: ${o.classification}\n` +
            `🧭 المسار السائد: ${o.dominant_pathway_ar}\n\n` +
            `${o.reason}\n\n` +
            `التحقق الميداني المطلوب:\n${o.required_verification_ar}\n\n` +
            `${o.truth}`;
        }
      }

      if (open && typeof win.openPanel === "function") {
        win.openPanel("radarPanel");
      }
      return o;
    };

    win.getSavedTargets = function () {
      return bridge.getSavedTargetsList();
    };

    win.setSavedTargets = function (list) {
      bridge.setSavedTargetsList(list);
      try {
        if (win.localStorage) {
          win.localStorage.setItem("bouh_targets_unified_v15", JSON.stringify(bridge.getSavedTargetsList()));
        }
      } catch (_) {}
    };

    win.saveTargetFromCenter = function () {
      const p = typeof win.currentLatLng === "function" ? win.currentLatLng() : { lat: 19.973186, lng: 36.74559 };
      const noteEl = win.document ? win.document.getElementById("targetNote") : null;
      const note = noteEl && noteEl.value ? String(noteEl.value).trim() : "";
      const res = bridge.saveTargetAtCoordinate(p.lat, p.lng, note, win.defaultTargetStatus || "NEW");
      if (!res.ok) {
        if (typeof win.showStatus === "function") {
          win.showStatus(res.message_ar);
        }
        return res;
      }
      try {
        if (win.localStorage) {
          win.localStorage.setItem("bouh_targets_unified_v15", JSON.stringify(bridge.getSavedTargetsList()));
        }
      } catch (_) {}
      if (typeof win.renderSavedTargets === "function") win.renderSavedTargets();
      if (typeof win.showStatus === "function") {
        win.showStatus(`تم حفظ الهدف ${res.target.id} (${res.target.reference_score}/100 — ${res.target.priority_class_code})`);
      }
      return res;
    };

    win.cardForTarget = function (t, i) {
      const r = bridge.buildTargetRow(t);
      const scoreText = r.reference_score !== null ? `${r.reference_score}/100` : INSUFFICIENT_DATA_LABEL_AR;
      const distText =
        r.distance_from_query_m !== null ? ` | ${r.distance_from_query_m}م ${r.direction_ar}` : "";
      return (
        `<div class="targetCard">` +
        `<strong>${safeHtml(r.id || r.uid || "هدف " + (i + 1))} (${safeHtml(r.zone)})</strong>` +
        `<div class="targetMeta">` +
        `${OFFICIAL_SCORE_TITLE_AR}: <b>${safeHtml(scoreText)}</b> (core_score: null) | ` +
        `${safeHtml(r.priority_class_code)} — ${safeHtml(r.priority_class_ar)}${safeHtml(distText)}<br/>` +
        `الإحداثيات: ${Number(r.lat).toFixed(6)}, ${Number(r.lon).toFixed(6)}<br/>` +
        `المؤشرات: البنية ${formatMetricValueForDisplay(r.structure)} • التحول ${formatMetricValueForDisplay(r.alteration)} • الحديد ${formatMetricValueForDisplay(r.feox)} • التصريف ${formatMetricValueForDisplay(r.drainage)} | ` +
        `جودة البيانات: ${formatMetricValueForDisplay(r.data_quality_score)}` +
        `</div>` +
        `<div>${safeHtml(r.note || r.dominant_pathway_ar)}</div>` +
        `<div class="targetActions">` +
        `<button class="miniBtn good" onclick="map.setView([${r.lat},${r.lon}],18);analyzeCurrent(false);closePanels()">فتح في الخريطة</button>` +
        `</div></div>`
      );
    };

    win.showNearestTargets = function () {
      const p = typeof win.currentLatLng === "function" ? win.currentLatLng() : { lat: 19.973186, lng: 36.74559 };
      const minEl = win.document ? win.document.getElementById("minScoreInput") : null;
      const clsEl = win.document ? win.document.getElementById("classFilter") : null;
      const minScore = minEl && minEl.value !== "" ? parseInt(minEl.value, 10) : 60;
      const clsFilter = clsEl && clsEl.value ? clsEl.value : "";
      const arr = bridge.nearestTargetsArray(p.lat, p.lng, 10, minScore, clsFilter);
      if (win.document) {
        const sum = win.document.getElementById("targetsSummary");
        const el = win.document.getElementById("targetsList");
        if (sum) {
          sum.innerText = `أقرب ${arr.length} أهداف من مركز الخريطة (${OFFICIAL_SCORE_TITLE_AR} — Reference Score)`;
        }
        if (el) {
          el.innerHTML = arr.length
            ? arr.map(function (t, idx) {
                return win.cardForTarget(t, idx, true);
              }).join("")
            : `<div class="strip">لا توجد خلايا مفعلة مطابقة للفلتر ضمن نطاق البحث.</div>`;
        }
      }
      return arr;
    };

    win.rowsTargets = function () {
      return bridge.rowsTargets();
    };

    win.exportTargetsCsv = function () {
      const csv = bridge.exportTargetsCsvString();
      if (typeof win.exportViaNative === "function") {
        return win.exportViaNative("bouh_targets_unified_" + Date.now() + ".csv", csv);
      }
      return csv;
    };

    win.exportTargetsKml = function () {
      const kml = bridge.exportTargetsKmlString();
      if (typeof win.exportViaNative === "function") {
        return win.exportViaNative("bouh_targets_unified_" + Date.now() + ".kml", kml);
      }
      return kml;
    };

    win.exportTargetsGeoJson = function () {
      const geojson = bridge.exportTargetsGeoJsonString();
      if (typeof win.exportViaNative === "function") {
        return win.exportViaNative("bouh_targets_unified_" + Date.now() + ".geojson", geojson);
      }
      return geojson;
    };

    win.exportFullReport = function () {
      const p = typeof win.currentLatLng === "function" ? win.currentLatLng() : { lat: 19.973186, lng: 36.74559 };
      const jsonStr = bridge.exportFullReportJsonString({ lat: p.lat, lon: p.lng });
      if (typeof win.exportViaNative === "function") {
        return win.exportViaNative("bouh_full_report_unified_" + Date.now() + ".json", jsonStr);
      }
      return jsonStr;
    };

    win.exportHtmlFieldReport = function () {
      const p = typeof win.currentLatLng === "function" ? win.currentLatLng() : { lat: 19.973186, lng: 36.74559 };
      const htmlStr = bridge.exportHtmlFieldReportString({ lat: p.lat, lon: p.lng });
      if (typeof win.exportViaNative === "function") {
        return win.exportViaNative("bouh_field_report_unified_" + Date.now() + ".html", htmlStr);
      }
      return htmlStr;
    };

    win.loadCells = function () {
      try {
        if (!win.L || !win.importantLayer) return;
        win.importantLayer.clearLayers();
        const markers = bridge.cellsArray(300);
        markers.forEach(function (c) {
          const col =
            c.priority_class_code === "REFERENCE_PRIORITY_A"
              ? "#ff6969"
              : c.priority_class_code === "REFERENCE_PRIORITY_B"
              ? "#f4c55e"
              : "#66d87c";
          win.L.circleMarker([c.lat, c.lon], {
            radius: 3.5,
            color: col,
            fillColor: col,
            fillOpacity: 0.45,
            weight: 1
          })
            .addTo(win.importantLayer)
            .bindPopup(
              `<b>${safeHtml(c.id)} (${safeHtml(c.zone)})</b><br/>` +
                `${safeHtml(c.priority_class_code)} — ${safeHtml(c.priority_class_ar)}<br/>` +
                `${OFFICIAL_SCORE_TITLE_AR}: ${c.reference_score}/100 (core_score: null)`
            );
        });
      } catch (_) {}
    };

    return bridge;
  }

  /**
   * دالة ترقيع وتطهير ملف assets/index.html الأصلي آليًا:
   * - تزيل الخطأ النحوي في Template Literal المكسور داخل exportHtmlFieldReport (الأسطر 846–1666).
   * - تزيل مصفوفة TOP60 وجميع طبقات التعديل المتراكبة السبع (v49, v50, v51, v63, v64, v70, v763, v71).
   * - تدمج المحرك الموحد (v1.5.0) وجسر الواجهة الموحد (v1.5.0) بحيث يترجم كل <script> في الملف الناتج
   *   بدون أي خطأ نحوي (0 SyntaxError) وبمصدر حساب واحد فقط.
   */
  function buildCleanIntegratedHtml(rawHtmlContent, engineJsContent, bridgeJsContent) {
    const lines = String(rawHtmlContent).split(/\r?\n/);
    const rawCellsLine = lines.find(function (l) {
      return l.includes("const RAW_CELLS = [[");
    });
    if (!rawCellsLine) {
      throw new Error("Could not locate const RAW_CELLS in rawHtmlContent.");
    }

    // نحتفظ بالجزء العلوي النظيف (الأغلفة، الأنماط، وعناصر HTML، وبديل Leaflet المصغر: الأسطر 1..297)
    // والجزء الأساسي لواجهة الخريطة (الأسطر 446..749) بعد تنظيفه من أي استدعاء لـ TOP60 أو احتمال الذهب
    const headAndDomPart = lines.slice(0, 297).join("\n")
      .replace(/تخزين سريع حول TOP60/g, "تخزين سريع حول أعلى الخلايا المرجعية")
      .replace(/<option value="GPZ">GPZ<\/option><option value="Candidate">Candidate<\/option><option value="HOLD">HOLD<\/option>/g,
        '<option value="REFERENCE_PRIORITY_A">فئة أ مرجعية (REFERENCE_PRIORITY_A)</option>' +
        '<option value="REFERENCE_PRIORITY_B">فئة ب مرجعية (REFERENCE_PRIORITY_B)</option>' +
        '<option value="REFERENCE_PRIORITY_C">فئة ج مرجعية (REFERENCE_PRIORITY_C)</option>' +
        '<option value="VEIN_STRUCTURAL">مسار عروق وبنية (VEIN_STRUCTURAL)</option>' +
        '<option value="PLACER_ALLUVIAL">مسار غريني ومصائد (PLACER_ALLUVIAL)</option>');

    const baseUiScriptLines = lines.slice(445, 749).join("\n");

    const integratedHtml = [
      headAndDomPart,
      `<script id="bouh-raw-cells-data">`,
      `window.__BOUH_RAW_CELLS__ = (function(){`,
      rawCellsLine,
      `return RAW_CELLS;`,
      `})();`,
      `<\/script>`,
      `<script id="bouh-unified-engine-v15">`,
      String(engineJsContent).trim(),
      `<\/script>`,
      `<script id="bouh-ui-unified-integration-bridge-v15">`,
      String(bridgeJsContent).trim(),
      `<\/script>`,
      baseUiScriptLines,
      `<script id="bouh-stage1-2-unified-bootstrap">`,
      `(function(){`,
      `  "use strict";`,
      `  const rawCells = window.__BOUH_RAW_CELLS__ || [];`,
      `  window.__BOUH_ACTIVE_BRIDGE__ = window.BouhUIBridge.attachToBrowserWindow(window, rawCells, {`,
      `    allowQuarantinedAster: false,`,
      `    collinearityDiscountPoints: 8`,
      `  });`,
      `  window.v44TargetsForPlanning = function(){`,
      `    const p = typeof window.currentLatLng === "function" ? window.currentLatLng() : { lat: 19.973186, lng: 36.745590 };`,
      `    return window.__BOUH_ACTIVE_BRIDGE__.nearestTargetsArray(p.lat, p.lng, 30, 60, "");`,
      `  };`,
      `  window.showFieldReadiness = function(){`,
      `    const db = window.__BOUH_ACTIVE_BRIDGE__.dbSummaryObject();`,
      `    const box = document.getElementById("fieldStatusBox");`,
      `    if (box) {`,
      `      box.innerHTML = "<div class=\\"fieldCard\\"><b>المحرك الموحد (" + db.engine_version + ")</b><br/>" +`,
      `        "الخلايا النشطة: " + db.active_dp58_and_reference_cells + "<br/>" +`,
      `        "خلايا ASTER المحجورة: " + db.quarantined_aster_cells + "<br/>" +`,
      `        "سجلات TOP60 المستبعدة: " + db.excluded_top60_and_curated_cells + "<br/>" +`,
      `        "الدرجة الأساسية (core_score): معطلة (null)</div>";`,
      `    }`,
      `    if (typeof window.openPanel === "function") window.openPanel("fieldPanel");`,
      `  };`,
      `})();`,
      `<\/script>`,
      `</body></html>`
    ].join("\n");

    return integratedHtml;
  }

  return Object.freeze({
    BRIDGE_VERSION: BRIDGE_VERSION,
    OWNER_NAME_AR: OWNER_NAME_AR,
    OFFICIAL_SCORE_TITLE_AR: OFFICIAL_SCORE_TITLE_AR,
    INSUFFICIENT_DATA_LABEL_AR: INSUFFICIENT_DATA_LABEL_AR,
    formatUnifiedRecordForUI: formatUnifiedRecordForUI,
    createUnifiedUIBridge: createUnifiedUIBridge,
    attachToBrowserWindow: attachToBrowserWindow,
    buildCleanIntegratedHtml: buildCleanIntegratedHtml
  });
});
